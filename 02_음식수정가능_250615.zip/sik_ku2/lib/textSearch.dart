import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'intakeStore/firestore_intake.dart';
import 'main.dart';
import 'dart:convert'; // JSON 파싱용
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:xml/xml.dart';

class Screen2State extends State<FirstScreen> {
  final TextEditingController _controller = TextEditingController();
  List<Map<String, dynamic>> _searchResults = []; // 검색 결과 리스트 저장
  bool _isLoading = false; // 로딩 상태 관리
  int _currentPage = 1; // 현재 페이지 번호, 1부터 시작
  int _totalPages = 0; // 전체 페이지 수
  static const int _itemsPerPage = 10; // 페이지당 항목 수
  String _currentQuery = ''; // 현재 검색어
  bool _hasSearched = false; // 검색어가 입력되었는지 여부

  // API 호출 함수
  Future<void> _performSearch(String query, {int pageNo = 1}) async {
    setState(() {
      _isLoading = true;
      _searchResults = []; // 이전 결과 초기화
      if (query != _currentQuery) {
        _currentPage = 1; // 새로운 검색어일 경우 페이지 초기화
      }
      _currentQuery = query;
      _hasSearched = true; // 검색어가 입력되었음을 표시
    });

    final String apiUrl =
        'https://apis.data.go.kr/1471000/FoodNtrCpntDbInfo01/getFoodNtrCpntDbInq01';
    final String serviceKey =
        'XgwptjbbJW9Kj0dDUwg4g47BpypKMzQrg%2ByaUu6Vs%2BI2nmZpO%2BMzm9zl%2FnJvp2%2BnElg4FgOKt8r1Na6kt4FKmQ%3D%3D';

    // 페이지 번호 추가
    final Uri uri = Uri.parse(
        '$apiUrl?serviceKey=$serviceKey&FOOD_NM_KR=${Uri.encodeComponent(query)}&pageNo=$pageNo&numOfRows=$_itemsPerPage&type=json');

    try {
      final response = await http.get(uri);

      if (response.statusCode == 200) {
        // 응답 본문 출력 (디버깅용)
        print('응답 본문: ${response.body}');

        if (_isXmlResponse(response.body)) {
          // XML 파싱
          try {
            final document = XmlDocument.parse(response.body);
            final items = document.findAllElements('item');
            setState(() {
              _searchResults = items
                  .map((item) => {
                'FOOD_NM_KR': item.findElements('FOOD_NM_KR').first.text, // 식품명
                'FOOD_CAT3_NM': item.findElements('FOOD_CAT3_NM').first.text, // 식품소분류명
                'AMT_NUM1': item.findElements('AMT_NUM1').first.text, // 에너지
                'AMT_NUM6': item.findElements('AMT_NUM6').first.text, // 탄수화물
                'AMT_NUM3': item.findElements('AMT_NUM3').first.text, // 단백질
                'AMT_NUM4': item.findElements('AMT_NUM4').first.text, // 지방
                'AMT_NUM7': item.findElements('AMT_NUM7').first.text, // 당류
                'AMT_NUM13': item.findElements('AMT_NUM13').first.text, // 나트륨
                'AMT_NUM23': item.findElements('AMT_NUM23').first.text, // 콜레스테롤
                'NUTRI_AMOUNT_SERVING': item.findElements('NUTRI_AMOUNT_SERVING').first.text, // 1회 섭취참고량
                'Z10500': item.findElements('Z10500').first.text, // 식품중량
                'MAKER_NM': item.findElements('MAKER_NM').first.text, // 업체명
                'ITEM_REPORT_NO': item.findElements('ITEM_REPORT_NO').first.text, // 품목제조보고번호
                'UPDATE_YMD': item.findElements('UPDATE_YMD').first.text, // 데이터기준일자
              })
                  .toList();
              _totalPages = (_searchResults.length / _itemsPerPage).ceil();
            });
          } catch (e) {
            setState(() {
              _searchResults = [
                {'FOOD_NM_KR': 'XML 파싱 중 오류 발생: $e'}
              ];
            });
          }
        } else {
          // JSON 파싱
          try {
            final data = json.decode(response.body);
            if (data['header']['resultCode'] == '00') {
              final totalCount =
                  int.tryParse(data['body']['totalCount']?.toString() ?? '0') ??
                      0;
              _totalPages = (totalCount / _itemsPerPage).ceil();

              final items = data['body']['items'];
              if (items != null) {
                List<dynamic> itemList;

                if (items is List) {
                  // items가 리스트인 경우 여러 개의 아이템 처리
                  itemList = items;
                } else if (items is Map && items['item'] is List) {
                  // items 안의 item이 리스트인 경우
                  itemList = items['item'];
                } else if (items is Map && items['item'] is Map) {
                  // items 안의 item이 단일 객체인 경우
                  itemList = [items['item']];
                } else {
                  itemList = [];
                }

                setState(() {
                  _searchResults = itemList
                      .map((item) => {
                    'FOOD_NM_KR': item['FOOD_NM_KR'] as String, // 식품명
                    'FOOD_CAT3_NM': item['FOOD_CAT3_NM'], // 식품소분류명
                    'AMT_NUM1': item['AMT_NUM1'], // 에너지
                    'AMT_NUM6': item['AMT_NUM6'], // 탄수화물
                    'AMT_NUM3': item['AMT_NUM3'], // 단백질
                    'AMT_NUM4': item['AMT_NUM4'], // 지방
                    'AMT_NUM7': item['AMT_NUM7'], // 당류
                    'AMT_NUM13': item['AMT_NUM13'], // 나트륨
                    'AMT_NUM23': item['AMT_NUM23'], // 콜레스테롤
                    'NUTRI_AMOUNT_SERVING': item['NUTRI_AMOUNT_SERVING'], // 1회 섭취참고량
                    'Z10500': item['Z10500'], // 식품중량
                    'MAKER_NM': item['MAKER_NM'], // 업체명
                    'ITEM_REPORT_NO': item['ITEM_REPORT_NO'], // 품목제조보고번호
                    'UPDATE_YMD': item['UPDATE_YMD'], // 데이터기준일자
                  })
                      .toList();
                });
              } else {
                setState(() {
                  _searchResults = [
                    {'FOOD_NM_KR': '검색 결과가 없습니다: "$query"'}
                  ];
                  _totalPages = 1;
                });
              }
            } else {
              setState(() {
                _searchResults = [
                  {'FOOD_NM_KR': '오류: ${data['header']['resultMsg']}'}
                ];
                _totalPages = 1;
              });
            }
          } catch (e) {
            setState(() {
              _searchResults = [
                {'FOOD_NM_KR': 'JSON 파싱 중 오류 발생: $e'}
              ];
              _totalPages = 1;
            });
          }
        }
      } else {
        setState(() {
          _searchResults = [
            {'FOOD_NM_KR': '서버 오류: 데이터를 가져오는 데 실패했습니다 (상태 코드: ${response.statusCode})'}
          ];
          _totalPages = 1;
        });
      }
    } catch (e) {
      setState(() {
        _searchResults = [
          {'FOOD_NM_KR': '네트워크 요청 중 오류 발생: $e'}
        ];
        _totalPages = 1;
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // 응답이 XML인지 JSON인지 확인하는 함수
  bool _isXmlResponse(String responseBody) {
    return responseBody.trim().startsWith('<');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: const Text('Text Search'),
      //   backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      // ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '텍스트 검색',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30.0),
                        borderSide: const BorderSide(color: Colors.green),
                      ),
                      hintText: '식품명을 입력해주세요',
                      hintStyle: const TextStyle(color: Colors.grey),
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.search, color: Colors.green),
                        onPressed: () {
                          if (_controller.text.isNotEmpty) {
                            _performSearch(_controller.text);
                          }
                        },
                      ),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30.0),
                        borderSide: const BorderSide(color: Colors.green),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30.0),
                        borderSide: const BorderSide(color: Colors.green, width: 2),
                      ),
                    ),
                    style: const TextStyle(fontSize: 16),
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.search,
                    onSubmitted: (query) {
                      if (query.isNotEmpty) {
                        _performSearch(query);
                      }
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            if (_isLoading)
              const Center(child: CircularProgressIndicator())
            else if (_hasSearched && _searchResults.isEmpty)
              const Text('결과가 없습니다.', style: TextStyle(fontSize: 16))
            else
              Expanded(
                child: Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                        itemCount: _searchResults.length,
                        itemBuilder: (context, index) {
                          return ListTile(
                            title: Text(_searchResults[index]['FOOD_NM_KR'] ?? 'N/A'),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => FoodDetailPage(
                                    foodItem: _searchResults[index],
                                  ),
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        _totalPages,
                            (index) => InkWell(
                          onTap: () {
                            setState(() {
                              _currentPage = index + 1; // 페이지 번호는 1부터 시작
                              _performSearch(_currentQuery, pageNo: _currentPage);
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              '${index + 1}',
                              style: TextStyle(
                                fontWeight: _currentPage == index + 1
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                                color: _currentPage == index + 1
                                    ? Colors.blue
                                    : Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}


class FoodDetailPage extends StatefulWidget {
  final Map<String, dynamic> foodItem;

  const FoodDetailPage({super.key, required this.foodItem});

  @override
  _FoodDetailPageState createState() => _FoodDetailPageState();
}

class _FoodDetailPageState extends State<FoodDetailPage> {
  double _selectedAmount = 0; // 선택된 섭취량
  double _totalConsumed = 0; // 총 섭취량
  double _inputWeight = 100.0; // 텍스트 필드의 초기값

  double recommendedCalories = 0.0;
  double recommendedCarbs = 0.0;
  double recommendedProtein = 0.0;
  double recommendedFat = 0.0;
  double recommendedSugars = 0.0;
  double recommendedSodium = 0.0;
  double recommendedCholesterol = 0.0;

  final TextEditingController _weightController = TextEditingController(text: '100'); // 입력 필드 초기화
  final ScrollController _scrollController = ScrollController();

  // 상태 추적을 위해 추가
  Set<int> expandedIndexes = {};
  final List<GlobalKey> itemKeys = [];

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    // 초기 중량 설정
    final weightText = widget.foodItem['Z10500']?.toString()?.replaceAll('g', '').trim() ?? '100';
    final parsedWeight = double.tryParse(weightText) ?? 100.0;

    _inputWeight = parsedWeight;
    _weightController.text = parsedWeight % 1 == 0
        ? parsedWeight.toStringAsFixed(0)
        : parsedWeight.toStringAsFixed(1);

    _loadUserNutrition();           // 사용자 권장 영양소 로드

    itemKeys.addAll(List.generate(100, (_) => GlobalKey()));
  }

  Future<void> _saveConsumptionToFirestore() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    final today = DateTime.now().toIso8601String().split('T')[0];

    // 사용자가 입력한 섭취량
    double consumedAmount = _totalConsumed;

    // 각 영양소 값을 섭취량에 맞게 변환하여 저장
    double calculateNutrient(dynamic nutrientValue) {
      double originalValue = double.tryParse(nutrientValue?.toString() ?? '0') ?? 0.0;
      return (originalValue / 100) * consumedAmount;
    }

    // 영양소 계산
    double calories = calculateNutrient(widget.foodItem['AMT_NUM1']);  // 칼로리
    double carbohydrates = calculateNutrient(widget.foodItem['AMT_NUM6']);  // 탄수화물
    double protein = calculateNutrient(widget.foodItem['AMT_NUM3']);  // 단백질
    double fat = calculateNutrient(widget.foodItem['AMT_NUM4']);  // 지방
    double sugars = calculateNutrient(widget.foodItem['AMT_NUM7']);  // 당류
    double sodium = calculateNutrient(widget.foodItem['AMT_NUM13']);  // 나트륨
    double cholesterol = calculateNutrient(widget.foodItem['AMT_NUM23']);  // 콜레스테롤


    try {
      await FirebaseFirestore.instance
          .collection('sjsk_users')
          .doc(currentUser.email)
          .collection(today)
          .add({
        'foodName': widget.foodItem['FOOD_NM_KR'] ?? 'Unknown',
        'totalConsumed': consumedAmount.toStringAsFixed(1),
        'calories': calories.toStringAsFixed(1),
        'carbohydrates': carbohydrates.toStringAsFixed(1),
        'protein': protein.toStringAsFixed(1),
        'fat': fat.toStringAsFixed(1),
        'sugars': sugars.toStringAsFixed(1),
        'sodium': sodium.toStringAsFixed(1),
        'timestamp': Timestamp.now(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('섭취 기록이 저장되었습니다!')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('저장 중 오류 발생: $e')),
      );
    }
  }


  void _showEditDialog(DocumentSnapshot<Map<String, dynamic>> doc) {
    final record = doc.data()!;
    final foodNameController = TextEditingController(text: record['foodName']);
    final amountController = TextEditingController(text: record['totalConsumed']);
    final caloriesController = TextEditingController(text: record['calories']);
    final carbsController = TextEditingController(text: record['carbohydrates']);
    final proteinController = TextEditingController(text: record['protein']);
    final fatController = TextEditingController(text: record['fat']);
    final sugarsController = TextEditingController(text: record['sugars']);
    final sodiumController = TextEditingController(text: record['sodium']);
    final cholesterolController = TextEditingController(text: record['cholesterol']);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("섭취 기록 수정"),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildTextField('음식명', foodNameController),
              _buildTextField('섭취량(g)', amountController),
              _buildTextField('칼로리(kcal)', caloriesController),
              _buildTextField('탄수화물(g)', carbsController),
              _buildTextField('단백질(g)', proteinController),
              _buildTextField('지방(g)', fatController),
              _buildTextField('당류(g)', sugarsController),
              _buildTextField('나트륨(mg)', sodiumController),
              _buildTextField('콜레스테롤(mg)', cholesterolController),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("취소"),
          ),
          TextButton(
            onPressed: () async {
              await doc.reference.delete();
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("기록이 삭제되었습니다.")));
            },
            child: const Text("삭제", style: TextStyle(color: Colors.red)),
          ),
          ElevatedButton(
            onPressed: () async {
              await doc.reference.update({
                'foodName': foodNameController.text,
                'totalConsumed': amountController.text,
                'calories': caloriesController.text,
                'carbohydrates': carbsController.text,
                'protein': proteinController.text,
                'fat': fatController.text,
                'sugars': sugarsController.text,
                'sodium': sodiumController.text,
                'cholesterol': cholesterolController.text,
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("기록이 수정되었습니다.")));
            },
            child: const Text("저장"),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(),
          isDense: true,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final foodItem = widget.foodItem;
    final double maxWeight =
        double.tryParse(foodItem['Z10500']?.toString() ?? '0') ?? 0.0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('식품 상세 정보'),
        backgroundColor: const Color(0xFF9CAF88),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '"${foodItem['FOOD_NM_KR'] ?? 'N/A'}"의 영양성분',
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            // 영양성분 테이블
            Table(
              border: TableBorder.all(color: Colors.grey),
              columnWidths: const {
                0: FlexColumnWidth(1.1),
                1: FlexColumnWidth(1.1),
                2: FlexColumnWidth(1.1),
              },
              children: [
                TableRow(
                  decoration: BoxDecoration(color: Colors.grey[300]),
                  children: [
                    const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text('영양성분',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _weightController,
                              keyboardType: TextInputType.number,
                              textAlign: TextAlign.center,
                              decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                contentPadding: EdgeInsets.symmetric(
                                    vertical: 5, horizontal: 5),
                                hintText: 'g',
                              ),
                              onChanged: (value) {
                                setState(() {
                                  _inputWeight = double.tryParse(value) ?? 100.0;
                                });
                              },
                            ),
                          ),
                          const Text('g 당 함량'),
                        ],
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text('1일 영양섭취 기준 (%)',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
                _buildDynamicNutritionRow('에너지', foodItem['AMT_NUM1'], 0.0), // 에너지
                _buildDynamicNutritionRow('탄수화물', foodItem['AMT_NUM6'], 0.0), // 탄수화물
                _buildDynamicNutritionRow('단백질', foodItem['AMT_NUM3'], 0.0), // 단백질
                _buildDynamicNutritionRow('지방', foodItem['AMT_NUM4'], 0.0), // 지방
                _buildDynamicNutritionRow('당류', foodItem['AMT_NUM7'], 0.0), // 당류
                _buildDynamicNutritionRow('나트륨', foodItem['AMT_NUM13'], 0.0), // 나트륨
                _buildDynamicNutritionRow('콜레스테롤', foodItem['AMT_NUM23'], 0.0), // 콜레스테롤
              ],
            ),
            const SizedBox(height: 16),
            // 부가 정보
            Text(
              '부가 정보',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Table(
              border: TableBorder.all(color: Colors.grey),
              columnWidths: const {
                0: FlexColumnWidth(1),
                1: FlexColumnWidth(2),
              },
              children: [
                _buildAdditionalInfoRow('식품명', foodItem['FOOD_NM_KR'] ?? 'N/A'),
                _buildAdditionalInfoRow('제조사명', foodItem['MAKER_NM'] ?? 'N/A'),
                _buildAdditionalInfoRow('식품 중량', '${(double.tryParse(foodItem['Z10500']?.toString()?.replaceAll('g', '').trim() ?? '0') ?? 0).toStringAsFixed(1)}g' ?? 'N/A'),
                _buildAdditionalInfoRow('1회 섭취참고량', foodItem['NUTRI_AMOUNT_SERVING'] ?? '데이터 미등록'),
                _buildAdditionalInfoRow('품목제조보고번호', foodItem['ITEM_REPORT_NO'] ?? '데이터 미등록'),
              ],
            ),
            const SizedBox(height: 16),
            // 슬라이더
            Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(
                      child: Column(
                        children: [
                          Slider(
                            value: _selectedAmount,
                            min: 0,
                            max: foodItem['Z10500'] != null
                                ? double.tryParse(
                              foodItem['Z10500']
                                  .toString()
                                  .replaceAll('g', '')
                                  .trim(),
                            ) ?? 1.0
                                : 1.0,
                            divisions: foodItem['Z10500'] != null
                                ? (double.tryParse(
                              foodItem['Z10500']
                                  .toString()
                                  .replaceAll('g', '')
                                  .trim(),
                            )?.toInt() ?? 1)
                                : null,
                            label: '${_selectedAmount.toStringAsFixed(1)}g',
                            onChanged: (value) {
                              setState(() {
                                _selectedAmount = value;
                                _inputWeight = value;  // 실시간 계산 반영
                                _weightController.text = value.toStringAsFixed(1);
                              });
                            },
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('0g', style: TextStyle(fontSize: 16)),
                              Text(
                                '${(double.tryParse(foodItem['Z10500']?.toString()?.replaceAll('g', '').trim() ?? '0') ?? 0).toStringAsFixed(1)}g',
                                style: const TextStyle(fontSize: 16),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _totalConsumed += _selectedAmount;
                          _selectedAmount = 0; // 슬라이더 초기화
                        });
                      },
                      child: const Text('추가'),
                    ),
                  ],
                ),
                const SizedBox(height: 15), // 슬라이더와 총 섭취량 사이 간격
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '총 섭취량: ${_totalConsumed.toStringAsFixed(1)}g',
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(width: 10), // 간격 최소화
                    ElevatedButton(
                      onPressed: _saveConsumptionToFirestore,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,
                      ),
                      child: const Text('저장'),
                    ),
                  ],
                ),
                const SizedBox(height: 20),


                // 섭취 기록 표시
                Text(
                  '섭취 기록',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  height: 300,
                  child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                    stream: FirebaseFirestore.instance
                        .collection('sjsk_users')
                        .doc(FirebaseAuth.instance.currentUser!.email)
                        .collection(DateTime.now().toIso8601String().split('T')[0])
                        .orderBy('timestamp', descending: true)
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      if (snapshot.hasError) {
                        return Center(child: Text('오류 발생: ${snapshot.error}'));
                      }
                      if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                        return const Center(child: Text('저장된 섭취 기록이 없습니다.'));
                      }

                      final records = snapshot.data!.docs;

                      return ListView.builder(
                        controller: _scrollController,
                        itemCount: records.length,
                        itemBuilder: (context, index) {
                          final record = records[index].data();
                          final isExpanded = expandedIndexes.contains(index);

                          return Card(
                            key: itemKeys[index],
                            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            elevation: 3,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      // 👇 이 Expanded 전체가 터치 가능 영역 (삭제 버튼 제외)
                                      Expanded(
                                        child: InkWell(
                                          onTap: () {
                                            setState(() {
                                              if (isExpanded) {
                                                expandedIndexes.remove(index);
                                              } else {
                                                expandedIndexes.add(index);

                                                WidgetsBinding.instance.addPostFrameCallback((_) {
                                                  final context = itemKeys[index].currentContext;
                                                  if (context != null) {
                                                    Scrollable.ensureVisible(
                                                      context,
                                                      duration: Duration(milliseconds: 300),
                                                      curve: Curves.easeInOut,
                                                    );
                                                  }
                                                });
                                              }
                                            });
                                          },
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                record['foodName'] ?? 'Unknown',
                                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                              ),
                                              Text('섭취량: ${record['totalConsumed']}g'),
                                            ],
                                          ),
                                        ),
                                      ),
                                      IconButton(
                                        icon: Icon(Icons.edit, color: Colors.deepPurple),
                                        onPressed: () {
                                          _showEditDialog(snapshot.data!.docs[index]);
                                        },
                                      ),
                                    ],
                                  ),
                                  // 👇 펼쳐지는 내용
                                  AnimatedCrossFade(
                                    duration: const Duration(milliseconds: 250),
                                    crossFadeState: isExpanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
                                    firstChild: SizedBox.shrink(),
                                    secondChild: Padding(
                                      padding: const EdgeInsets.only(top: 8),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text("칼로리: ${record["calories"]} kcal"),
                                          Text("탄수화물: ${record["carbohydrates"]} g"),
                                          Text("단백질: ${record["protein"]} g"),
                                          Text("지방: ${record["fat"]} g"),
                                          Text("당류: ${record["sugars"]} g"),
                                          Text("나트륨: ${record["sodium"]} mg"),
                                          Text("콜레스테롤: ${record["cholesterol"]} mg"),
                                          Text(
                                            "기록 시간: ${(record["timestamp"] as Timestamp).toDate().toLocal()}",
                                            style: const TextStyle(color: Colors.grey),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),


                // // 섭취 기록 표시
                // Text(
                //   '섭취 기록',
                //   style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                // ),
                // const SizedBox(height: 10),
                // SizedBox(
                //   height: 200,
                //   child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                //     stream: FirebaseFirestore.instance
                //         .collection('sjsk_users')
                //         .doc(FirebaseAuth.instance.currentUser!.email)
                //         .collection(DateTime.now().toIso8601String().split('T')[0])
                //         .orderBy('timestamp', descending: true)
                //         .snapshots(),
                //     builder: (context, snapshot) {
                //       if (snapshot.connectionState == ConnectionState.waiting) {
                //         return const Center(child: CircularProgressIndicator());
                //       }
                //       if (snapshot.hasError) {
                //         return Center(child: Text('오류 발생: ${snapshot.error}'));
                //       }
                //       if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                //         return const Center(child: Text('저장된 섭취 기록이 없습니다.'));
                //       }
                //
                //       final records = snapshot.data!.docs;
                //
                //       return ListView.builder(
                //         itemCount: records.length,
                //         itemBuilder: (context, index) {
                //           final record = records[index].data();
                //           return ListTile(
                //             title: Text(record['foodName'] ?? 'Unknown'),
                //             subtitle: Text('총 섭취량: ${record['totalConsumed']}g'),
                //             trailing: Text(
                //               (record['timestamp'] as Timestamp)
                //                   .toDate()
                //                   .toLocal()
                //                   .toString()
                //                   .split(' ')[1],
                //             ),
                //           );
                //         },
                //       );
                //     },
                //   ),
                // ),


              ],
            ),
          ],
        ),
      ),
    );
  }


  Future<void> _loadUserNutrition() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    final snapshot = await FirebaseFirestore.instance
        .collection('sjsk_users')
        .doc(currentUser.email)
        .get();

    if (snapshot.exists) {
      final data = snapshot.data()!;
      setState(() {
        recommendedCalories = (data['calories'] ?? 0).toDouble();
        recommendedCarbs = (data['carbohydrates'] ?? 0).toDouble();
        recommendedProtein = (data['protein'] ?? 0).toDouble();
        recommendedFat = (data['fat'] ?? 0).toDouble();
        recommendedSugars = (data['sugars'] ?? 0).toDouble();
        recommendedSodium = (data['sodium'] ?? 0).toDouble();
        recommendedCholesterol = (data['cholesterol'] ?? 0).toDouble();
      });
    }
  }


  TableRow _buildNutritionRow(String nutrient, dynamic originalAmount, double dailyPercentage) {
    final parsedValue = double.tryParse(originalAmount?.toString() ?? '0') ?? 0.0;

    return TableRow(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(nutrient, textAlign: TextAlign.center),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            '${parsedValue.toStringAsFixed(2)}',
            textAlign: TextAlign.center,
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            '${dailyPercentage.toStringAsFixed(2)}%',
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }

  TableRow _buildAdditionalInfoRow(String label, String value) {
    return TableRow(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(label, textAlign: TextAlign.left),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(value, textAlign: TextAlign.left),
        ),
      ],
    );
  }

  TableRow _buildDynamicNutritionRow(String nutrient, dynamic originalAmount, double dummy) {
    final parsedValue = double.tryParse(originalAmount?.toString() ?? '0') ?? 0.0;
    final adjustedValue = (parsedValue / 100) * _inputWeight;

    // 🔹 권장 섭취량 가져오기
    double recommended = switch (nutrient) {
      '에너지' => recommendedCalories,
      '탄수화물' => recommendedCarbs,
      '단백질' => recommendedProtein,
      '지방' => recommendedFat,
      '당류' => recommendedSugars,
      '나트륨' => recommendedSodium,
      '콜레스테롤' => recommendedCholesterol,
      _ => 0
    };

    final percent = recommended > 0 ? (adjustedValue / recommended * 100) : 0;

    return TableRow(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(nutrient, textAlign: TextAlign.center),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text('${adjustedValue.toStringAsFixed(2)}', textAlign: TextAlign.center),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text('${percent.toStringAsFixed(1)}%', textAlign: TextAlign.center),
        ),
      ],
    );
  }


}


