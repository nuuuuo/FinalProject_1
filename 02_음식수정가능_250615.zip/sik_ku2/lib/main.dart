import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:coniv_3_dream/auth/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import 'firebase_options.dart';
import 'logout_screen.dart';
import 'myPage/my_page.dart';
import 'textSearch.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    print('Firebase 초기화 오류: $e');
    // 이미 초기화된 경우 무시하고 계속 진행
  }
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Sik_ku',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AuthWrapper(),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.active) {
          User? user = snapshot.data;
          if (user == null) {
            return LoginScreen();
          }
          return TabView();
        }
        return Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        );
      },
    );
  }
}

class TabView extends StatefulWidget {
  const TabView({super.key});

  @override
  State<TabView> createState() => _TabViewState();
}

class _TabViewState extends State<TabView> with TickerProviderStateMixin {
  late TabController _tabController;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _navItems.length, vsync: this);
    _tabController.addListener(tabListener);
  }

  @override
  void dispose() {
    _tabController.removeListener(tabListener);
    _tabController.dispose();
    super.dispose();
  }

  void tabListener() {
    setState(() {
      _index = _tabController.index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser; // 현재 로그인된 사용자 정보 가져오기
    final userId = user?.email ?? "Unknown User"; // 사용자 이메일 (없으면 "Unknown User")

    return SafeArea(
      child: Scaffold(


        appBar: PreferredSize(
          preferredSize: Size.fromHeight(90),
          child: Container(
            padding: const EdgeInsets.only(top: 12),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFD2E8C6), Color(0xFFC8E6C9)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            alignment: Alignment.center,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [

                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Icon(Icons.restaurant_menu, color: Color(0xFFE97739), size: 30),
                    Icon(Icons.restaurant, color: Color(0xFFB0885A), size: 32),
                    const SizedBox(width: 10),
                    Row(
                      children: [
                        Text(
                          '식전식',
                          style: TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.w600,
                            // fontFamily: 'Jua',
                            fontFamily: 'MapleBold',
                            color: Color(0xFF4E342E),
                            shadows: [
                              Shadow(offset: Offset(1, 1), blurRadius: 1.5, color: Colors.black26),
                            ],
                          ),
                        ),
                        const SizedBox(width: 4),
                        Stack(
                          alignment: Alignment.center,
                          children: [
                            // 테두리
                            Text(
                              'KU',
                              style: TextStyle(
                                fontSize: 32,
                                fontWeight: FontWeight.w800,
                                // fontFamily: 'Jua',
                                fontFamily: 'MapleBold',
                                foreground: Paint()
                                  ..style = PaintingStyle.stroke
                                  ..strokeWidth = 2
                                  ..color = Color(0xFF4CAF50), // 진한 초록
                              ),
                            ),
                            // 본문
                            Text(
                              'KU',
                              style: TextStyle(
                                fontSize: 32,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFFE97739),
                                // fontFamily: 'Jua',
                                fontFamily: 'MapleBold',
                                shadows: [
                                  Shadow(offset: Offset(1, 1), blurRadius: 1.5, color: Colors.black26),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),

              ],
            ),
          ),
        ),

        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Colors.white,
          selectedItemColor: Colors.black,
          unselectedItemColor: Colors.grey,
          selectedLabelStyle: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 10,
          ),
          unselectedLabelStyle: const TextStyle(
            fontSize: 10,
          ),
          type: BottomNavigationBarType.fixed,
          onTap: (int index) {
            _tabController.animateTo(index);
          },
          currentIndex: _index,
          items: _navItems.map((item) {
            return BottomNavigationBarItem(
              icon: Image.asset(
                item.activeIconPath, // 항상 activeIconPath를 사용
                width: 24,
                height: 24,
                // color: _index == item.index ? null : Colors.grey, // 비활성화 상태일 경우 회색 처리
                // colorBlendMode: BlendMode.modulate, // 색상 변경 적용
              ),
              label: item.label,
            );
          }).toList(),
        ),
        body: TabBarView(
          physics: const NeverScrollableScrollPhysics(),
          controller: _tabController,
          children: [
            const FirstScreen(),
            SecondScreen(),
            MyPage(userId: userId), // MyPage에 사용자 이메일 전달
          ],
        ),
      ),
    );
  }
}

class NavItem {
  final int index;
  final String activeIconPath; // 이미지 경로
  final String label;

  const NavItem({
    required this.index,
    required this.activeIconPath,
    required this.label,
  });
}

const _navItems = [
  NavItem(
    index: 0,
    activeIconPath: 'assets/images/textsearch.png',
    label: '텍스트 검색',
  ),
  NavItem(
    index: 1,
    activeIconPath: 'assets/images/imagesearch.png',
    label: '이미지 검색',
  ),
  NavItem(
    index: 2,
    activeIconPath: 'assets/images/mypage.png',
    label: '마이페이지',
  ),
];

class FirstScreen extends StatefulWidget {
  const FirstScreen({super.key});

  @override
  State<FirstScreen> createState() => Screen2State();

}




class SecondScreen extends StatefulWidget {
  @override
  _SecondScreenState createState() => _SecondScreenState();
}


class _SecondScreenState extends State<SecondScreen> {
  static const platform = MethodChannel('com.doinglab.foodlens2.example');
  bool _isNameLoading = false; //로딩
  String validationMessage = "검증 결과가 여기에 표시됩니다.";
  List<Map<String, dynamic>> searchResults = [];
  List<String> _recognizedFoodNames = []; // 두잉랩 인식 음식 이름 저장 리스트
  List<Map<String, dynamic>> _matchedFoodItems = [];
  List<Map<String, dynamic>> _recognizedFoodItems = [];
  bool _isLoading = false;
  int _currentPage = 1;
  int _totalPages = 0;
  static const int _itemsPerPage = 10;

  @override
  void initState() {
    super.initState();

    platform.setMethodCallHandler((call) async {
      try {
        if (call.method == 'returnValidationResult') {
          setState(() {
            _isNameLoading = true; //  로딩 시작
          });

          final Map<String, dynamic> resultData = Map<String, dynamic>.from(call.arguments);
          print('Flutter가 받은 검증 결과: $resultData');

          final String recognitionJson = resultData['recognitionResults'] ?? '[]';
          final List<dynamic> recognitionList = jsonDecode(recognitionJson);


          // ✅ 두잉랩 인식 결과 처리
          final recognizedItems = recognitionList
              .whereType<Map>()
              .map((e) => Map<String, dynamic>.from(e))
              .toList();
          final recognizedNames = recognizedItems
              .map((e) => e['name']?.toString() ?? '')
              .where((name) => name.isNotEmpty)
              .toList();


          // // ✅ recognitionList → _recognizedFoodItems 저장
          // _recognizedFoodItems = List<Map<String, dynamic>>.from(
          //   recognitionList.whereType<Map>().map((e) => Map<String, dynamic>.from(e)),
          // );
          //
          // // 음식 이름 리스트 추출
          // final List<String> names = recognitionList
          //     .map((e) => e['name']?.toString() ?? '')
          //     .where((name) => name.isNotEmpty)
          //     .toList();

          // 디버그 로그
          for (final item in recognitionList) {
            print("🍳 ${item['name']} / energy=${item['energy']} / carb=${item['carbohydrate']} / protein=${item['protein']}");
          }


          setState(() {
            validationMessage = resultData['message'] ?? '검증 결과 없음';

            // _recognizedFoodNames = names;
            _recognizedFoodItems = recognizedItems;
            _recognizedFoodNames = recognizedNames;

            _matchedFoodItems = List<Map<String, dynamic>>.from(_recognizedFoodItems);
            // _matchedFoodItems = List.generate(_recognizedFoodNames.length, (_) => {});

            // `products`를 JSON 문자열에서 리스트로 변환
            if (resultData.containsKey('products')) {
              if (resultData['products'] is List) {
                searchResults = List<Map<String, dynamic>>.from(
                    resultData['products'].map((e) => Map<String, dynamic>.from(e)));
              } else if (resultData['products'] is String) {
                List<dynamic> jsonList = jsonDecode(resultData['products']);
                searchResults = List<Map<String, dynamic>>.from(jsonList);
              }
            } else {
              searchResults = [];
            }

            // _matchedFoodItems = _recognizedFoodNames.map((name) {
            //   return searchResults.firstWhere(
            //         (item) => item['name'] == name,
            //     orElse: () => {},
            //   );
            // }).toList();

            // 페이지 계산
            _totalPages = (searchResults.length / _itemsPerPage).ceil();
          });

          //
          // for (int i = 0; i < _recognizedFoodNames.length; i++) {
          //   print('🔎 이름 비교: ${_recognizedFoodNames[i]}');
          //   print('👉 매칭된 아이템: ${_matchedFoodItems[i]}');
          // }

          print('📦 baseList: $_recognizedFoodItems');
          for (int i = 0; i < _recognizedFoodNames.length; i++) {
            print('🔎 name: ${_recognizedFoodNames[i]}');
            print('👉 matched: ${_matchedFoodItems[i]}');
          }


          _isNameLoading = false; // 로딩 종료

          print('검증 메시지: $validationMessage');
          print('API 검색 결과: $searchResults');
        }
      } catch (e) {
        print('네이티브 데이터 처리 중 오류 발생: $e');
      }
    });
  }

  Future<void> _invokeGallery() async {
    try {
      await platform.invokeMethod('openGallery');
    } on PlatformException catch (e) {
      print('네이티브 호출 실패: ${e.message}');
    } catch (e) {
      print('알 수 없는 오류 발생: $e');
    }
  }

  Future<void> _invokeCameraAction(String action) async {
    try {
      await platform.invokeMethod(action);
    } on PlatformException catch (e) {
      print('네이티브 호출 실패: ${e.message}');
    } catch (e) {
      print('알 수 없는 오류 발생: $e');
    }
  }


  // Future<void> _showFoodDetailFromIndex(int index) async {
  //   if (index < 0 || index >= _matchedFoodItems.length) {
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       const SnackBar(content: Text("잘못된 인덱스입니다.")),
  //     );
  //     return;
  //   }
  //
  //   final matchedItem = _matchedFoodItems[index];
  //   if (matchedItem.isNotEmpty) {
  //     final Map<String, dynamic> foodItem = {
  //       'FOOD_NM_KR': matchedItem['name'] ?? 'Unknown',
  //       'Z10500': matchedItem['gram'] ?? 100.0,
  //       'AMT_NUM1': matchedItem['energy'],
  //       'AMT_NUM6': matchedItem['carbohydrate'],
  //       'AMT_NUM3': matchedItem['protein'],
  //       'AMT_NUM4': matchedItem['fat'],
  //       'AMT_NUM7': matchedItem['totalSugars'],
  //       'AMT_NUM13': matchedItem['sodium'],
  //       'AMT_NUM23': matchedItem['cholesterol'],
  //     };
  //
  //     Navigator.push(
  //       context,
  //       MaterialPageRoute(
  //         builder: (context) => FoodDetailPage(foodItem: foodItem),
  //       ),
  //     );
  //   } else {
  //     final name = _recognizedFoodNames[index];
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       SnackBar(content: Text("해당 음식($name)의 정보를 찾을 수 없습니다.")),
  //     );
  //   }
  // }


  void _showFoodDetailFromMatched(int index) {
    if (index < 0 || index >= _matchedFoodItems.length) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('잘못된 인덱스 접근입니다.')),
      );
      return;
    }

    final matchedItem = _matchedFoodItems[index];

    if (matchedItem.isEmpty) {
      final name = _recognizedFoodNames[index];
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("해당 음식($name)의 정보를 찾을 수 없습니다.")),
      );
      return;
    }

    final Map<String, dynamic> foodItem = {
      'FOOD_NM_KR': matchedItem['name'] ?? 'Unknown',
      'Z10500': matchedItem['gram'] ?? 100.0,
      'AMT_NUM1': matchedItem['energy'],
      'AMT_NUM6': matchedItem['carbohydrate'],
      'AMT_NUM3': matchedItem['protein'],
      'AMT_NUM4': matchedItem['fat'],
      'AMT_NUM7': matchedItem['totalSugars'],
      'AMT_NUM13': matchedItem['sodium'],
      'AMT_NUM23': matchedItem['cholesterol'],
    };

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => FoodDetailPage(foodItem: foodItem),
      ),
    );
  }


  // Future<void> _showFoodDetailFromFoodLens(String foodName) async {
  //   final matchedItem = _recognizedFoodItems.firstWhere(
  //         (item) => item['name'] == foodName,
  //     orElse: () => {},
  //   );
  //
  //   if (matchedItem.isNotEmpty) {
  //     final Map<String, dynamic> foodItem = {
  //       'FOOD_NM_KR': matchedItem['name'] ?? 'Unknown',
  //       'Z10500': matchedItem['gram'] ?? 100.0,
  //       'AMT_NUM1': matchedItem['energy'],        // 에너지
  //       'AMT_NUM6': matchedItem['carbohydrate'],  // 탄수화물
  //       'AMT_NUM3': matchedItem['protein'],       // 단백질
  //       'AMT_NUM4': matchedItem['fat'],           // 지방
  //       'AMT_NUM7': matchedItem['totalSugars'],   // 당류
  //       'AMT_NUM13': matchedItem['sodium'],       // 나트륨
  //       'AMT_NUM23': matchedItem['cholesterol'],  // 콜레스테롤
  //     };
  //
  //     Navigator.push(
  //       context,
  //       MaterialPageRoute(
  //         builder: (context) => FoodDetailPage(foodItem: foodItem),
  //       ),
  //     );
  //   } else {
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       SnackBar(content: Text("해당 음식($foodName)의 정보를 찾을 수 없습니다.")),
  //     );
  //   }
  // }


  // 수정 다이얼로그 함수
  void _showEditDialog(int index) {
    final TextEditingController _controller = TextEditingController(text: _recognizedFoodNames[index]);
    String selectedCategory = '음식';

    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: Text('음식 이름 수정'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _controller,
                decoration: InputDecoration(labelText: '수정할 음식 이름'),
              ),
              ListTile(
                title: Text('음식'),
                leading: Radio<String>(
                  value: '음식',
                  groupValue: selectedCategory,
                  onChanged: (value) {
                    selectedCategory = value!;
                    (dialogContext as Element).markNeedsBuild();
                  },
                ),
              ),
              ListTile(
                title: Text('원재료성 식품'),
                leading: Radio<String>(
                  value: '원재료성 식품',
                  groupValue: selectedCategory,
                  onChanged: (value) {
                    selectedCategory = value!;
                    (dialogContext as Element).markNeedsBuild();
                  },
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text('취소'),
            ),
            ElevatedButton(
              onPressed: () async {
                final newName = _controller.text.trim();
                if (newName.isEmpty) return;

                final normalizedCategory = selectedCategory == '원재료성 식품' ? '원재료성' : selectedCategory;


                try {
                  final result = await platform.invokeMethod('findProductWithCategory', {
                    'productName': newName,
                    'category': selectedCategory,
                  });

                  Navigator.pop(dialogContext); // ✅ 다이얼로그 닫기

                  if (result != null) {
                    final List<dynamic> itemList = jsonDecode(result);

                    if (itemList.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('"$newName"에 해당하는 "$selectedCategory" 분류 식품을 찾을 수 없습니다.')),
                      );
                      return;
                    }


                    await showDialog(
                      context: context,
                      builder: (context) {
                        return SimpleDialog(
                          title: const Text('제품 선택'),
                          children: [
                            ...itemList.map((item) {
                              final foodName = item['FOOD_NM_KR'] ?? '이름 없음';
                              return SimpleDialogOption(
                                child: Text(foodName),
                                onPressed: () {
                                  Navigator.pop(context);
                                  setState(() {
                                    _recognizedFoodNames[index] = foodName;
                                    // _matchedFoodItems[index] = Map<String, dynamic>.from(item);
                                    _matchedFoodItems[index] = {
                                      'name': item['FOOD_NM_KR'] ?? '',
                                      'gram': item['Z10500'] ?? 100.0,
                                      'energy': item['AMT_NUM1'],
                                      'carbohydrate': item['AMT_NUM6'],
                                      'protein': item['AMT_NUM3'],
                                      'fat': item['AMT_NUM4'],
                                      'totalSugars': item['AMT_NUM7'],
                                      'sodium': item['AMT_NUM13'],
                                      'cholesterol': item['AMT_NUM23'],
                                    };
                                  });
                                },
                              );
                            }),
                            SimpleDialogOption(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const [Icon(Icons.close), SizedBox(width: 4), Text('선택 안 함')],
                              ),
                              onPressed: () => Navigator.pop(context),
                            ),
                          ],
                        );
                      },
                    );



                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('"$newName"에 해당하는 "$selectedCategory" 분류 식품을 찾을 수 없습니다.')),
                    );
                  }
                } catch (e) {
                  print('🔴 예외 발생: $e');
                  Navigator.pop(dialogContext); // 예외 시에도 다이얼로그 닫기
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('검색 중 오류가 발생했습니다.')),
                    );
                  }
                }
              },
              child: Text('확인'),
            ),
          ],
        );
      },
    );
  }


//  수정 다이얼로그 함수, 우선 전체 다 // 없애야함
  // void _showEditDialog(String originalName) {
  //   final TextEditingController _controller = TextEditingController(text: originalName);
  //   String selectedCategory = '음식';
  //
  //   showDialog(
  //     context: context,
  //     builder: (context) {
  //       return AlertDialog(
  //         title: Text('음식 이름 수정'),
  //         content: Column(
  //           mainAxisSize: MainAxisSize.min,
  //           children: [
  //             TextField(
  //               controller: _controller,
  //               decoration: InputDecoration(labelText: '수정할 음식 이름'),
  //             ),
  //             ListTile(
  //               title: Text('음식'),
  //               leading: Radio<String>(
  //                 value: '음식',
  //                 groupValue: selectedCategory,
  //                 onChanged: (value) {
  //                   selectedCategory = value!;
  //                   (context as Element).markNeedsBuild();
  //                 },
  //               ),
  //             ),
  //             ListTile(
  //               title: Text('원재료성 식품'),
  //               leading: Radio<String>(
  //                 value: '원재료성 식품',
  //                 groupValue: selectedCategory,
  //                 onChanged: (value) {
  //                   selectedCategory = value!;
  //                   (context as Element).markNeedsBuild();
  //                 },
  //               ),
  //             ),
  //           ],
  //         ),
  //         actions: [
  //           TextButton(
  //             onPressed: () => Navigator.pop(context),
  //             child: Text('취소'),
  //           ),
  //
  //
  //
  //           ElevatedButton(
  //
  //             onPressed: () async {
  //               final newName = _controller.text.trim();
  //               if (newName.isEmpty) return;
  //
  //               Navigator.pop(context); // ✅ 다이얼로그 먼저 닫기
  //
  //
  //
  //               try {
  //                 final result = await platform.invokeMethod('findProductWithCategory', {
  //                   'productName': newName,
  //                   'category': selectedCategory,
  //                 });
  //
  //                 if (result == null) {
  //                   if (context.mounted) {
  //                     ScaffoldMessenger.of(context).showSnackBar(
  //                       SnackBar(content: Text('"$newName"에 해당하는 "$selectedCategory" 분류 음식을 찾을 수 없습니다.')),
  //                     );
  //                   }
  //                   return; // ❗ 여기서 종료
  //                 }
  //
  //                 final Map<String, dynamic> item = Map<String, dynamic>.from(jsonDecode(result));
  //
  //                 if (item.isNotEmpty) {
  //
  //                   setState(() {
  //                     recognizedFoods[index] = newName; // 리스트 값 업데이트
  //                   });
  //
  //                   Navigator.push(
  //                     context,
  //                     MaterialPageRoute(
  //                       builder: (context) => FoodDetailPage(foodItem: item),
  //                     ),
  //                   );
  //                 } else {
  //                   if (context.mounted) {
  //                     ScaffoldMessenger.of(context).showSnackBar(
  //                       SnackBar(content: Text('"$newName"에 해당하는 "$selectedCategory" 분류 음식을 찾을 수 없습니다.')),
  //                     );
  //                   }
  //                 }
  //               } catch (e) {
  //                 print('🔴 예외 발생: $e');
  //                 if (context.mounted) {
  //                   ScaffoldMessenger.of(context).showSnackBar(
  //                     SnackBar(content: Text('검색 중 오류가 발생했습니다.')),
  //                   );
  //                 }
  //               }
  //
  //
  //               // try {
  //               //   final result = await platform.invokeMethod('findProductWithCategory', {
  //               //     'productName': newName,
  //               //     'category': selectedCategory,
  //               //   });
  //               //
  //               //   // 응답은 JSON 문자열 → Map으로 변환
  //               //   final Map<String, dynamic> item = Map<String, dynamic>.from(jsonDecode(result));
  //               //
  //               //   if (item.isNotEmpty) {
  //               //     Navigator.push(
  //               //       context,
  //               //       MaterialPageRoute(
  //               //         builder: (context) => FoodDetailPage(foodItem: item),
  //               //       ),
  //               //     );
  //               //   } else {
  //               //     if (context.mounted) {
  //               //       ScaffoldMessenger.of(context).showSnackBar(
  //               //         SnackBar(content: Text('"$newName"에 해당하는 "$selectedCategory" 분류 음식을 찾을 수 없습니다.')),
  //               //       );
  //               //     }
  //               //   }
  //               // } catch (e) {
  //               //   print('🔴 예외 발생: $e');
  //               //   if (context.mounted) {
  //               //     ScaffoldMessenger.of(context).showSnackBar(
  //               //       SnackBar(content: Text('검색 중 오류가 발생했습니다.')),
  //               //     );
  //               //   }
  //               // }
  //
  //
  //             },
  //
  //
  //             // onPressed: () async {
  //             //   final newName = _controller.text.trim();
  //             //   if (newName.isEmpty) return;
  //             //
  //             //   Navigator.pop(context); // ✅ 다이얼로그 먼저 닫음
  //             //
  //             //   try {
  //             //     // ✅ 네이티브 메서드 호출 (분류 일치 항목 탐색)
  //             //     final resultJson = await platform.invokeMethod<String>(
  //             //       'findProductWithCategory',
  //             //       {
  //             //         'productName': newName,
  //             //         'category': selectedCategory,
  //             //       },
  //             //     );
  //             //
  //             //     if (resultJson != null) {
  //             //       final Map<String, dynamic> matchedProduct = jsonDecode(resultJson);
  //             //       Navigator.push(
  //             //         context,
  //             //         MaterialPageRoute(
  //             //           builder: (context) => FoodDetailPage(foodItem: matchedProduct),
  //             //         ),
  //             //       );
  //             //     } else {
  //             //       // 일치하는 항목 없음
  //             //       final messenger = ScaffoldMessenger.of(context); // 먼저 참조해두기
  //             //       Navigator.pop(context);
  //             //
  //             //       if (mounted) {
  //             //         ScaffoldMessenger.of(context).showSnackBar(
  //             //           SnackBar(content: Text('오류 메시지')),
  //             //         );
  //             //       }
  //             //
  //             //       // WidgetsBinding.instance.addPostFrameCallback((_) {
  //             //       //   ScaffoldMessenger.of(context).showSnackBar(
  //             //       //     SnackBar(content: Text('"$newName"에 해당하는 "$selectedCategory" 분류 음식을 찾을 수 없습니다.')),
  //             //       //   );
  //             //       // });
  //             //
  //             //     }
  //             //   } catch (e) {
  //             //     print('🔴 오류 발생: $e');
  //             //     WidgetsBinding.instance.addPostFrameCallback((_) {
  //             //       ScaffoldMessenger.of(context).showSnackBar(
  //             //         SnackBar(content: Text('검색 중 오류가 발생했습니다.')),
  //             //       );
  //             //     });
  //             //   }
  //             // },
  //
  //
  //             child: Text('확인'),
  //           ),
  //
  //
  //
  //           // 기존 코드 (주석 처리)
  //           // ElevatedButton(
  //           //   onPressed: () async {
  //           //     final newName = _controller.text.trim();
  //           //     if (newName.isEmpty) return;
  //           //
  //           //     // 이름 목록 업데이트
  //           //     setState(() {
  //           //       final index = _recognizedFoodNames.indexOf(originalName);
  //           //       if (index != -1) _recognizedFoodNames[index] = newName;
  //           //     });
  //           //
  //           //     // API 검색 → DB_GRP_NM 필터 → 첫 결과
  //           //     final filtered = searchResults.where((item) =>
  //           //     item['FOOD_NM_KR'] == newName && item['DB_GRP_NM'] == selectedCategory
  //           //     ).toList();
  //           //
  //           //     for (final item in searchResults) {
  //           //       print("🔍 ${item['FOOD_NM_KR']} | DB_GRP_NM=${item['DB_GRP_NM']}"); ///////
  //           //     }
  //           //
  //           //     if (filtered.isNotEmpty) {
  //           //       Navigator.pop(context);
  //           //       Navigator.push(
  //           //         context,
  //           //         MaterialPageRoute(
  //           //           builder: (context) => FoodDetailPage(foodItem: filtered.first),
  //           //         ),
  //           //       );
  //           //     } else {
  //           //       Navigator.pop(context);
  //           //       ScaffoldMessenger.of(context).showSnackBar(
  //           //         SnackBar(content: Text('"$newName"에 해당하는 "$selectedCategory" 분류 음식을 찾을 수 없습니다.')),
  //           //       );
  //           //     }
  //           //   },
  //           //   child: Text('확인'),
  //           // ),
  //
  //
  //
  //
  //         ],
  //       );
  //     },
  //   );
  // }




  @override
  Widget build(BuildContext context) {
    int startIndex = (_currentPage - 1) * _itemsPerPage;
    int endIndex = startIndex + _itemsPerPage;
    List<Map<String, dynamic>> displayedResults = searchResults.sublist(
      startIndex,
      endIndex > searchResults.length ? searchResults.length : endIndex,
    );

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '이미지 검색',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            // 상단 버튼
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _invokeCameraAction('openCamera'),
                    icon: const Icon(Icons.camera_alt, color: Colors.black87, size: 20),
                    label: const Text("카메라 열기", style: TextStyle(fontSize: 16, color: Colors.black87)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green[300],
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      elevation: 4,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _invokeGallery,
                    icon: const Icon(Icons.photo_library, color: Colors.black87, size: 20),
                    label: const Text("갤러리 열기", style: TextStyle(fontSize: 16, color: Colors.black87)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange[300],
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      elevation: 4,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // 로딩 인디케이터
            if (_isNameLoading)
              const Center(child: CircularProgressIndicator()),

            // 두잉랩 인식 음식 출력
            if (_recognizedFoodNames.isNotEmpty) ...[
              const Text("🍽 두잉랩 인식 음식", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),


              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: _recognizedFoodNames.asMap().entries.map((entry) {
                  final index = entry.key;
                  final name = entry.value;

                  return Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(


                        child: GestureDetector(


                          onTap: () {
                            if (index < 0 || index >= _matchedFoodItems.length) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('잘못된 인덱스 접근입니다.')),
                              );
                              return;
                            }

                            final matchedItem = _matchedFoodItems[index];

                            if (matchedItem.isEmpty) {
                              final name = _recognizedFoodNames[index];
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text("해당 음식($name)의 정보를 찾을 수 없습니다.")),
                              );
                              return;
                            }

                            final foodItem = {
                              'FOOD_NM_KR': matchedItem['name'] ?? 'Unknown',
                              'Z10500': matchedItem['gram'] ?? 100.0,
                              'AMT_NUM1': matchedItem['energy'],
                              'AMT_NUM6': matchedItem['carbohydrate'],
                              'AMT_NUM3': matchedItem['protein'],
                              'AMT_NUM4': matchedItem['fat'],
                              'AMT_NUM7': matchedItem['totalSugars'],
                              'AMT_NUM13': matchedItem['sodium'],
                              'AMT_NUM23': matchedItem['cholesterol'],
                            };

                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => FoodDetailPage(foodItem: foodItem),
                              ),
                            );
                          },




                          // onTap: () {
                          //   // final matchedItem = _matchedFoodItems[index];
                          //   final name = _recognizedFoodNames[index];
                          //   _showFoodDetailFromFoodLens(name);
                          //
                          //   // if (matchedItem.isNotEmpty) {
                          //   //   Navigator.push(
                          //   //     context,
                          //   //     MaterialPageRoute(
                          //   //       builder: (context) => FoodDetailPage(foodItem: matchedItem),
                          //   //     ),
                          //   //   );
                          //   // } else {
                          //   //   ScaffoldMessenger.of(context).showSnackBar(
                          //   //     SnackBar(content: Text("해당 음식($name)의 정보를 찾을 수 없습니다.")),
                          //   //   );
                          //   // }
                          // },
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 12.0),
                            margin: const EdgeInsets.symmetric(vertical: 4.0),
                            decoration: BoxDecoration(
                              color: Color(0xFFF3F3F7),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.grey.shade300),
                            ),
                            child: Text(
                              name,
                              style: const TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w500,
                                color: Colors.black87,
                              ),
                            ),
                          ),
                        ),


                        // child: GestureDetector(
                        //   onTap: () => _showFoodDetailFromFoodLens(name),
                        //   child: Container(
                        //     width: double.infinity,
                        //     padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 12.0),
                        //     margin: const EdgeInsets.symmetric(vertical: 4.0),
                        //     decoration: BoxDecoration(
                        //       color: Color(0xFFF3F3F7),
                        //       borderRadius: BorderRadius.circular(8),
                        //       border: Border.all(color: Colors.grey.shade300),
                        //     ),
                        //     child: Text(
                        //       name,
                        //       style: const TextStyle(
                        //         fontSize: 17,
                        //         fontWeight: FontWeight.w500,
                        //         color: Colors.black87,
                        //       ),
                        //     ),
                        //   ),
                        // ),
                      ),
                      IconButton(
                        icon: Icon(Icons.edit, color: Colors.grey[600]),
                        onPressed: () => _showEditDialog(index),
                      ),
                    ],
                  );
                }).toList(),
              ),


              // Column(
              //   crossAxisAlignment: CrossAxisAlignment.start,
              //   children: _recognizedFoodNames.map((name) {
              //     return Row(
              //       crossAxisAlignment: CrossAxisAlignment.center,
              //       children: [
              //         Expanded(
              //           child: GestureDetector(
              //             onTap: () => _showFoodDetailFromFoodLens(name),
              //             child: Container(
              //               width: double.infinity,
              //               padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 12.0),
              //               margin: const EdgeInsets.symmetric(vertical: 4.0),
              //               decoration: BoxDecoration(
              //                 color: Color(0xFFF3F3F7),
              //                 borderRadius: BorderRadius.circular(8),
              //                 border: Border.all(color: Colors.grey.shade300),
              //               ),
              //               child: Text(
              //                 name,
              //                 style: const TextStyle(
              //                   fontSize: 17,
              //                   fontWeight: FontWeight.w500,
              //                   color: Colors.black87,
              //                 ),
              //               ),
              //             ),
              //           ),
              //         ),
              //         IconButton(
              //           icon: Icon(Icons.edit, color: Colors.grey[600]),
              //           onPressed: () => _showEditDialog(name),
              //         ),
              //       ],
              //     );
              //   }).toList(),
              // ),

              // Column(
              //   crossAxisAlignment: CrossAxisAlignment.start,
              //   children: _recognizedFoodNames.map((name) {
              //     return GestureDetector(
              //       onTap: () => _showFoodDetailFromFoodLens(name),
              //       child: Container(
              //         width: double.infinity,
              //         padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 12.0),
              //         margin: const EdgeInsets.symmetric(vertical: 4.0),
              //         decoration: BoxDecoration(
              //           color: Color(0xFFF3F3F7),
              //           borderRadius: BorderRadius.circular(8),
              //           border: Border.all(color: Colors.grey.shade300),
              //         ),
              //         child: Text(
              //           name,
              //           style: const TextStyle(
              //             fontSize: 17,
              //             fontWeight: FontWeight.w500,
              //             color: Colors.black87,
              //           ),
              //         ),
              //       ),
              //     );
              //   }).toList(),
              // ),


              const SizedBox(height: 20),
            ],




            // OCR 메시지 출력
            if (validationMessage.trim().isNotEmpty &&
                validationMessage.trim() != "검증 결과가 여기에 표시됩니다.") ...[
              const Text("📋 OCR 탐색 결과", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(
                validationMessage,
                style: const TextStyle(fontSize: 16, color: Colors.blue),
              ),
              const SizedBox(height: 20),
            ],


            // 로딩 or 결과 표시
            if (_isLoading)
              const Center(child: CircularProgressIndicator())
            else if (searchResults.isEmpty)
              const Text('검색 결과가 없습니다.', style: TextStyle(fontSize: 16))
            else
              Expanded(
                child: Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                        itemCount: displayedResults.length,
                        itemBuilder: (context, index) {
                          return ListTile(
                            title: Text(displayedResults[index]['FOOD_NM_KR'] ?? 'N/A'),
                            subtitle: Text("제조사: ${displayedResults[index]['MAKER_NM'] ?? 'N/A'}"),
                            onTap: () {
                              final foodItem = Map<String, dynamic>.from(displayedResults[index]);
                              print("🧾 전달할 foodItem: $foodItem");
                              print("🧾 키 목록: ${foodItem.keys}");
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => FoodDetailPage(foodItem: foodItem),
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        _totalPages,
                            (index) => InkWell(
                          onTap: () {
                            setState(() {
                              _currentPage = index + 1;
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              '${index + 1}',
                              style: TextStyle(
                                fontWeight: _currentPage == index + 1
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                                color: _currentPage == index + 1
                                    ? Colors.blue
                                    : Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }




}


class FoodDetailPage extends StatefulWidget {
  final Map<String, dynamic> foodItem;

  const FoodDetailPage({super.key, required this.foodItem});

  @override
  _FoodDetailPageState createState() => _FoodDetailPageState();
}

class _FoodDetailPageState extends State<FoodDetailPage> {
  double _selectedAmount = 0;
  double _totalConsumed = 0;
  double _inputWeight = 100.0;

  double recommendedCalories = 0.0;
  double recommendedCarbs = 0.0;
  double recommendedProtein = 0.0;
  double recommendedFat = 0.0;
  double recommendedSugars = 0.0;
  double recommendedSodium = 0.0;
  double recommendedCholesterol = 0.0;

  final TextEditingController _weightController = TextEditingController(text: '100');
  final ScrollController _scrollController = ScrollController();

  // 상태 추적을 위해 추가
  Set<int> expandedIndexes = {};
  final List<GlobalKey> itemKeys = [];

  late Map<String, dynamic> foodItem;

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    final weightText = widget.foodItem['Z10500']?.toString()?.replaceAll('g', '').trim() ?? '100';
    final parsedWeight = double.tryParse(weightText) ?? 100.0;

    _inputWeight = parsedWeight;
    _weightController.text = parsedWeight % 1 == 0
        ? parsedWeight.toStringAsFixed(0)
        : parsedWeight.toStringAsFixed(1);

    _loadUserNutrition();

    itemKeys.addAll(List.generate(100, (_) => GlobalKey()));
  }

  Future<void> _loadUserNutrition() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    final snapshot = await FirebaseFirestore.instance
        .collection('sjsk_users')
        .doc(currentUser.email)
        .get();

    if (snapshot.exists) {
      final data = snapshot.data()!;
      setState(() {
        recommendedCalories = (data['calories'] ?? 0).toDouble();
        recommendedCarbs = (data['carbohydrates'] ?? 0).toDouble();
        recommendedProtein = (data['protein'] ?? 0).toDouble();
        recommendedFat = (data['fat'] ?? 0).toDouble();
        recommendedSugars = (data['sugars'] ?? 0).toDouble();
        recommendedSodium = (data['sodium'] ?? 0).toDouble();
        recommendedCholesterol = (data['cholesterol'] ?? 0).toDouble();
      });
    }
  }


  Future<void> _saveConsumptionToFirestore() async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    final today = DateTime.now().toIso8601String().split('T')[0];

    double consumedAmount = _totalConsumed;

    double calculateNutrient(dynamic value) {
      final originalValue = value is num
          ? value.toDouble()
          : double.tryParse(value?.toString() ?? '0') ?? 0.0;
      return (originalValue / 100) * _inputWeight;
    }

    double calories = calculateNutrient(widget.foodItem['AMT_NUM1']); // 칼로리
    double carbohydrates = calculateNutrient(widget.foodItem['AMT_NUM6']); // 탄수화물
    double protein = calculateNutrient(widget.foodItem['AMT_NUM3']); // 단백질
    double fat = calculateNutrient(widget.foodItem['AMT_NUM4']); // 지방
    double sugars = calculateNutrient(widget.foodItem['AMT_NUM7']); // 당류
    double sodium = calculateNutrient(widget.foodItem['AMT_NUM13']); // 나트륨
    double cholesterol = calculateNutrient(widget.foodItem['AMT_NUM23']); // 콜레스테롤

    try {
      await FirebaseFirestore.instance
          .collection('sjsk_users')
          .doc(currentUser.email)
          .collection(today)
          .add({
        'foodName': widget.foodItem['FOOD_NM_KR'] ?? 'Unknown',
        'totalConsumed': consumedAmount.toStringAsFixed(1),
        'calories': calories.toStringAsFixed(1),
        'carbohydrates': carbohydrates.toStringAsFixed(1),
        'protein': protein.toStringAsFixed(1),
        'fat': fat.toStringAsFixed(1),
        'sugars': sugars.toStringAsFixed(1),
        'sodium': sodium.toStringAsFixed(1),
        'cholesterol': cholesterol.toStringAsFixed(1),
        'timestamp': Timestamp.now(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('섭취 기록이 저장되었습니다!')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('저장 중 오류 발생: $e')),
      );
    }
  }

  TableRow _buildDynamicNutritionRow(String nutrient, dynamic originalAmount) {
    final parsedValue = originalAmount is num
        ? originalAmount.toDouble()
        : double.tryParse(originalAmount?.toString() ?? '0') ?? 0.0;
    // final parsedValue = originalAmount is num ? originalAmount.toDouble() : 0.0;
    final adjustedValue = (parsedValue / 100) * _inputWeight;

    double recommended = switch (nutrient) {
      '에너지' => recommendedCalories,
      '탄수화물' => recommendedCarbs,
      '단백질' => recommendedProtein,
      '지방' => recommendedFat,
      '당류' => recommendedSugars,
      '나트륨' => recommendedSodium,
      '콜레스테롤' => recommendedCholesterol,
      _ => 0,
    };

    final percent = recommended > 0 ? (adjustedValue / recommended * 100) : 0;

    return TableRow(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(nutrient, textAlign: TextAlign.center),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text('${adjustedValue.toStringAsFixed(2)}', textAlign: TextAlign.center),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text('${percent.toStringAsFixed(1)}%', textAlign: TextAlign.center),
        ),
      ],
    );
  }

  TableRow _buildAdditionalInfoRow(String label, String value) {
    return TableRow(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(label, textAlign: TextAlign.left),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(value, textAlign: TextAlign.left),
        ),
      ],
    );
  }


  void _showEditDialog(DocumentSnapshot<Map<String, dynamic>> doc) {
    final record = doc.data()!;
    final foodNameController = TextEditingController(text: record['foodName']);
    final amountController = TextEditingController(text: record['totalConsumed']);
    final caloriesController = TextEditingController(text: record['calories']);
    final carbsController = TextEditingController(text: record['carbohydrates']);
    final proteinController = TextEditingController(text: record['protein']);
    final fatController = TextEditingController(text: record['fat']);
    final sugarsController = TextEditingController(text: record['sugars']);
    final sodiumController = TextEditingController(text: record['sodium']);
    final cholesterolController = TextEditingController(text: record['cholesterol']);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("섭취 기록 수정"),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildTextField('음식명', foodNameController),
              _buildTextField('섭취량(g)', amountController),
              _buildTextField('칼로리(kcal)', caloriesController),
              _buildTextField('탄수화물(g)', carbsController),
              _buildTextField('단백질(g)', proteinController),
              _buildTextField('지방(g)', fatController),
              _buildTextField('당류(g)', sugarsController),
              _buildTextField('나트륨(mg)', sodiumController),
              _buildTextField('콜레스테롤(mg)', cholesterolController),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("취소"),
          ),
          TextButton(
            onPressed: () async {
              await doc.reference.delete();
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("기록이 삭제되었습니다.")));
            },
            child: const Text("삭제", style: TextStyle(color: Colors.red)),
          ),
          ElevatedButton(
            onPressed: () async {
              await doc.reference.update({
                'foodName': foodNameController.text,
                'totalConsumed': amountController.text,
                'calories': caloriesController.text,
                'carbohydrates': carbsController.text,
                'protein': proteinController.text,
                'fat': fatController.text,
                'sugars': sugarsController.text,
                'sodium': sodiumController.text,
                'cholesterol': cholesterolController.text,
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("기록이 수정되었습니다.")));
            },
            child: const Text("저장"),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(),
          isDense: true,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final foodItem = widget.foodItem;
    final double maxWeightRaw = double.tryParse(foodItem['Z10500']?.toString()?.replaceAll('g', '') ?? '0') ?? 100.0;
    final double maxWeight = maxWeightRaw > 0 ? maxWeightRaw : 100.0;
    final String formattedWeight = maxWeight % 1 == 0 ? maxWeight.toStringAsFixed(0) : maxWeight.toStringAsFixed(1);

    return Scaffold(
      appBar: AppBar
        (title: const Text('식품 상세 정보'),
        backgroundColor: const Color(0xFF9CAF88),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '"${foodItem['FOOD_NM_KR'] ?? 'N/A'}"의 영양성분',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),

            // ✅ 입력 필드 추가된 헤더
            Table(
              border: TableBorder.all(),
              columnWidths: const {
                0: FlexColumnWidth(0.8),
                1: FlexColumnWidth(1.2),
                2: FlexColumnWidth(1.5),
              },
              children: [
                TableRow(
                  decoration: const BoxDecoration(color: Colors.grey),
                  children: [
                    const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text('영양성분', textAlign: TextAlign.center),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _weightController,
                              keyboardType: TextInputType.number,
                              textAlign: TextAlign.center,
                              decoration: const InputDecoration(
                                border: OutlineInputBorder(),
                                contentPadding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                                hintText: 'g',
                              ),
                              onChanged: (value) {
                                setState(() {
                                  _inputWeight = double.tryParse(value) ?? 100.0;
                                });
                              },
                            ),
                          ),
                          const Text('g 당 함량'),
                        ],
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text('1일 영양섭취 기준(%)', textAlign: TextAlign.center),
                    ),
                  ],
                ),
                _buildDynamicNutritionRow('에너지', foodItem['AMT_NUM1']),
                _buildDynamicNutritionRow('탄수화물', foodItem['AMT_NUM6']),
                _buildDynamicNutritionRow('단백질', foodItem['AMT_NUM3']),
                _buildDynamicNutritionRow('지방', foodItem['AMT_NUM4']),
                _buildDynamicNutritionRow('당류', foodItem['AMT_NUM7']),
                _buildDynamicNutritionRow('나트륨', foodItem['AMT_NUM13']),
                _buildDynamicNutritionRow('콜레스테롤', foodItem['AMT_NUM23']),
              ],
            ),
            const SizedBox(height: 16),

            // 부가정보 표
            Text('부가 정보', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Table(
              border: TableBorder.all(),
              children: [
                _buildAdditionalInfoRow('식품명', foodItem['FOOD_NM_KR'] ?? 'N/A'),
                _buildAdditionalInfoRow('제조사명', foodItem['MAKER_NM'] ?? 'N/A'),
                _buildAdditionalInfoRow('식품 중량', '${formattedWeight}g'),
                _buildAdditionalInfoRow('1회 섭취참고량', foodItem['NUTRI_AMOUNT_SERVING'] ?? 'N/A'),
                _buildAdditionalInfoRow('품목제조보고번호', foodItem['ITEM_REPORT_NO'] ?? 'N/A'),
              ],
            ),
            const SizedBox(height: 16),

            // 슬라이더 + 텍스트 + 저장 버튼
            Column(
              children: [
                // 슬라이더 + 추가 버튼
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(
                      child: Column(
                        children: [
                          Slider(
                            value: _selectedAmount,
                            min: 0,
                            max: foodItem['Z10500'] != null
                                ? double.tryParse(foodItem['Z10500'].toString().replaceAll('g', '').trim()) ?? 1.0
                                : 1.0,
                            divisions: foodItem['Z10500'] != null
                                ? (double.tryParse(foodItem['Z10500'].toString().replaceAll('g', '').trim())?.toInt() ?? 1)
                                : null,
                            label: '${_selectedAmount.toStringAsFixed(1)}g',
                            onChanged: (value) {
                              setState(() {
                                _selectedAmount = value;
                                _inputWeight = value;
                                _weightController.text = value.toStringAsFixed(1);
                              });
                            },
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('0g', style: TextStyle(fontSize: 16)),
                              Text(
                                '${(double.tryParse(foodItem['Z10500']?.toString()?.replaceAll('g', '')?.trim() ?? '0') ?? 0).toStringAsFixed(1)}g',
                                style: const TextStyle(fontSize: 16),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _totalConsumed += _selectedAmount;
                          _selectedAmount = 0;
                        });
                      },
                      style: ElevatedButton.styleFrom(
                        // backgroundColor: Colors.white,
                        // foregroundColor: Colors.deepPurple,
                        elevation: 2,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(24), // 약간 둥근 느낌
                          // side: const BorderSide(
                          //   // color: Color(0xFFB39DDB), // 연보라 테두리
                          //   width: 1.5,
                          // ),
                        ),
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                      ),


                      child: const Text('추가'),
                    ),
                  ],
                ),

                const SizedBox(height: 15),

                // 총 섭취량 + 저장 버튼
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '총 섭취량: ${_totalConsumed.toStringAsFixed(1)}g',
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(width: 10), // 간격 최소화
                    ElevatedButton(
                      onPressed: _saveConsumptionToFirestore,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,
                      ),
                      child: const Text('저장'),
                    ),
                  ],
                ),
                const SizedBox(height: 20),



                // 섭취 기록 표시
                Text(
                  '섭취 기록',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  height: 300,
                  child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                    stream: FirebaseFirestore.instance
                        .collection('sjsk_users')
                        .doc(FirebaseAuth.instance.currentUser!.email)
                        .collection(DateTime.now().toIso8601String().split('T')[0])
                        .orderBy('timestamp', descending: true)
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      if (snapshot.hasError) {
                        return Center(child: Text('오류 발생: ${snapshot.error}'));
                      }
                      if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                        return const Center(child: Text('저장된 섭취 기록이 없습니다.'));
                      }

                      final records = snapshot.data!.docs;

                      return ListView.builder(
                        controller: _scrollController,
                        itemCount: records.length,
                        itemBuilder: (context, index) {
                          final record = records[index].data();
                          final isExpanded = expandedIndexes.contains(index);

                          return Card(
                            key: itemKeys[index],
                            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            elevation: 3,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      // 👇 이 Expanded 전체가 터치 가능 영역 (삭제 버튼 제외)
                                      Expanded(
                                        child: InkWell(
                                          onTap: () {
                                            setState(() {
                                              if (isExpanded) {
                                                expandedIndexes.remove(index);
                                              } else {
                                                expandedIndexes.add(index);

                                                WidgetsBinding.instance.addPostFrameCallback((_) {
                                                  final context = itemKeys[index].currentContext;
                                                  if (context != null) {
                                                    Scrollable.ensureVisible(
                                                      context,
                                                      duration: Duration(milliseconds: 300),
                                                      curve: Curves.easeInOut,
                                                    );
                                                  }
                                                });
                                              }
                                            });
                                          },
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                record['foodName'] ?? 'Unknown',
                                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                              ),
                                              Text('섭취량: ${record['totalConsumed']}g'),
                                            ],
                                          ),
                                        ),
                                      ),
                                      IconButton(
                                        icon: Icon(Icons.edit, color: Colors.deepPurple),
                                        onPressed: () {
                                          _showEditDialog(snapshot.data!.docs[index]);
                                        },
                                      ),
                                    ],
                                  ),
                                  // 👇 펼쳐지는 내용
                                  AnimatedCrossFade(
                                    duration: const Duration(milliseconds: 250),
                                    crossFadeState: isExpanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
                                    firstChild: SizedBox.shrink(),
                                    secondChild: Padding(
                                      padding: const EdgeInsets.only(top: 8),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text("칼로리: ${record["calories"]} kcal"),
                                          Text("탄수화물: ${record["carbohydrates"]} g"),
                                          Text("단백질: ${record["protein"]} g"),
                                          Text("지방: ${record["fat"]} g"),
                                          Text("당류: ${record["sugars"]} g"),
                                          Text("나트륨: ${record["sodium"]} mg"),
                                          Text("콜레스테롤: ${record["cholesterol"]} mg"),
                                          Text(
                                            "기록 시간: ${(record["timestamp"] as Timestamp).toDate().toLocal()}",
                                            style: const TextStyle(color: Colors.grey),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),


              ],
            ),
          ],
        ),
      ),
    );
  }
}




//로그인+텍스트검색 합본_241202