import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:coniv_3_dream/main.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SignUpScreen extends StatefulWidget {
  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _nicknameController = TextEditingController();
  final TextEditingController _departmentController = TextEditingController();

  Future<void> _signUp() async {
    try {
      UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailController.text,
        password: _passwordController.text,
      );

      if (userCredential.user != null) {
        String userId = userCredential.user!.uid;
        String nickname = _nicknameController.text;
        String department = _departmentController.text;

        // userInfo 컬렉션에 데이터 저장
        await FirebaseFirestore.instance
            .collection('userInfo')
            .doc(userId)
            .set({
          'nickname': nickname,
          'department': department,
        });

        // 회원가입 성공 후 TabView로 이동
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => TabView()));
      } else {
        throw Exception('회원가입에 실패했습니다.');
      }
    } on FirebaseAuthException catch (e) {
      String errorMessage = '회원가입에 실패했습니다.';
      if (e.code == 'weak-password') {
        errorMessage = '비밀번호가 너무 약합니다.';
      } else if (e.code == 'email-already-in-use') {
        errorMessage = '이미 사용 중인 이메일 주소입니다.';
      }
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(errorMessage)));
    } catch (e) {
      print('회원가입 오류: $e');
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('회원가입 중 오류가 발생했습니다.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF54D42A),
        iconTheme: IconThemeData(
          color: Colors.white, // 화살표 아이콘 색상을 흰색으로 설정
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context); // 뒤로 가기 기능
          },
        ),
        title: Text(
          '회원가입',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus(); // 키보드 숨기기
        },
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 30.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: 80),
                CircleAvatar(
                  radius: 120,
                  backgroundColor: Colors.grey[200],
                  child: Icon(
                    Icons.person,
                    size: 170,
                    color: Colors.black54,
                  ),
                ),
                SizedBox(height: 80),
                TextField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: '아이디',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.emailAddress,
                ),
                SizedBox(height: 20),
                TextField(
                  controller: _passwordController,
                  decoration: InputDecoration(
                    labelText: '패스워드',
                    border: OutlineInputBorder(),
                  ),
                  obscureText: true,
                ),
                SizedBox(height: 20),
                TextField(
                  controller: _nicknameController,
                  decoration: InputDecoration(
                    labelText: '닉네임',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: _departmentController,
                  decoration: InputDecoration(
                    labelText: '대학 및 학과명',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 40),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: ElevatedButton(
                    onPressed: _signUp,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF54D42A),
                      shape: RoundedRectangleBorder(
                        borderRadius:
                        BorderRadius.circular(8), // 모서리를 덜 둥글게 설정 (값을 조절해보세요)
                      ),
                      minimumSize: Size(double.infinity, 50),
                    ),
                    child: Text(
                      '가입하기',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 23,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
