import 'package:coniv_3_dream/main.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:coniv_3_dream/auth/signup_screen.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  Future<void> _login() async {
    try {
      UserCredential userCredential =
          await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _emailController.text,
        password: _passwordController.text,
      );
      Navigator.of(context)
          .pushReplacement(MaterialPageRoute(builder: (context) => TabView()));
    } on FirebaseAuthException catch (e) {
      String errorMessage = '로그인에 실패했습니다.';
      if (e.code == 'user-not-found') {
        errorMessage = '해당 이메일로 등록된 사용자가 없습니다.';
      } else if (e.code == 'wrong-password') {
        errorMessage = '잘못된 비밀번호입니다.';
      }
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(errorMessage)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus(); // 키보드 숨기기
        },
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(60.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: 50.0),
                Text(
                  '식전식KU',
                  style: TextStyle(
                    fontSize: 60,
                    color: Color(0xFF54D42A),
                    //color: Color(0xFF63BBFA),
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 120),
                TextField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: '아이디',
                    labelStyle: TextStyle(fontSize: 25),
                  ),
                  keyboardType: TextInputType.emailAddress,
                ),
                SizedBox(height: 5.0),
                TextField(
                  controller: _passwordController,
                  decoration: InputDecoration(
                    labelText: '패스워드',
                    labelStyle: TextStyle(fontSize: 25),
                  ),
                  obscureText: true,
                ),
                SizedBox(height: 40.0),
                ElevatedButton(
                  onPressed: _login,
                  child: Text(
                    '로그인',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 23,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF54D42A),
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(8), // 모서리를 덜 둥글게 설정 (값을 조절해보세요)
                    ),
                    minimumSize: Size(double.infinity, 50),
                  ),
                ),
                SizedBox(height: 10.0),
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => SignUpScreen()));
                  },
                  child: Row(
                    children: [
                      Text(
                        '회원가입',
                        style: TextStyle(
                          fontSize: 15,
                          color: Colors.grey,
                          decoration: TextDecoration.underline,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
