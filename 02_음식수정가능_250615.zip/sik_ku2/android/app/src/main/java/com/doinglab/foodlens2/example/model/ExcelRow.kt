package com.doinglab.foodlens2.example.model

import com.alibaba.excel.annotation.ExcelProperty

data class ExcelRow(
    @ExcelProperty("품목제조보고번호")
    var itemReportNo: String? = null,

    @ExcelProperty("식품명")
    var foodName: String? = null
) {
    override fun toString(): String {
        return "ExcelRow(itemReportNo=$itemReportNo, foodName=$foodName)"
    }
}