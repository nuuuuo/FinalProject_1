package com.doinglab.foodlens2.example

import android.Manifest
import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.util.Log
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.databinding.DataBindingUtil
import com.doinglab.foodlens2.example.databinding.ActivityMainBinding
import com.doinglab.foodlens2.example.listview.ListItem
import com.doinglab.foodlens2.example.listview.SampleListAdapter
import com.doinglab.foodlens2.example.util.Utils
import com.doinglab.foodlens2.sdk.FoodLens
import com.doinglab.foodlens2.sdk.RecognitionResultHandler
import com.doinglab.foodlens2.sdk.config.LanguageConfig
import com.doinglab.foodlens2.sdk.errors.BaseError
import com.doinglab.foodlens2.sdk.model.RecognitionResult
import java.io.File


class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.doinglab.foodlens2.example"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "startFoodLens" -> {
                    // CameraActivity 호출
                    startFoodLensActivity()
                    result.success("Started FoodLens in MainActivity")
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun startFoodLensActivity() {
        val intent = Intent(this, CameraActivity::class.java)
        startActivity(intent)
    }
}



class CameraActivity : AppCompatActivity() {
    private var currentPhotoUri: Uri? = null
    private var currentPhotoPath: String = ""
    private var originBitmap: Bitmap? = null

    private val mCameraForResult: ActivityResultLauncher<Uri> =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) {
                Toast.makeText(this, "Image captured successfully", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Failed to capture image", Toast.LENGTH_SHORT).show()
            }
        }

    private val mGalleryForResult: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val uri = result.data?.data
                uri?.let {
                    Toast.makeText(this, "Image selected: $it", Toast.LENGTH_SHORT).show()
                    // 추가 로직: 선택한 이미지 처리
                }
            } else {
                Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera) // 레이아웃 설정
        checkAndRequestPermissions()

        // 버튼 초기화
        val cameraButton: Button = findViewById(R.id.btn_open_camera)
        val galleryButton: Button = findViewById(R.id.btn_open_gallery)

        cameraButton.setOnClickListener {
            openCamera()
        }

        galleryButton.setOnClickListener {
            openGallery()
        }
    }

    private fun checkAndRequestPermissions() {
        val permissions = arrayOf(Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE)

        val deniedPermissions = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (deniedPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, deniedPermissions.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }

    private fun openCamera() {
        val imageFile = createImageFile()
        currentPhotoUri = FileProvider.getUriForFile(
            this,
            "${applicationContext.packageName}.fileprovider",
            imageFile
        )

        currentPhotoUri?.let { uri ->
            mCameraForResult.launch(uri)
        } ?: run {
            Toast.makeText(this, "Failed to get image URI", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        mGalleryForResult.launch(intent)
    }

    private fun createImageFile(): File {
        val imageFileName = "JPEG_Image"
        val imagePath: File? = getExternalFilesDir("images")

        val newFile: File = File.createTempFile(imageFileName, ".jpg", imagePath)
        currentPhotoPath = newFile.absolutePath
        return newFile
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                Toast.makeText(this, "Permissions granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Permissions denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        private const val PERMISSION_REQUEST_CODE = 1001
    }
}





//class MainActivity : FlutterActivity() {
//    private val CHANNEL = "com.doinglab.foodlens2.example"
//    private lateinit var activityResultHelper: ActivityResultHelper
//
//    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
//        super.configureFlutterEngine(flutterEngine)
//        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
//            when (call.method) {
//                "startFoodLens" -> {
//                    startFoodLens()
//                    result.success("FoodLens started")
//                }
//                else -> result.notImplemented()
//            }
//        }
//    }
//
//    private fun startFoodLens() {
//        activityResultHelper.openCamera()
//    }
//
//    lateinit var binding: ActivityMainBinding
//
//    private val foodLensService by lazy {
//        FoodLens.createFoodLensService(this@MainActivity)
//    }
//
//    private val listAdapter by lazy {
//        SampleListAdapter()
//    }
//
//    private var originBitmap: Bitmap? = null
//
//    private val loadingDialog by lazy {
//        Dialog(this@MainActivity)
//    }
//
//    var currentPhotoUri: Uri? = null
//    var currentPhotoPath = ""
//
//    private val selLanguage = arrayOf("en", "ko")
//    private val selOrientation = arrayOf("true", "false")
//
//    private fun predictFood(imagePath: String, result: MethodChannel.Result) {
//        try {
//            val byteData = File(imagePath).readBytes() // 이미지 파일을 바이트 배열로 읽기
//            loadingDialog.show()
//
//            foodLensService.predict(byteData, object : RecognitionResultHandler {
//                override fun onSuccess(recognitionResult: RecognitionResult?) {
//                    loadingDialog.dismiss()
//
//                    val foodNames = recognitionResult?.foodInfoList?.map { it.name } ?: emptyList()
//                    result.success(foodNames) // 결과를 Flutter로 반환
//                }
//
//                override fun onError(errorReason: BaseError?) {
//                    loadingDialog.dismiss()
//                    Log.e("FoodLens", "Error: ${errorReason?.getMessage()}")
//                    result.error("PREDICT_ERROR", errorReason?.getMessage(), null)
//                }
//            })
//        } catch (e: Exception) {
//            loadingDialog.dismiss()
//            Log.e("FoodLens", "Prediction failed: ${e.message}")
//            result.error("PREDICT_EXCEPTION", e.message, null)
//        }
//    }
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        configureFlutterEngine(FlutterEngine(this))
//        binding = ActivityMainBinding.inflate(layoutInflater)
//        setContentView(binding.root)
//        requestPermission()
//
//        binding.list.adapter = listAdapter
//
//        loadingDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        loadingDialog.setContentView(ProgressBar(this))
//
//        binding.tvSetLanguage.text = "Language : ${foodLensService.getLanguage()}"
//        binding.tvSetRotation.text = "Rotation Auto : ${foodLensService.getAutoRotate()}"
//
//        binding.btnRunFoodlensCamera.setOnClickListener {
//            openCamera()
////            openCamera(REQ_CAMERA_PICTURE)
//        }
//
//        binding.btnRunFoodlensGallery.setOnClickListener {
//            openGallery()
////            openGallery(REQ_GALLERY_PICTURE)
//        }
//
//        binding.tvSetLanguage.setOnClickListener {
//            selectLanguageDialog()
//        }
//
//        binding.tvSetRotation.setOnClickListener {
//            selectRotationDialog()
//        }
//    }
//
//    private fun openCamera() {
//        val imageFile = createImageFile()
//        currentPhotoUri = FileProvider.getUriForFile(
//            this,
//            "${applicationContext.packageName}.fileprovider",
//            imageFile
//        )
//
//        currentPhotoUri?.let { uri -> // 스마트 캐스트를 사용하기 위해 지역 변수로 할당
//            mCameraForResult.launch(uri)
//        } ?: run {
//            Toast.makeText(this, "Failed to get image URI", Toast.LENGTH_SHORT).show()
//        }
//    }
//
//    private fun openGallery() {
//        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
//        mGalleryForResult.launch(intent)
//    }
//
//    private val mGalleryForResult: ActivityResultLauncher<Intent> =
//        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
//            if (result.resultCode == RESULT_OK) {
//                val uri = result.data?.data
//                uri?.let {
//                    val filePathColumn = arrayOf(MediaStore.Images.Media.DATA)
//                    val cursor = contentResolver.query(it, filePathColumn, null, null, null)
//                    cursor?.moveToFirst()?.let {
//                        val columnIndex = cursor.getColumnIndex(filePathColumn[0])
//                        val picturePath = cursor.getString(columnIndex)
//                        cursor.close()
//
//                        picturePath?.let {
//                            currentPhotoPath = it
//                            originBitmap = Utils.getBitmapFromFile(it)
//                            // 추가 로직
//                        }
//                    }
//                }
//            }
//        }
//
//    private val mCameraForResult: ActivityResultLauncher<Uri> =
//        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
//            if (success) {
//                originBitmap = Utils.getBitmapFromFile(currentPhotoPath)
//                // 추가 로직
//            } else {
//                Toast.makeText(this, "Failed to capture image", Toast.LENGTH_SHORT).show()
//            }
//        }
//
//
//
//
////    private fun openCamera(requestCode: Int) {
////        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)) {
////            Toast.makeText(this, "no camera", Toast.LENGTH_SHORT).show()
////            return
////        }
////        var imageFile = createImageFile()
////        imageFile?.let {
////            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
////            intent.putExtra(MediaStore.EXTRA_OUTPUT, currentPhotoUri)
////            mCameraForResult.launch(intent)
////        }
////
////    }
////
////    private fun openGallery(requestCode: Int) {
////        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
////        mGalleryForResult.launch(intent)
////    }
////
////    private var mGalleryForResult: ActivityResultLauncher<Intent> =
////        registerForActivityResult<Intent, ActivityResult>(
////            ActivityResultContracts.StartActivityForResult()
////        ) { result ->
////            if (result.resultCode == RESULT_OK) {
////                result.data?.data?.let {
////                    val filePathColumn = arrayOf(MediaStore.Images.Media.DATA)
////                    val cursor = contentResolver?.query(it, filePathColumn, null, null, null)
////                    cursor?.moveToFirst()
////                    val columnIndex = cursor?.getColumnIndex(filePathColumn[0])
////                    val picturePath = cursor?.getString(columnIndex ?: return@let) ?: return@let
////                    currentPhotoPath = picturePath
////                    cursor.close()
////
////                    originBitmap = Utils.getBitmapFromFile(picturePath)
////
////                    loadingDialog.show()
////                    val byteData = Utils.readContentIntoByteArray(File(picturePath))
////
////                    foodLensService.predict(byteData, object : RecognitionResultHandler {
////                        override fun onSuccess(result: RecognitionResult?) {
////                            loadingDialog.dismiss()
////
////                            result?.let {
////                                setRecognitionResultData(result)
////                            }
////                        }
////
////                        override fun onError(errorReason: BaseError?) {
////                            loadingDialog.dismiss()
////                            Toast.makeText(applicationContext,errorReason?.getMessage(), Toast.LENGTH_SHORT).show()
////                        }
////                    })
////                }
////            }
////        }
////
////    private var mCameraForResult: ActivityResultLauncher<Intent> =
////        registerForActivityResult<Intent, ActivityResult>(
////            ActivityResultContracts.StartActivityForResult()
////        ) { result ->
////            if (result.resultCode == RESULT_OK) {
////                originBitmap = Utils.getBitmapFromFile(currentPhotoPath)
////
////                loadingDialog.show()
////                val byteData = Utils.readContentIntoByteArray(File(currentPhotoPath))
////
////                foodLensService.predict(byteData, object : RecognitionResultHandler {
////                    override fun onSuccess(result: RecognitionResult?) {
////                        loadingDialog.dismiss()
////
////                        result?.let {
////                            setRecognitionResultData(result)
////                        }
////                    }
////
////                    override fun onError(errorReason: BaseError?) {
////                        loadingDialog.dismiss()
////                        Toast.makeText(applicationContext, errorReason?.getMessage(), Toast.LENGTH_SHORT).show()
////                    }
////                })
////            }
////        }
//
//
//    private fun setRecognitionResultData(resultData: RecognitionResult) {
//        val mutableList = mutableListOf<ListItem>()
//
//        if(foodLensService.getAutoRotate()) {
//            var orientation = Utils.getOrientationOfImage(currentPhotoPath)
//            originBitmap = Utils.getRotationBitmap(originBitmap, orientation)
//        }
//
//        binding.tvTitle.text = "Result from FoodLens Service"
//        resultData.foodInfoList?.forEach { foodInfo ->
//
//            foodInfo?.let {
//                val xMin = it.foodPosition?.xmin ?: 0
//                val yMin = it.foodPosition?.ymin ?: 0
//                val xMax = it.foodPosition?.xmax ?: originBitmap?.width ?: 0
//                val yMax = it.foodPosition?.ymax ?: originBitmap?.height ?: 0
//
//                val bitmap = Utils.cropBitmap(originBitmap, xMin, yMin, xMax,yMax) ?: null
//
//                mutableList.add(
//                    ListItem(
//                        id = it.hashCode(),
//                        title = "${it.name}",
//                        icon = BitmapDrawable(resources, bitmap),
//                        foodPosition = "${getString(R.string.food_position)} : ${xMin}, ${yMin}, ${xMax}, ${yMax}",
//                        foodNutrition = "${getString(R.string.carbohydrate)} : ${it.carbohydrate}, " +
//                                "${getString(R.string.protein)} : ${it.protein}, " +
//                                "${getString(R.string.fat)} : ${it.fat}"
//                    )
//                )
//            }
//        }
//
//        listAdapter.submitList(mutableList)
//    }
//
//    private fun selectLanguageDialog() {
//        var selectIndex = if(foodLensService.getLanguage() == LanguageConfig.EN.launuage) 0 else 1
//
//        AlertDialog.Builder(this@MainActivity)
//            .setTitle("Select Language")
//            .setSingleChoiceItems(selLanguage, selectIndex,
//                DialogInterface.OnClickListener{ _, i->
//                    selectIndex = i
//                })
//            .setPositiveButton("Confirm",
//                DialogInterface.OnClickListener{ _, _ ->
//                    if(selectIndex == 0) {
//                        foodLensService.setLanguage(LanguageConfig.EN)
//                    }
//                    else {
//                        foodLensService.setLanguage(LanguageConfig.KO)
//                    }
//                    binding.tvSetLanguage.text = "Language : ${foodLensService.getLanguage()}"
//                })
//            .setNegativeButton("Cancel", null)
//            .show()
//    }
//
//    private fun selectRotationDialog() {
//        var selectIndex = if(foodLensService.getAutoRotate()) 0 else 1
//
//        AlertDialog.Builder(this@MainActivity)
//            .setTitle("Select Auto Rotation")
//            .setSingleChoiceItems(selOrientation, selectIndex,
//                DialogInterface.OnClickListener{ _, i->
//                    selectIndex = i
//                })
//            .setPositiveButton("Confirm",
//                DialogInterface.OnClickListener{ _, _ ->
//                    if(selectIndex == 0) {
//                        foodLensService.setAutoRotate(true)
//                    }
//                    else {
//                        foodLensService.setAutoRotate(false)
//                    }
//                    binding.tvSetRotation.text = "Rotation auto : ${foodLensService.getAutoRotate()}"
//                })
//            .setNegativeButton("Cancel", null)
//            .show()
//    }
//
//
//    private fun createImageFile() : File {
//        val imageFileName = "JPEG_Image"
//        val imagePath: File? = getExternalFilesDir("images")
//
//        val newFile: File = File.createTempFile(imageFileName, ".jpg", imagePath)
//
//        currentPhotoPath = newFile.getAbsolutePath()
//
//        try {
//            currentPhotoUri = FileProvider.getUriForFile(
//                this,
//                applicationContext.packageName + ".fileprovider",
//                newFile
//            )
//        } catch (ex: Exception) {
//            ex.printStackTrace()
//        }
//        return newFile
//    }
//
//    private fun requestPermission() {
//        val permissionList =
//            arrayOf(
//                Manifest.permission.READ_EXTERNAL_STORAGE,
//                Manifest.permission.WRITE_EXTERNAL_STORAGE,
//            )
//
//        if (permissionList.map { ContextCompat.checkSelfPermission(this, it) }.filter { it == PackageManager.PERMISSION_DENIED }.isNullOrEmpty()) {
//            Log.d("FoodlensSample", "permission complete")
//        } else {
//            ActivityCompat.requestPermissions(this, permissionList, REQUEST_PERMISSION)
//        }
//    }
//
//    override fun onRequestPermissionsResult(
//        requestCode: Int,
//        permissions: Array<out String>,
//        grantResults: IntArray
//    ) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
//    }
//
//    companion object {
//        private const val REQ_GALLERY_PICTURE = 0x02
//        private const val REQ_CAMERA_PICTURE = 0x03
//        private const val REQUEST_PERMISSION = 101
//    }
//}