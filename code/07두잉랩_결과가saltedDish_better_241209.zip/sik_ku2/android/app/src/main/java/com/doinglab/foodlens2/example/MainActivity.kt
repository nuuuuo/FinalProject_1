package com.doinglab.foodlens2.example

import android.Manifest
import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.util.Log
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.databinding.DataBindingUtil
import com.doinglab.foodlens2.example.databinding.ActivityMainBinding
import com.doinglab.foodlens2.example.listview.ListItem
import com.doinglab.foodlens2.example.listview.SampleListAdapter
import com.doinglab.foodlens2.example.util.Utils
import com.doinglab.foodlens2.sdk.FoodLens
import com.doinglab.foodlens2.sdk.RecognitionResultHandler
import com.doinglab.foodlens2.sdk.config.LanguageConfig
import com.doinglab.foodlens2.sdk.errors.BaseError
import com.doinglab.foodlens2.sdk.model.RecognitionResult
import java.io.ByteArrayOutputStream
import java.io.File

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.doinglab.foodlens2.example"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "startFoodLens" -> {
                    // CameraActivity 호출
                    startFoodLensActivity()
                    result.success("Started FoodLens in MainActivity")
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun startFoodLensActivity() {
        val intent = Intent(this, CameraActivity::class.java)
        startActivity(intent)
    }
}


//class CameraActivity : AppCompatActivity() {
//    private var currentPhotoPath: String = ""
//    private var originBitmap: Bitmap? = null
//    lateinit var binding: ActivityMainBinding
//
//    private val foodLensService by lazy {
//        FoodLens.createFoodLensService(this)
//    }
//
//    private val loadingDialog by lazy {
//        Dialog(this).apply {
//            window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//            setContentView(ProgressBar(this@CameraActivity))
//        }
//    }
//
//    private val mGalleryForResult: ActivityResultLauncher<Intent> =
//        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
//            if (result.resultCode == RESULT_OK) {
//                result.data?.data?.let { uri ->
//                    processImageFromUri(uri)
//                }
//            } else {
//                Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show()
//            }
//        }
//
//    private val mCameraForResult: ActivityResultLauncher<Uri> =
//        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
//            if (success) {
//                processImageFromPath(currentPhotoPath)
//            } else {
//                Toast.makeText(this, "Failed to capture image", Toast.LENGTH_SHORT).show()
//            }
//        }
//
//    private val selLaunuage = arrayOf("en", "ko")
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
//        setContentView(R.layout.activity_camera)
//
//        val cameraButton: Button = findViewById(R.id.btn_open_camera)
//        val galleryButton: Button = findViewById(R.id.btn_open_gallery)
//
//        cameraButton.setOnClickListener { openCamera() }
//        galleryButton.setOnClickListener { openGallery() }
//        checkAndRequestPermissions()
//
//        binding.tvSetLanguage.text = "Language : ${foodLensService.getLanguage()}"
//
//        binding.tvSetLanguage.setOnClickListener {
//            selectLanguageDialog()
//        }
//    }
//
//    private fun openCamera() {
//        val imageFile = createImageFile()
//        val photoUri = FileProvider.getUriForFile(
//            this,
//            "${applicationContext.packageName}.fileprovider",
//            imageFile
//        )
//
//        currentPhotoPath = imageFile.absolutePath
//        mCameraForResult.launch(photoUri)
//    }
//
//    private fun openGallery() {
//        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
//        mGalleryForResult.launch(intent)
//    }
//
//    private fun createImageFile(): File {
//        val imageFileName = "JPEG_Image"
//        val storageDir: File? = getExternalFilesDir("images")
//        return File.createTempFile(imageFileName, ".jpg", storageDir)
//    }
//
//    private fun processImageFromPath(imagePath: String) {
//        try {
//            if (imagePath.isEmpty()) {
//                Toast.makeText(this, "Invalid image path", Toast.LENGTH_SHORT).show()
//                return
//            }
//            val file = File(imagePath)
//            val byteData = file.readBytes()
//
//            processImage(byteData)
//        } catch (e: Exception) {
//            Toast.makeText(this, "Error processing image: ${e.message}", Toast.LENGTH_SHORT).show()
//        }
//    }
//
//    private fun processImageFromUri(uri: Uri) {
//        try {
//            val inputStream = contentResolver.openInputStream(uri)
//            val byteData = inputStream?.readBytes() ?: throw Exception("Unable to read image data")
//
//            processImage(byteData)
//        } catch (e: Exception) {
//            Toast.makeText(this, "Error processing image: ${e.message}", Toast.LENGTH_SHORT).show()
//        }
//    }
//
//    private fun processImage(byteData: ByteArray) {
//        loadingDialog.show()
//
//        foodLensService.predict(byteData, object : RecognitionResultHandler {
//            override fun onSuccess(result: RecognitionResult?) {
//                loadingDialog.dismiss()
//                result?.let {
//                    displayRecognitionResults(it)
//                } ?: run {
//                    Toast.makeText(this@CameraActivity, "No recognition result found.", Toast.LENGTH_SHORT).show()
//                }
//            }
//
//            override fun onError(errorReason: BaseError?) {
//                loadingDialog.dismiss()
//                Toast.makeText(this@CameraActivity, "Error: ${errorReason?.getMessage()}", Toast.LENGTH_SHORT).show()
//            }
//        })
//    }
//
//    private fun displayRecognitionResults(result: RecognitionResult) {
//        val recognizedFoods = result.foodInfoList?.map { foodInfo ->
//            val name = foodInfo.name ?: "Unknown"
//            val carbohydrate = foodInfo.carbohydrate ?: 0.0
//            val protein = foodInfo.protein ?: 0.0
//            val fat = foodInfo.fat ?: 0.0
//
//            // 음식 이름과 영양 정보를 조합
//            """
//        Name: $name
//        Carbohydrates: $carbohydrate g
//        Protein: $protein g
//        Fat: $fat g
//        """.trimIndent()
//        } ?: listOf("No food recognized")
//
//        // AlertDialog로 결과 표시
//        val builder = AlertDialog.Builder(this)
//            .setTitle("Recognized Foods and Nutrition Info")
//            .setItems(recognizedFoods.toTypedArray(), null)
//            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
//        builder.show()
//    }
//
//
//    private fun checkAndRequestPermissions() {
//        val permissions = arrayOf(
//            Manifest.permission.READ_EXTERNAL_STORAGE,
//            Manifest.permission.WRITE_EXTERNAL_STORAGE
//        )
//        val deniedPermissions = permissions.filter {
//            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
//        }
//        if (deniedPermissions.isNotEmpty()) {
//            ActivityCompat.requestPermissions(this, deniedPermissions.toTypedArray(), PERMISSION_REQUEST_CODE)
//        }
//    }
//
//    private fun selectLanguageDialog() {
//        var selectIndex = if(foodLensService.getLanguage() == LanguageConfig.EN.launuage) 0 else 1
//
//        AlertDialog.Builder(this@CameraActivity)
//            .setTitle("Select Language")
//            .setSingleChoiceItems(selLaunuage, selectIndex,
//                DialogInterface.OnClickListener{ _, i->
//                    selectIndex = i
//                })
//            .setPositiveButton("Confirm",
//                DialogInterface.OnClickListener{ _, _ ->
//                    if(selectIndex == 0) {
//                        foodLensService.setLanguage(LanguageConfig.KO)
//                    }
//                    else {
//                        foodLensService.setLanguage(LanguageConfig.EN)
//                    }
//                    binding.tvSetLanguage.text = "Language : ${foodLensService.getLanguage()}"
//                })
//            .setNegativeButton("Cancel", null)
//            .show()
//    }
//
//    companion object {
//        private const val REQ_GALLERY_PICTURE = 0x02
//        private const val REQ_CAMERA_PICTURE = 0x03
//        private const val PERMISSION_REQUEST_CODE = 1001
//    }
//}


class CameraActivity : AppCompatActivity() {
    private var currentPhotoPath: String = ""
    private var originBitmap: Bitmap? = null
    lateinit var binding: ActivityMainBinding

    private val foodLensService by lazy {
        FoodLens.createFoodLensService(this)
    }

    private val loadingDialog by lazy {
        Dialog(this).apply {
            window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setContentView(ProgressBar(this@CameraActivity))
        }
    }

    private val mGalleryForResult: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                result.data?.data?.let { uri ->
                    processImageFromUri(uri)
                }
            } else {
                Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show()
            }
        }

    private val mCameraForResult: ActivityResultLauncher<Uri> =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) {
                processImageFromPath(currentPhotoPath)
            } else {
                Toast.makeText(this, "Failed to capture image", Toast.LENGTH_SHORT).show()
            }
        }

    private val selLaunuage = arrayOf("en", "ko")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        setContentView(R.layout.activity_camera)

        val cameraButton: Button = findViewById(R.id.btn_open_camera)
        val galleryButton: Button = findViewById(R.id.btn_open_gallery)

        cameraButton.setOnClickListener { openCamera() }
        galleryButton.setOnClickListener { openGallery() }
        checkAndRequestPermissions()

        binding.tvSetLanguage.text = "Language : ${foodLensService.getLanguage()}"

        binding.tvSetLanguage.setOnClickListener {
            selectLanguageDialog()
        }
    }

    private fun openCamera() {
        val imageFile = createImageFile()
        val photoUri = FileProvider.getUriForFile(
            this,
            "${applicationContext.packageName}.fileprovider",
            imageFile
        )

        currentPhotoPath = imageFile.absolutePath
        mCameraForResult.launch(photoUri)
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        mGalleryForResult.launch(intent)
    }

    private fun createImageFile(): File {
        val imageFileName = "JPEG_Image"
        val storageDir: File? = getExternalFilesDir("images")
        return File.createTempFile(imageFileName, ".jpg", storageDir)
    }

    private fun processImageFromPath(imagePath: String) {
        try {
            if (imagePath.isEmpty()) {
                Toast.makeText(this, "Invalid image path", Toast.LENGTH_SHORT).show()
                return
            }

            val bitmap = getHighResolutionBitmap(imagePath)
            if (bitmap == null) {
                Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show()
                return
            }

            val enhancedBitmap = enhanceBitmap(bitmap) // 선명도 개선
            val byteData = getByteArrayFromBitmap(enhancedBitmap) // 바이트 배열 생성

            processImage(byteData)
        } catch (e: Exception) {
            Toast.makeText(this, "Error processing image: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }


    private fun processImageFromUri(uri: Uri) {
        try {
            val inputStream = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (bitmap == null) {
                Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show()
                return
            }

            val enhancedBitmap = enhanceBitmap(bitmap) // 선명도 개선
            val byteData = getByteArrayFromBitmap(enhancedBitmap) // 바이트 배열 생성

            processImage(byteData)
        } catch (e: Exception) {
            Toast.makeText(this, "Error processing image: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun processImage(byteData: ByteArray) {
        loadingDialog.show()

        foodLensService.predict(byteData, object : RecognitionResultHandler {
            override fun onSuccess(result: RecognitionResult?) {
                loadingDialog.dismiss()
                result?.let {
                    displayRecognitionResults(it)
                } ?: run {
                    Toast.makeText(this@CameraActivity, "No recognition result found.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onError(errorReason: BaseError?) {
                loadingDialog.dismiss()
                Toast.makeText(this@CameraActivity, "Error: ${errorReason?.getMessage()}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun displayRecognitionResults(result: RecognitionResult) {
        val recognizedFoods = result.foodInfoList?.map { foodInfo ->
            val name = foodInfo.name ?: "Unknown"
            val carbohydrate = foodInfo.carbohydrate ?: 0.0
            val protein = foodInfo.protein ?: 0.0
            val fat = foodInfo.fat ?: 0.0

            // 음식 이름과 영양 정보를 조합
            """
        Name: $name
        Carbohydrates: $carbohydrate g
        Protein: $protein g
        Fat: $fat g
        """.trimIndent()
        } ?: listOf("No food recognized")

        // AlertDialog로 결과 표시
        val builder = AlertDialog.Builder(this)
            .setTitle("Recognized Foods and Nutrition Info")
            .setItems(recognizedFoods.toTypedArray(), null)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
        builder.show()
    }


    private fun checkAndRequestPermissions() {
        val permissions = arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
        val deniedPermissions = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (deniedPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, deniedPermissions.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }

    private fun selectLanguageDialog() {
        var selectIndex = if(foodLensService.getLanguage() == LanguageConfig.EN.launuage) 0 else 1

        AlertDialog.Builder(this@CameraActivity)
            .setTitle("Select Language")
            .setSingleChoiceItems(selLaunuage, selectIndex,
                DialogInterface.OnClickListener{ _, i->
                    selectIndex = i
                })
            .setPositiveButton("Confirm",
                DialogInterface.OnClickListener{ _, _ ->
                    if(selectIndex == 0) {
                        foodLensService.setLanguage(LanguageConfig.KO)
                    }
                    else {
                        foodLensService.setLanguage(LanguageConfig.EN)
                    }
                    binding.tvSetLanguage.text = "Language : ${foodLensService.getLanguage()}"
                })
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun getHighResolutionBitmap(filePath: String): Bitmap? {
        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888 // 고해상도 설정
            inJustDecodeBounds = false // 이미지 전체 로드
        }
        return BitmapFactory.decodeFile(filePath, options)
    }

    private fun getByteArrayFromBitmap(bitmap: Bitmap): ByteArray {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream) // PNG는 무손실 압축
        return outputStream.toByteArray()
    }

    private fun enhanceBitmap(bitmap: Bitmap): Bitmap {
        val contrast = 1.5f // 대비 증가 값
        val brightness = 10f // 밝기 증가 값 (float 타입으로 변경)

        // ColorMatrix 생성 및 설정
        val colorMatrix = ColorMatrix().apply {
            set(floatArrayOf(
                contrast, 0f, 0f, 0f, brightness,
                0f, contrast, 0f, 0f, brightness,
                0f, 0f, contrast, 0f, brightness,
                0f, 0f, 0f, 1f, 0f
            ))
        }

        // Paint에 ColorFilter 적용
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(colorMatrix)
        }

        // 결과 비트맵 생성
        val resultBitmap = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config)
        val canvas = Canvas(resultBitmap)
        canvas.drawBitmap(bitmap, 0f, 0f, paint)

        return resultBitmap
    }

    companion object {
        private const val REQ_GALLERY_PICTURE = 0x02
        private const val REQ_CAMERA_PICTURE = 0x03
        private const val PERMISSION_REQUEST_CODE = 1001
    }
}





//class CameraActivity : AppCompatActivity() {
//    private var currentPhotoPath: String = ""
//    private var originBitmap: Bitmap? = null
//
//    private val foodLensService by lazy {
//        FoodLens.createFoodLensService(this)
//    }
//
//    private val loadingDialog by lazy {
//        Dialog(this).apply {
//            window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//            setContentView(ProgressBar(this@CameraActivity))
//        }
//    }
//
//    private val mGalleryForResult: ActivityResultLauncher<Intent> =
//        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
//            if (result.resultCode == RESULT_OK) {
//                result.data?.data?.let { imageUri ->
//                    val filePathColumn = arrayOf(MediaStore.Images.Media.DATA)
//                    val cursor = contentResolver?.query(imageUri, filePathColumn, null, null, null)
//                    cursor?.moveToFirst()?.let {
//                        val columnIndex = cursor.getColumnIndex(filePathColumn[0])
//                        val picturePath = cursor.getString(columnIndex)
//                        cursor.close()
//
//                        processImage(picturePath)
//                    }
//                }
//            } else {
//                Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show()
//            }
//        }
//
//    private val mCameraForResult: ActivityResultLauncher<Uri> =
//        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
//            if (success) {
//                processImage(currentPhotoPath)
//            } else {
//                Toast.makeText(this, "Failed to capture image", Toast.LENGTH_SHORT).show()
//            }
//        }
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_camera)
//
//        val cameraButton: Button = findViewById(R.id.btn_open_camera)
//        val galleryButton: Button = findViewById(R.id.btn_open_gallery)
//
//        cameraButton.setOnClickListener { openCamera() }
//        galleryButton.setOnClickListener { openGallery() }
//    }
//
//    private fun openCamera() {
//        val imageFile = createImageFile()
//        val photoUri = FileProvider.getUriForFile(
//            this,
//            "${applicationContext.packageName}.fileprovider",
//            imageFile
//        )
//
//        currentPhotoPath = imageFile.absolutePath
//        mCameraForResult.launch(photoUri)
//    }
//
//    private fun openGallery() {
//        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
//        mGalleryForResult.launch(intent)
//    }
//
//    private fun createImageFile(): File {
//        val imageFileName = "JPEG_Image"
//        val storageDir: File? = getExternalFilesDir("images")
//        return File.createTempFile(imageFileName, ".jpg", storageDir)
//    }
//
//    private fun processImage(imagePath: String) {
//        try {
//            if (imagePath.isEmpty()) {
//                Toast.makeText(this, "Invalid image path", Toast.LENGTH_SHORT).show()
//                return
//            }
//
//            originBitmap = Utils.getBitmapFromFile(imagePath)
//
//            if (originBitmap == null) {
//                Toast.makeText(this, "Failed to decode bitmap", Toast.LENGTH_SHORT).show()
//                return
//            }
//
//            loadingDialog.show()
//
//            val byteData = Utils.readContentIntoByteArray(File(imagePath))
//            foodLensService.predict(byteData, object : RecognitionResultHandler {
//                override fun onSuccess(result: RecognitionResult?) {
//                    loadingDialog.dismiss()
//                    result?.let {
//                        displayRecognitionResults(it)
//                    } ?: run {
//                        Toast.makeText(this@CameraActivity, "No recognition result found.", Toast.LENGTH_SHORT).show()
//                    }
//                }
//
//                override fun onError(errorReason: BaseError?) {
//                    loadingDialog.dismiss()
//                    Toast.makeText(this@CameraActivity, "Error: ${errorReason?.getMessage()}", Toast.LENGTH_SHORT).show()
//                }
//            })
//        } catch (e: Exception) {
//            loadingDialog.dismiss()
//            Toast.makeText(this, "Error processing image: ${e.message}", Toast.LENGTH_SHORT).show()
//        }
//    }
//
//    private fun displayRecognitionResults(result: RecognitionResult) {
//        val foodNames = result.foodInfoList?.map { it.name ?: "Unknown" } ?: emptyList()
//        val message = "Recognized Foods:\n${foodNames.joinToString("\n")}"
//        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
//    }
//
//    private fun checkAndRequestPermissions() {
//        val permissions = arrayOf(
//            Manifest.permission.READ_EXTERNAL_STORAGE,
//            Manifest.permission.WRITE_EXTERNAL_STORAGE
//        )
//        val deniedPermissions = permissions.filter {
//            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
//        }
//        if (deniedPermissions.isNotEmpty()) {
//            ActivityCompat.requestPermissions(this, deniedPermissions.toTypedArray(), PERMISSION_REQUEST_CODE)
//        }
//    }
//
//    private fun getFileFromUri(uri: Uri): File? {
//        val filePathColumn = arrayOf(MediaStore.Images.Media.DATA)
//        val cursor = contentResolver.query(uri, filePathColumn, null, null, null)
//        cursor?.use {
//            if (it.moveToFirst()) {
//                val columnIndex = it.getColumnIndexOrThrow(filePathColumn[0])
//                return File(it.getString(columnIndex))
//            }
//        }
//        return null
//    }
//
//    companion object {
//        private const val PERMISSION_REQUEST_CODE = 1001
//    }
//}



//class CameraActivity : AppCompatActivity() {
//    private var currentPhotoUri: Uri? = null
//    private var currentPhotoPath: String = ""
//    private var originBitmap: Bitmap? = null
//
//    private val mCameraForResult: ActivityResultLauncher<Uri> =
//        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
//            if (success) {
//                currentPhotoUri?.let {
//                    processImage(it)
//                }
//            } else {
//                Toast.makeText(this, "Failed to capture image", Toast.LENGTH_SHORT).show()
//            }
//        }
//
//    private val mGalleryForResult: ActivityResultLauncher<Intent> =
//        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
//            if (result.resultCode == RESULT_OK) {
//                val uri = result.data?.data
//                uri?.let {
//                    processImage(it)
//                }
//            } else {
//                Toast.makeText(this, "No image selected", Toast.LENGTH_SHORT).show()
//            }
//        }
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_camera) // 레이아웃 설정
//        checkAndRequestPermissions()
//
//        // 버튼 초기화
//        val cameraButton: Button = findViewById(R.id.btn_open_camera)
//        val galleryButton: Button = findViewById(R.id.btn_open_gallery)
//
//        cameraButton.setOnClickListener {
//            openCamera()
//        }
//
//        galleryButton.setOnClickListener {
//            openGallery()
//        }
//    }
//
//    private fun checkAndRequestPermissions() {
//        val permissions = arrayOf(Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE)
//
//        val deniedPermissions = permissions.filter {
//            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
//        }
//
//        if (deniedPermissions.isNotEmpty()) {
//            ActivityCompat.requestPermissions(this, deniedPermissions.toTypedArray(), PERMISSION_REQUEST_CODE)
//        }
//    }
//
//    private fun openCamera() {
//        val imageFile = createImageFile()
//        currentPhotoUri = FileProvider.getUriForFile(
//            this,
//            "${applicationContext.packageName}.fileprovider",
//            imageFile
//        )
//
//        currentPhotoUri?.let { uri ->
//            mCameraForResult.launch(uri)
//        } ?: run {
//            Toast.makeText(this, "Failed to get image URI", Toast.LENGTH_SHORT).show()
//        }
//    }
//
//    private fun openGallery() {
//        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
//        mGalleryForResult.launch(intent)
//    }
//
//    private fun createImageFile(): File {
//        val imageFileName = "JPEG_Image"
//        val imagePath: File? = getExternalFilesDir("images")
//
//        val newFile: File = File.createTempFile(imageFileName, ".jpg", imagePath)
//        currentPhotoPath = newFile.absolutePath
//        return newFile
//    }
//
//    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
//        if (requestCode == PERMISSION_REQUEST_CODE) {
//            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
//                Toast.makeText(this, "Permissions granted", Toast.LENGTH_SHORT).show()
//            } else {
//                Toast.makeText(this, "Permissions denied. Some features may not work.", Toast.LENGTH_SHORT).show()
//            }
//        }
//    }
//
//    private fun processImage(imageUri: Uri) {
//        try {
//            val inputStream = contentResolver.openInputStream(imageUri)
//            val bitmap = BitmapFactory.decodeStream(inputStream)
//
//            // Bitmap으로 이미지 처리
//            originBitmap = bitmap
//
//            // 추가 로직
//            Toast.makeText(this, "Image processed successfully!", Toast.LENGTH_SHORT).show()
//        } catch (e: Exception) {
//            Toast.makeText(this, "Error processing image: ${e.message}", Toast.LENGTH_SHORT).show()
//        }
//    }
//
//    companion object {
//        private const val PERMISSION_REQUEST_CODE = 1001
//    }
//}





/*

flutter clean
flutter pub get
flutter run

 */

