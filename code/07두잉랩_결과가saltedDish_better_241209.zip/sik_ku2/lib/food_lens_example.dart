import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'foodlens_service.dart'; // FoodLensService 연결

class FoodLensExample extends StatefulWidget {
  @override
  _FoodLensExampleState createState() => _FoodLensExampleState();
}

class _FoodLensExampleState extends State<FoodLensExample> {
  String _result = "No result"; // 예측 결과
  bool _isLoading = false; // 로딩 상태 표시

  /// 이미지를 선택하고 FoodLens SDK 호출
  Future<void> _pickAndPredict() async {
    setState(() {
      _isLoading = true;
      _result = "Processing...";
    });

    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery); // 갤러리에서 이미지 선택

    if (image != null) {
      try {
        final imageData = await image.readAsBytes(); // 이미지를 바이트 데이터로 읽기
        final foodNames = await FoodLensService.predictFood(imageData); // FoodLensService 호출

        setState(() {
          _result = foodNames.isNotEmpty
              ? "Predicted Foods: ${foodNames.join(", ")}" // 결과 표시
              : "No food recognized!";
        });
      } catch (e) {
        setState(() {
          _result = "Error: $e"; // 오류 메시지 표시
        });
      }
    } else {
      setState(() {
        _result = "No image selected";
      });
    }

    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("FoodLens Example")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _isLoading
                ? CircularProgressIndicator() // 로딩 중 표시
                : Text(
              _result,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _pickAndPredict, // 이미지 선택 및 예측
              child: Text("Select Image & Predict"),
            ),
          ],
        ),
      ),
    );
  }
}
