import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/services.dart';

class FoodLensScreen extends StatefulWidget {
  const FoodLensScreen({super.key});

  @override
  _FoodLensScreenState createState() => _FoodLensScreenState();
}

class _FoodLensScreenState extends State<FoodLensScreen> {
  static const platform = MethodChannel('foodlens_sdk');
  String _result = "No results yet.";
  File? _selectedImage;

  Future<void> _pickImage(ImageSource source) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: source);

    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
      _analyzeImage(pickedFile.path);
    }
  }

  Future<void> _analyzeImage(String imagePath) async {
    try {
      final List<dynamic> result = await platform.invokeMethod('predictFood', {
        'imagePath': imagePath,
      });

      setState(() {
        _result = result.join(", ");
      });
    } on PlatformException catch (e) {
      setState(() {
        _result = "Error: ${e.message}";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('FoodLens Example'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: () => _pickImage(ImageSource.camera),
              child: Text("Capture Image"),
            ),
            ElevatedButton(
              onPressed: () => _pickImage(ImageSource.gallery),
              child: Text("Select from Gallery"),
            ),
            if (_selectedImage != null) Image.file(_selectedImage!),
            SizedBox(height: 16),
            Text(
              "Result: $_result",
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
