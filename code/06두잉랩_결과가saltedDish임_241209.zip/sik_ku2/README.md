# Coniv 3 Dream

Coniv 3 Dream은 Flutter로 개발된 모바일 애플리케이션으로, 개발자 커뮤니티와 기술 정보 공유 플랫폼입니다.

## 주요 기능

1. 사용자 인증: 회원가입, 로그인, 프로필 관리
2. 커뮤니티: 게시글 작성, 댓글 기능, 즐겨찾기
3. 기술 정보: Android, iOS, Flutter, React Native 관련 아티클 제공
4. 개인화: 내가 쓴 글, 댓글, 즐겨찾기 관리

## 시작하기

### 필수 조건

- Flutter SDK
- Firebase 프로젝트
- Android Studio 또는 VS Code

### 설정

1. 종속성을 설치합니다:

   ```
   flutter pub get
   ```

2. Firebase 설정 파일을 추가합니다:

   - Android: `android/app/google-services.json`
   - iOS: `ios/Runner/GoogleService-Info.plist`

3. 앱을 실행합니다:
   ```
   flutter run
   ```

## Firebase 설정

### Authentication 설정

1. Firebase 콘솔에서 프로젝트를 선택합니다.
2. 왼쪽 메뉴에서 "Authentication"을 클릭합니다.
3. "시작하기" 버튼을 클릭합니다.
4. 이메일/비밀번호 로그인 방식을 선택하고 활성화합니다.

### FireStore 보안 규칙

FireStore 보안을 위해 다음 규칙을 적용하세요:

```
rules_version = '2';

service cloud.firestore {
  match /databases/{database}/documents {
    match /community/{document} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == request.resource.data.userId;
    }

    match /comments/{commentId} {
      allow read: if true;
      allow create: if request.auth != null;
      allow update, delete: if request.auth != null && request.auth.uid == resource.data.userId;
    }

    match /userInfo/{userId} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == userId;
    }

    match /favorites/{userId} {
      allow read: if request.auth != null && request.auth.uid == userId;
      allow write: if request.auth != null && request.auth.uid == userId;
    }

    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

### FireStore 색인 추가

효율적인 쿼리 실행을 위해 FireStore 색인을 추가해야 합니다. 다음 단계를 따라 색인을 추가하세요:

1. Firebase 콘솔에서 프로젝트를 선택합니다.
2. 왼쪽 메뉴에서 "Firestore Database"를 클릭합니다.
3. "색인" 탭을 선택합니다.
4. "복합 색인" 섹션에서 "색인 추가" 버튼을 클릭합니다.
5. 필요한 필드를 선택하고 정렬 순서를 지정합니다.
6. "색인 생성" 버튼을 클릭하여 색인을 생성합니다.

![FireStore 색인 추가](스크린샷 2024-10-09 21.53.41.png)
