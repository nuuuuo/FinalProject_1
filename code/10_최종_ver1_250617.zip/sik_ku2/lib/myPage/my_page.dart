import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';

import '../auth/login_screen.dart';
import '../main.dart';


class MyPage extends StatefulWidget {
  final String userId; // 사용자 ID (이메일 형식)
  const MyPage({Key? key, required this.userId}) : super(key: key);

  @override
  _MyPageState createState() => _MyPageState();
}

class _MyPageState extends State<MyPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final Set<int> expandedIndexes = {};

  // 사용자의 신체 정보
  String? selectedGender; // 성별
  int? selectedYear;
  TextEditingController heightController = TextEditingController();
  TextEditingController weightController = TextEditingController();

  // 권장 섭취량 (자동 계산 후 수정 가능)
  TextEditingController calorieController = TextEditingController();
  TextEditingController carbController = TextEditingController();
  TextEditingController proteinController = TextEditingController();
  TextEditingController fatController = TextEditingController();
  TextEditingController sugarController = TextEditingController();
  TextEditingController sodiumController = TextEditingController();
  TextEditingController cholesterolController = TextEditingController();

  // 달력 관련
  DateTime _focusedDay = DateTime.now(); // 현재 선택된 달
  DateTime? _selectedDay; // 선택된 날짜
  List<Map<String, dynamic>> _selectedDayRecords = []; // 선택된 날짜의 섭취 기록

  @override
  void initState() {
    super.initState();
    _selectedDay = DateTime.now();
    _loadUserInfo(); // Firestore에서 사용자 신체 정보 로드
    _loadRecordsForSelectedDay(); // 선택한 날짜의 섭취 기록 로드
  }

  // Firestore에서 사용자 신체 정보 불러오기
  Future<void> _loadUserInfo() async {
    final doc = await _firestore.collection('sjsk_users').doc(widget.userId).get();
    if (doc.exists) {
      final data = doc.data();
      setState(() {
        selectedGender = data?['gender'];
        selectedYear = data?['birthYear'];
        heightController.text = data?['height']?.toString() ?? '';
        weightController.text = data?['weight']?.toString() ?? '';
        calorieController.text = data?['calories']?.toString() ?? '';
        carbController.text = data?['carbohydrates']?.toString() ?? '';
        proteinController.text = data?['protein']?.toString() ?? '';
        fatController.text = data?['fat']?.toString() ?? '';
        sugarController.text = data?['sugars']?.toString() ?? '';
        sodiumController.text = data?['sodium']?.toString() ?? '';
        cholesterolController.text = data?['cholesterol']?.toString() ?? '';
      });
    }
  }

  // 성별 기반 권장 영양소 자동 계산
  void _calculateRecommendedNutrition() {
    if (selectedGender == null || selectedYear == null || heightController.text.isEmpty || weightController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("모든 필드를 입력하세요.")),
      );
      return;
    }

    double height = double.parse(heightController.text);
    double weight = double.parse(weightController.text);
    int age = DateTime.now().year - (selectedYear ?? DateTime.now().year);

    // 🔸 BMR 계산 (기초대사량)
    double bmr;
    if (selectedGender == "남자") {
      bmr = 10 * weight + 6.25 * height - 5 * age + 5;
    } else {
      bmr = 10 * weight + 6.25 * height - 5 * age - 161;
    }

    // 🔸 총 권장 칼로리 (활동량 낮음 기준)
    double recommendedCalories = bmr * 1.2;

    // 🔸 탄수화물 (총 칼로리의 55%)
    double recommendedCarbs = (recommendedCalories * 0.55) / 4;
    // 🔸 단백질 (남성: 체중 * 1.5, 여성: 체중 * 1.2)
    double recommendedProtein = selectedGender == "남자" ? weight * 1.5 : weight * 1.2;
    // 🔸 지방 (총 칼로리의 25%)
    double recommendedFat = (recommendedCalories * 0.25) / 9;
    // 🔸 당류 (총 칼로리의 10%)
    double recommendedSugars = (recommendedCalories * 0.1) / 4;
    // 🔸 나트륨 (하루 권장량 약 2,000mg)
    double recommendedSodium = 2000.0;
    // 🔸 콜레스테롤 (하루 권장량 약 300mg)
    double recommendedCholesterol = 300.0;

    setState(() {
      calorieController.text = recommendedCalories.toStringAsFixed(1);
      carbController.text = recommendedCarbs.toStringAsFixed(1);
      proteinController.text = recommendedProtein.toStringAsFixed(1);
      fatController.text = recommendedFat.toStringAsFixed(1);
      sugarController.text = recommendedSugars.toStringAsFixed(1);
      sodiumController.text = recommendedSodium.toStringAsFixed(1);
      cholesterolController.text = recommendedCholesterol.toStringAsFixed(1);
    });
  }

  double _getTotal(String nutrientKey) {
    return _selectedDayRecords.fold(0.0, (sum, record) {
      return sum + (double.tryParse(record[nutrientKey]?.toString() ?? '0') ?? 0);
    });
  }


  // Firestore에 사용자 신체 정보 저장하기
  Future<void> _saveUserInfo() async {
    if (selectedGender == null || selectedYear == null || heightController.text.isEmpty || weightController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("모든 필드를 입력하세요.")),
      );
      return;
    }

    await _firestore.collection('sjsk_users').doc(widget.userId).set({
      'gender': selectedGender,
      'birthYear': selectedYear,
      'height': double.parse(heightController.text),
      'weight': double.parse(weightController.text),
      'calories': double.parse(calorieController.text),
      'carbohydrates': double.parse(carbController.text),
      'protein': double.parse(proteinController.text),
      'fat': double.parse(fatController.text),
      'sugars': double.parse(sugarController.text),
      'sodium': double.parse(sodiumController.text),
      'cholesterol': double.parse(cholesterolController.text),
    }, SetOptions(merge: true));

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("사용자 정보가 저장되었습니다.")),
    );
  }

  // Firestore에서 선택된 날짜의 섭취 기록 불러오기
  Future<void> _loadRecordsForSelectedDay() async {
    final formattedDate = _selectedDay!.toString().split(' ')[0]; // 날짜 변환 (YYYY-MM-DD)

    try {
      final snapshot = await _firestore
          .collection('sjsk_users')
          .doc(widget.userId)
          .collection(formattedDate)
          .get();

      final records = snapshot.docs.map((doc) {
        final data = doc.data();
        data['recordId'] = doc.id;  // 🔹 문서 ID 저장
        return data;
      }).toList();

      // final snapshot = await _firestore
      //     .collection('sjsk_users') // 상위 컬렉션
      //     .doc(widget.userId) // 사용자 ID (이메일)
      //     .collection(formattedDate) // 선택된 날짜의 하위 컬렉션
      //     .get();
      //
      // final records = snapshot.docs.map((doc) => doc.data()).toList();

      setState(() {
        _selectedDayRecords = records.map((record) {
          return {
            "recordId": record['recordId'], // 문서 ID
            "foodName": record['foodName'] ?? "이름 없음", // 음식 이름
            "totalConsumed": record['totalConsumed'] ?? "0", // 섭취량
            "calories": record['calories'] ?? "0", // 칼로리
            "carbohydrates": record['carbohydrates'] ?? "0", // 탄수화물
            "protein": record['protein'] ?? "0", // 단백질
            "fat": record['fat'] ?? "0", // 지방
            "sugars": record['sugars'] ?? "0", // 당류
            "sodium": record['sodium'] ?? "0", // 나트륨
            "cholesterol": record['cholesterol'] ?? "0", // 콜레스테롤
            "timestamp": record['timestamp'], // 타임스탬프
          };
        }).toList();
      });
    } catch (e) {
      print('Firestore 데이터 로드 중 오류 발생: $e');
    }
  }



// 신체 정보 수정용 AlertDialog
  void _showEditBodyInfoDialog() {
    final heightCtrl = TextEditingController(text: heightController.text);
    final weightCtrl = TextEditingController(text: weightController.text);
    final calorieCtrl = TextEditingController(text: calorieController.text);
    final carbCtrl = TextEditingController(text: carbController.text);
    final proteinCtrl = TextEditingController(text: proteinController.text);
    final fatCtrl = TextEditingController(text: fatController.text);
    final sugarCtrl = TextEditingController(text: sugarController.text);
    final sodiumCtrl = TextEditingController(text: sodiumController.text);
    final cholesterolCtrl = TextEditingController(text: cholesterolController.text);

    showDialog(
      context: context,
      builder: (dialogContext) {
        String tempSelectedGender = selectedGender ?? "남자";
        int tempSelectedYear = selectedYear ?? DateTime.now().year;

        return StatefulBuilder(
          builder: (context, setState) {
            void _localCalculate() {
              heightController.text = heightCtrl.text;
              weightController.text = weightCtrl.text;
              _calculateRecommendedNutrition();
              calorieCtrl.text = calorieController.text;
              carbCtrl.text = carbController.text;
              proteinCtrl.text = proteinController.text;
              fatCtrl.text = fatController.text;
              sugarCtrl.text = sugarController.text;
              sodiumCtrl.text = sodiumController.text;
              cholesterolCtrl.text = cholesterolController.text;
            }

            return AlertDialog(
              title: Text('신체 정보 및 권장 영양소 수정'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // 성별
                    Row(
                      children: [
                        Text("성별: "),
                        SizedBox(width: 16),
                        DropdownButton<String>(
                          value: tempSelectedGender,
                          items: ["남자", "여자"].map((gender) {
                            return DropdownMenuItem(
                              value: gender,
                              child: Text(gender),
                            );
                          }).toList(),
                          onChanged: (value) {
                            if (value != null) {
                              setState(() {
                                tempSelectedGender = value;
                              });
                            }
                          },
                        ),
                      ],
                    ),
                    // 출생 연도
                    Row(
                      children: [
                        Text("출생 연도: "),
                        SizedBox(width: 16),
                        DropdownButton<int>(
                          value: tempSelectedYear,
                          items: List.generate(100, (index) {
                            int year = DateTime.now().year - index;
                            return DropdownMenuItem(value: year, child: Text("$year"));
                          }),
                          onChanged: (value) {
                            if (value != null) {
                              setState(() {
                                tempSelectedYear = value;
                              });
                            }
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),

                    // 키/몸무게
                    TextField(
                      controller: heightCtrl,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(labelText: '키 (cm)'),
                      onChanged: (_) => _localCalculate(),
                    ),
                    TextField(
                      controller: weightCtrl,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(labelText: '몸무게 (kg)'),
                      onChanged: (_) => _localCalculate(),
                    ),

                    const Divider(),

                    // 권장 영양소
                    TextField(controller: calorieCtrl, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: '권장 칼로리 (kcal)')),
                    TextField(controller: carbCtrl, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: '권장 탄수화물 (g)')),
                    TextField(controller: proteinCtrl, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: '권장 단백질 (g)')),
                    TextField(controller: fatCtrl, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: '권장 지방 (g)')),
                    TextField(controller: sugarCtrl, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: '권장 당류 (g)')),
                    TextField(controller: sodiumCtrl, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: '권장 나트륨 (mg)')),
                    TextField(controller: cholesterolCtrl, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: '권장 콜레스테롤 (mg)')),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(dialogContext).pop(),
                  child: Text('취소'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    setState(() {
                      selectedGender = tempSelectedGender;
                      selectedYear = tempSelectedYear;
                      heightController.text = heightCtrl.text;
                      weightController.text = weightCtrl.text;
                      calorieController.text = calorieCtrl.text;
                      carbController.text = carbCtrl.text;
                      proteinController.text = proteinCtrl.text;
                      fatController.text = fatCtrl.text;
                      sugarController.text = sugarCtrl.text;
                      sodiumController.text = sodiumCtrl.text;
                      cholesterolController.text = cholesterolCtrl.text;
                    });

                    _calculateRecommendedNutrition();
                    await _saveUserInfo();
                    Navigator.of(dialogContext).pop();
                  },
                  child: Text('저장'),
                ),
              ],
            );
          },
        );
      },
    );
  }


  void _showCalendarBottomSheet() {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: TableCalendar(
            focusedDay: _focusedDay,
            firstDay: DateTime(2020),
            lastDay: DateTime(2030),
            selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
            onDaySelected: (selectedDay, focusedDay) {
              setState(() {
                _selectedDay = selectedDay;
                _focusedDay = focusedDay;
              });
              _loadRecordsForSelectedDay();
              Navigator.pop(context); // ✅ 날짜 선택 후 달력 닫기
            },
            calendarStyle: CalendarStyle(
              todayDecoration: BoxDecoration(
                color: Colors.greenAccent,
                shape: BoxShape.circle,
              ),
              selectedDecoration: BoxDecoration(
                color: Colors.green,
                shape: BoxShape.circle,
              ),
            ),
          ),
        );
      },
    );
  }


  void _showEditDialog(BuildContext context, Map<String, dynamic> record, {required String recordId}) {
    final nameController = TextEditingController(text: record['foodName']);
    final consumedController = TextEditingController(text: record['totalConsumed']);
    final caloriesController = TextEditingController(text: record['calories']);
    final carbController = TextEditingController(text: record['carbohydrates']);
    final proteinController = TextEditingController(text: record['protein']);
    final fatController = TextEditingController(text: record['fat']);
    final sugarController = TextEditingController(text: record['sugars']);
    final sodiumController = TextEditingController(text: record['sodium']);
    final cholController = TextEditingController(text: record['cholesterol']);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('섭취 기록 수정'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildTextField('이름', nameController),
                _buildTextField('섭취량 (g)', consumedController),
                _buildTextField('칼로리', caloriesController),
                _buildTextField('탄수화물', carbController),
                _buildTextField('단백질', proteinController),
                _buildTextField('지방', fatController),
                _buildTextField('당류', sugarController),
                _buildTextField('나트륨', sodiumController),
                _buildTextField('콜레스테롤', cholController),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('취소'),
            ),
            TextButton(
              onPressed: () async {
                await FirebaseFirestore.instance
                    .collection('sjsk_users')
                    .doc(FirebaseAuth.instance.currentUser!.email)
                    .collection(DateTime.now().toIso8601String().split('T')[0])
                    .doc(recordId)
                    .delete();
                Navigator.pop(context);
              },
              child: Text('삭제', style: TextStyle(color: Colors.red)),
            ),
            ElevatedButton(
              onPressed: () async {
                await FirebaseFirestore.instance
                    .collection('sjsk_users')
                    .doc(FirebaseAuth.instance.currentUser!.email)
                    .collection(DateTime.now().toIso8601String().split('T')[0])
                    .doc(recordId)
                    .update({
                  'foodName': nameController.text,
                  'totalConsumed': consumedController.text,
                  'calories': caloriesController.text,
                  'carbohydrates': carbController.text,
                  'protein': proteinController.text,
                  'fat': fatController.text,
                  'sugars': sugarController.text,
                  'sodium': sodiumController.text,
                  'cholesterol': cholController.text,
                });
                Navigator.pop(context);
              },
              child: Text('저장'),
            )
          ],
        );
      },
    );
  }

  Future<void> fetchSelectedDayRecords() async {
    final formattedDate = DateFormat('yyyy-MM-dd').format(_selectedDay!);
    final snapshot = await FirebaseFirestore.instance
        .collection('sjsk_users')
        .doc(widget.userId)
        .collection(formattedDate)
        .get();

    final records = snapshot.docs.map((doc) {
      final data = doc.data();
      data['recordId'] = doc.id;
      return data;
    }).toList();

    setState(() {
      _selectedDayRecords = records;
    });
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(),
          isDense: true,
        ),
      ),
    );
  }


  void _showEditDialogFromMap(
      BuildContext context,
      Map<String, dynamic> record,
      String recordId,
      ) {
    final foodNameController = TextEditingController(text: record['foodName']);
    final amountController = TextEditingController(text: record['totalConsumed']);
    final caloriesController = TextEditingController(text: record['calories']);
    final carbsController = TextEditingController(text: record['carbohydrates']);
    final proteinController = TextEditingController(text: record['protein']);
    final fatController = TextEditingController(text: record['fat']);
    final sugarsController = TextEditingController(text: record['sugars']);
    final sodiumController = TextEditingController(text: record['sodium']);
    final cholesterolController = TextEditingController(text: record['cholesterol']);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("섭취 기록 수정"),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildTextField('음식명', foodNameController),
              _buildTextField('섭취량(g)', amountController),
              _buildTextField('칼로리(kcal)', caloriesController),
              _buildTextField('탄수화물(g)', carbsController),
              _buildTextField('단백질(g)', proteinController),
              _buildTextField('지방(g)', fatController),
              _buildTextField('당류(g)', sugarsController),
              _buildTextField('나트륨(mg)', sodiumController),
              _buildTextField('콜레스테롤(mg)', cholesterolController),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("취소"),
          ),
          TextButton(
            onPressed: () async {
              final userId = FirebaseAuth.instance.currentUser?.email ?? '';
              final dateKey = (record['timestamp'] as Timestamp).toDate().toIso8601String().split('T')[0];

              await FirebaseFirestore.instance
                  .collection('sjsk_users')
                  .doc(userId)
                  .collection(dateKey)
                  .doc(recordId)
                  .delete();

              Navigator.pop(context);
              await fetchSelectedDayRecords();
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("기록이 삭제되었습니다.")));
            },
            child: const Text("삭제", style: TextStyle(color: Colors.red)),
          ),
          ElevatedButton(
            onPressed: () async {
              final userId = FirebaseAuth.instance.currentUser?.email ?? '';
              final dateKey = (record['timestamp'] as Timestamp).toDate().toIso8601String().split('T')[0];

              await FirebaseFirestore.instance
                  .collection('sjsk_users')
                  .doc(userId)
                  .collection(dateKey)
                  .doc(recordId)
                  .update({
                'foodName': foodNameController.text,
                'totalConsumed': amountController.text,
                'calories': caloriesController.text,
                'carbohydrates': carbsController.text,
                'protein': proteinController.text,
                'fat': fatController.text,
                'sugars': sugarsController.text,
                'sodium': sodiumController.text,
                'cholesterol': cholesterolController.text,
              });

              Navigator.pop(context);
              await fetchSelectedDayRecords();
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("기록이 수정되었습니다.")));
            },
            child: const Text("저장"),
          ),
        ],
      ),
    );
  }



  @override
  Widget build(BuildContext context) {

    double totalCal = _selectedDayRecords.fold(0, (sum, r) => sum + (double.tryParse(r["calories"].toString()) ?? 0));
    double totalCarb = _selectedDayRecords.fold(0, (sum, r) => sum + (double.tryParse(r["carbohydrates"].toString()) ?? 0));
    double totalPro = _selectedDayRecords.fold(0, (sum, r) => sum + (double.tryParse(r["protein"].toString()) ?? 0));
    double totalFat = _selectedDayRecords.fold(0, (sum, r) => sum + (double.tryParse(r["fat"].toString()) ?? 0));

    double recCal = double.tryParse(calorieController.text) ?? 1;
    double recCarb = double.tryParse(carbController.text) ?? 1;
    double recPro = double.tryParse(proteinController.text) ?? 1;
    double recFat = double.tryParse(fatController.text) ?? 1;

    final analysisList = generateAnalysisTextList(
      nutrientNames: ["칼로리", "탄수화물", "단백질", "지방"],
      actuals: [totalCal, totalCarb, totalPro, totalFat],
      recommended: [recCal, recCarb, recPro, recFat],
    );


    return Scaffold(

      body: SingleChildScrollView(
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 사용자 ID 출력
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(
                  "사용자 ID: ${widget.userId}",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ),

              // 나의 신체 정보 입력 UI
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("나의 신체 정보", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        IconButton(
                          icon: Icon(Icons.edit),
                          onPressed: _showEditBodyInfoDialog,
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // "나의 섭취 기록"
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Text(
                  "나의 섭취 기록",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),

              // 날짜 표시 + 날짜 선택 버튼
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: OutlinedButton.icon(
                  icon: Icon(Icons.calendar_today, size: 20),
                  label: Text(
                    "날짜 선택: ${DateFormat('yyyy-MM-dd').format(_selectedDay!)}",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87,
                    ),
                  ),
                  onPressed: _showCalendarBottomSheet,
                  style: OutlinedButton.styleFrom(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    side: BorderSide(color: Colors.deepPurple),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.deepPurple,
                  ),
                ),
              ),

              const SizedBox(height: 16),

              // 선택된 날짜 섭취 기록 출력
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Text(
                  "선택된 날짜의 섭취 기록",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),

              AnimatedSize(
                duration: Duration(milliseconds: 300),
                curve: Curves.easeInOut,
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxHeight: 360, // ✅ 최대 높이 설정 (예: 음식 5개까지 보이는 정도)
                  ),
                  child: _selectedDayRecords.isEmpty
                      ? Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text("기록이 없습니다."),
                  )
                      : ListView.builder(
                    physics: ClampingScrollPhysics(), // 내부 스크롤 허용
                    shrinkWrap: true,
                    itemCount: _selectedDayRecords.length,
                    itemBuilder: (context, index) {
                      final record = _selectedDayRecords[index];
                      final recordId = record['recordId'];
                      final isExpanded = expandedIndexes.contains(index);


                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        elevation: 4,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTap: () {
                                  setState(() {
                                    if (expandedIndexes.contains(index)) {
                                      expandedIndexes.remove(index);
                                    } else {
                                      expandedIndexes.add(index);
                                    }
                                  });
                                },
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            record["foodName"] ?? "음식 정보 없음",
                                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                          ),
                                          Text("섭취량: ${record["totalConsumed"]}g"),
                                        ],
                                      ),
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.edit),
                                      onPressed: () {
                                        _showEditDialogFromMap(context, record, recordId);
                                      },
                                    ),
                                  ],
                                ),
                              ),
                              AnimatedCrossFade(
                                duration: const Duration(milliseconds: 250),
                                crossFadeState: expandedIndexes.contains(index)
                                    ? CrossFadeState.showSecond
                                    : CrossFadeState.showFirst,
                                firstChild: const SizedBox.shrink(),
                                secondChild: Padding(
                                  padding: const EdgeInsets.only(top: 8),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text("칼로리: ${record["calories"]} kcal"),
                                      Text("탄수화물: ${record["carbohydrates"]} g"),
                                      Text("단백질: ${record["protein"]} g"),
                                      Text("지방: ${record["fat"]} g"),
                                      Text("당류: ${record["sugars"]} g"),
                                      Text("나트륨: ${record["sodium"]} mg"),
                                      Text("콜레스테롤: ${record["cholesterol"]} mg"),
                                      Text(
                                        "기록 시간: ${record["timestamp"].toDate()}",
                                        style: const TextStyle(color: Colors.grey),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );


                    },
                  ),
                ),
              ),


              // ✅ 분석 그래프 추가 위치!
              if (_selectedDayRecords.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "일일 섭취 분석",
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 12),

                      // ✅ 여기에 그래프 위젯 호출
                      buildNutritionBarChart(
                        calorie: totalCal, carb: totalCarb, protein: totalPro, fat: totalFat,
                        caloRec: recCal, carbRec: recCarb, proteinRec: recPro, fatRec: recFat,
                      ),
                    ],
                  ),
                ),

              // 🔍 오늘의 분석 UI
              if (_selectedDayRecords.isNotEmpty && analysisList.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                  child: Container(
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Color(0xFFF8F7FC),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.deepPurple.withOpacity(0.4)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "🔍 오늘의 분석",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.deepPurple,
                          ),
                        ),
                        const SizedBox(height: 8),
                        ...analysisList.map((line) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 2.0),
                          child: Text(line),
                        )),
                      ],
                    ),
                  ),
                ),
              
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Text(
                  "일주일간 섭취 분석",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),

              Padding(
                padding: const EdgeInsets.all(16.0),
                child: FutureBuilder<Map<String, dynamic>>(
                  future: getWeeklyNutritionRatios(widget.userId, _selectedDay!),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) return CircularProgressIndicator();

                    final data = snapshot.data!;
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        buildWeeklyNutritionChartWithLegend(
                          dates: data["dates"]!,
                          calorieRatios: data["calories"]!,
                          carbRatios: data["carbs"]!,
                          proteinRatios: data["proteins"]!,
                          fatRatios: data["fats"]!,
                        ),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            ElevatedButton.icon(
                              onPressed: () async {
                                final shouldLogout = await showDialog<bool>(
                                  context: context,
                                  builder: (context) => AlertDialog(
                                    title: Text('로그아웃하시겠습니까?'),
                                    content: Text('로그아웃하면 일부 기능을 사용할 수 없습니다.'),
                                    actions: [
                                      TextButton(
                                        onPressed: () => Navigator.of(context).pop(false),
                                        child: Text('취소'),
                                      ),
                                      ElevatedButton(
                                        onPressed: () => Navigator.of(context).pop(true),
                                        child: Text('로그아웃'),
                                      ),
                                    ],
                                  ),
                                );

                                if (shouldLogout == true) {
                                  await FirebaseAuth.instance.signOut();
                                  Navigator.of(context).pushAndRemoveUntil(
                                    MaterialPageRoute(builder: (context) => AuthWrapper()),
                                        (route) => false,
                                  );
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.grey[800],
                                foregroundColor: Colors.white,
                              ),
                              icon: Icon(Icons.logout),
                              label: Text('로그아웃'),
                            ),
                          ],
                        ),
                      ],
                    );
                  },
                ),
              ),

            ],
          ),
      ),
    );
  }


}



List<String> generateAnalysisTextList({
  required List<String> nutrientNames,
  required List<double> actuals,
  required List<double> recommended,
}) {
  List<String> analysis = [];

  for (int i = 0; i < nutrientNames.length; i++) {
    final name = nutrientNames[i];
    final actual = actuals[i];
    final rec = recommended[i];

    if (rec == 0) {
      analysis.add("$name: 권장량 정보 없음");
      continue;
    }

    final ratio = (actual / rec) * 100;

    if (ratio < 90) {
      analysis.add("$name: 권장량보다 부족함");
    } else if (ratio > 110) {
      analysis.add("$name: 권장량보다 초과함");
    } else {
      analysis.add("$name: 적정 수준");
    }
  }

  return analysis;
}


// 일일 섭취 통계 그래프
Widget buildNutritionBarChart({
  required double calorie, required double carb,
  required double protein, required double fat,
  required double caloRec, required double carbRec,
  required double proteinRec, required double fatRec,
}) {
  List<_NutrientBar> bars = [
    _NutrientBar(name: "칼로리", value: calorie, recommended: caloRec, unit: "kcal"),
    _NutrientBar(name: "탄수화물", value: carb, recommended: carbRec, unit: "g"),
    _NutrientBar(name: "단백질", value: protein, recommended: proteinRec, unit: "g"),
    _NutrientBar(name: "지방", value: fat, recommended: fatRec, unit: "g"),
  ];

  // 최대 퍼센트 계산 → 시각적으로 가장 높은 바 기준으로 maxY 조절
  num maxBarHeight = bars.map((bar) {
    double percent = (bar.recommended == 0) ? 0 : (bar.value / bar.recommended) * 100;
    return percent > 100 ? percent : 100;
  }).reduce((a, b) => a > b ? a : b);

  double maxY = (maxBarHeight / 50).ceil() * 50;
  double interval = maxY <= 100 ? 20 : 50;

  return SizedBox(
    height: 300,
    child: BarChart(
      BarChartData(
        maxY: maxY,
        barGroups: bars.asMap().entries.map((entry) {
          int i = entry.key;
          final bar = entry.value;
          double percent = (bar.recommended == 0) ? 0 : (bar.value / bar.recommended) * 100;

          List<BarChartRodStackItem> stackItems = [
            BarChartRodStackItem(0, 100, Colors.grey[300]!), // 기준 회색 먼저
            if (percent > 0)
              BarChartRodStackItem(0, percent.clamp(0, 100), Colors.green), // 섭취량 초록
            if (percent > 100)
              BarChartRodStackItem(100, percent, Colors.red), // 초과 빨간
          ];

          return BarChartGroupData(
            x: i,
            barRods: [
              BarChartRodData(
                fromY: 0,
                toY: percent > 100 ? percent : 100, // 전체 길이는 최대값 기준
                rodStackItems: stackItems,
                width: 20,
              ),
            ],
          );
        }).toList(),
        titlesData: FlTitlesData(
          show: true,
          topTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 30,
              getTitlesWidget: (value, meta) {
                final bar = bars[value.toInt()];
                final percent = (bar.recommended == 0) ? 0 : (bar.value / bar.recommended) * 100;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text("${percent.toStringAsFixed(0)}%", style: TextStyle(fontSize: 12)),
                );
              },
            ),
          ),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 42,
              getTitlesWidget: (value, meta) {
                final bar = bars[value.toInt()];
                return Column(
                  children: [
                    Text(bar.name, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                    SizedBox(height: 2),
                    Text(
                      "${bar.value.toStringAsFixed(1)} / ${bar.recommended.toStringAsFixed(1)} ${bar.unit}",
                      style: TextStyle(fontSize: 10),
                    ),
                  ],
                );
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 30,
              interval: interval,
              getTitlesWidget: (value, meta) {
                return Text("${value.toInt()}", style: TextStyle(fontSize: 12));
              },
            ),
          ),
          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        gridData: FlGridData(
          show: true,
          drawHorizontalLine: true,
          drawVerticalLine: false, // ✅ 수직선은 표시하지 않음
          getDrawingHorizontalLine: (value) => FlLine(
            color: Colors.grey[300], // 연한 회색 가로선
            strokeWidth: 1,
          ),
        ),
        borderData: FlBorderData(show: false),
      ),
    ),
  );
}


class _NutrientBar {
  final String name;
  final double value;
  final double recommended;
  final String unit;
  _NutrientBar({required this.name, required this.value, required this.recommended, required this.unit});
}



// 일주일 섭취 통계 그래프
Widget buildWeeklyNutritionLineChart({
  required List<String> dates,
  required List<double> calorieRatios,
  required List<double> carbRatios,
  required List<double> proteinRatios,
  required List<double> fatRatios,
}) {
  final nutrientLines = [
    _LineData("칼로리", calorieRatios, Colors.orange),
    _LineData("탄수화물", carbRatios, Colors.blue),
    _LineData("단백질", proteinRatios, Colors.green),
    _LineData("지방", fatRatios, Colors.red),
  ];


  // ✅ maxY 동적 계산 (50 단위 반올림)
  final allValues = [
    ...calorieRatios,
    ...carbRatios,
    ...proteinRatios,
    ...fatRatios,
  ];
  final maxRatio = allValues.reduce((a, b) => a > b ? a : b);
  final maxY = ((maxRatio > 100 ? maxRatio : 100) / 50).ceil() * 50.0;
  double interval = (maxY <= 100) ? 20 : 50;  //   // 🔸 최대 퍼센트 계산


  return SizedBox(
    height: 300,
    child: LineChart(
      LineChartData(
        minY: 0,
        maxY: maxY, // ✅ 동적 y축 최대값
        clipData: FlClipData.all(),
        gridData: FlGridData(
          show: true,
          drawHorizontalLine: true,
          drawVerticalLine: true, // ✅ 수직선 표시 허용
          getDrawingVerticalLine: (value) {
            if (value % 1 == 0) {
              return FlLine(
                color: Colors.grey[300], // 연한 회색 선
                strokeWidth: 1,
              );
            }
            return FlLine(color: Colors.transparent); // 소수점엔 선 없음
          },
        ),
        borderData: FlBorderData(show: true),
        titlesData: FlTitlesData(
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              interval: interval, // ✅ 동적 눈금 간격
              getTitlesWidget: (value, meta) =>
                  Text('${value.toInt()}%', style: TextStyle(fontSize: 11)),
              reservedSize: 28,
            ),
          ),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 40,
              getTitlesWidget: (value, meta) {
                // ✅ 정수 값만 처리
                if (value % 1 != 0) return const SizedBox.shrink();

                int index = value.toInt();
                if (index < 0 || index >= dates.length) return const SizedBox.shrink();

                return Transform.rotate(
                  angle: -0.5, // 날짜 라벨 기울임
                  child: Text(
                    dates[index].substring(5), // MM-DD 형식
                    style: const TextStyle(fontSize: 10),
                  ),
                );
              },
              interval: 1, // ✅ x축 정수 간격 보장
            ),
          ),

          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        lineBarsData: nutrientLines.map((line) {
          return LineChartBarData(
            isCurved: true,
            preventCurveOverShooting: true,
            color: line.color,
            barWidth: 2.5,
            dotData: FlDotData(show: true),
            spots: line.ratios
                .asMap()
                .entries
                .map((e) => FlSpot(e.key.toDouble(), e.value))
                .toList(),
          );
        }).toList(),
        extraLinesData: ExtraLinesData(horizontalLines: [
          HorizontalLine(
            y: 100,
            color: Colors.grey,
            strokeWidth: 1,
            dashArray: [4, 4],
            label: HorizontalLineLabel(
              show: true,
              alignment: Alignment.centerRight,
              labelResolver: (_) => "권장 기준 100%",
              style: TextStyle(fontSize: 10, fontStyle: FontStyle.italic),
            ),
          ),
        ]),
      ),
    ),
  );
}

Widget buildWeeklyNutritionChartWithLegend({
  required List<String> dates,
  required List<double> calorieRatios,
  required List<double> carbRatios,
  required List<double> proteinRatios,
  required List<double> fatRatios,
}) {
  return Column(
    children: [
      buildWeeklyNutritionLineChart(
        dates: dates,
        calorieRatios: calorieRatios,
        carbRatios: carbRatios,
        proteinRatios: proteinRatios,
        fatRatios: fatRatios,
      ),
      const SizedBox(height: 12),
      Wrap(
        alignment: WrapAlignment.center,
        spacing: 12,
        runSpacing: 4,
        children: [
          _buildLegendDot(Colors.orange, "칼로리"),
          _buildLegendDot(Colors.blue, "탄수화물"),
          _buildLegendDot(Colors.green, "단백질"),
          _buildLegendDot(Colors.red, "지방"),
        ],
      ),
    ],
  );
}

Widget _buildLegendDot(Color color, String label) {
  return Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Container(
        width: 10,
        height: 10,
        margin: const EdgeInsets.only(right: 4),
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      ),
      Text(label, style: const TextStyle(fontSize: 12)),
    ],
  );
}


class _LineData {
  final String label;
  final List<double> ratios;
  final Color color;
  _LineData(this.label, this.ratios, this.color);
}



Future<Map<String, dynamic>> getWeeklyNutritionRatios(String userId, DateTime baseDay) async {
  List<String> getLast7Dates(DateTime base) {
    return List.generate(7, (index) {
      final date = base.subtract(Duration(days: 6 - index));
      return "${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}";
    });
  }

  final firestore = FirebaseFirestore.instance;
  final dates = getLast7Dates(baseDay);

  final userDoc = await firestore.collection('sjsk_users').doc(userId).get();
  final userData = userDoc.data()!;
  final caloRec = (userData['calories'] as num?)?.toDouble() ?? 1;
  final carbRec = (userData['carbohydrates'] as num?)?.toDouble() ?? 1;
  final proteinRec = (userData['protein'] as num?)?.toDouble() ?? 1;
  final fatRec = (userData['fat'] as num?)?.toDouble() ?? 1;

  List<double> calorieRatios = [];
  List<double> carbRatios = [];
  List<double> proteinRatios = [];
  List<double> fatRatios = [];



  for (final date in dates) {
    final snapshot = await firestore
        .collection('sjsk_users')
        .doc(userId)
        .collection(date)
        .get();

    double totalCal = 0, totalCarb = 0, totalPro = 0, totalFat = 0;

    for (final doc in snapshot.docs) {
      final d = doc.data();
      totalCal += (double.tryParse(d['calories']?.toString() ?? '0') ?? 0);
      totalCarb += (double.tryParse(d['carbohydrates']?.toString() ?? '0') ?? 0);
      totalPro += (double.tryParse(d['protein']?.toString() ?? '0') ?? 0);
      totalFat += (double.tryParse(d['fat']?.toString() ?? '0') ?? 0);
    }


    double safeRatio(double total, double recommended) {
      if (recommended == 0) return 0;
      double ratio = (total / recommended) * 100;
      return ratio.clamp(0, 500); // ✅ 음수 방지 + 상한 설정
    }


    calorieRatios.add(safeRatio(totalCal, caloRec));
    carbRatios.add(safeRatio(totalCarb, carbRec));
    proteinRatios.add(safeRatio(totalPro, proteinRec));
    fatRatios.add(safeRatio(totalFat, fatRec));

  }

  return {
    "dates": dates, // ✅ List<String>
    "calories": calorieRatios, // ✅ List<double>
    "carbs": carbRatios,
    "proteins": proteinRatios,
    "fats": fatRatios,
  };
}









