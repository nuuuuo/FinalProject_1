import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class FoodSearchScreen extends StatefulWidget {
  @override
  _FoodSearchScreenState createState() => _FoodSearchScreenState();
}

class _FoodSearchScreenState extends State<FoodSearchScreen> {
  final TextEditingController _controller = TextEditingController();
  List<Map<String, dynamic>> _searchResults = [];
  bool _isLoading = false;
  int _currentPage = 1;
  int _totalPages = 0;
  static const int _itemsPerPage = 10;
  String _currentQuery = '';

  Future<void> _performSearch(String query, {int pageNo = 1}) async {
    setState(() {
      _isLoading = true;
      _searchResults = [];
      if (query != _currentQuery) {
        _currentPage = 1;
      }
      _currentQuery = query;
    });

    final String apiUrl =
        'https://apis.data.go.kr/1471000/FoodNtrCpntDbInfo01/getFoodNtrCpntDbInq01';
    final String serviceKey = 'XgwptjbbJW9Kj0dDUwg4g47BpypKMzQrg%2ByaUu6Vs%2BI2nmZpO%2BMzm9zl%2FnJvp2%2BnElg4FgOKt8r1Na6kt4FKmQ%3D%3D';

    final Uri uri = Uri.parse(
        '$apiUrl?serviceKey=$serviceKey&FOOD_NM_KR=${Uri.encodeComponent(query)}&pageNo=$pageNo&numOfRows=$_itemsPerPage&type=json');

    try {
      final response = await http.get(uri);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['header']['resultCode'] == '00') {
          final totalCount =
              int.tryParse(data['body']['totalCount']?.toString() ?? '0') ?? 0;
          _totalPages = (totalCount / _itemsPerPage).ceil();

          final items = data['body']['items'];
          if (items != null) {
            List<dynamic> itemList;

            if (items is List) {
              itemList = items;
            } else if (items is Map && items['item'] is List) {
              itemList = items['item'];
            } else if (items is Map && items['item'] is Map) {
              itemList = [items['item']];
            } else {
              itemList = [];
            }

            setState(() {
              _searchResults = itemList
                  .map((item) => {
                'FOOD_NM_KR': item['FOOD_NM_KR'] as String,
                'MAKER_NM': item['MAKER_NM'],
                'DB_GRP_NM': item['DB_GRP_NM'],
                'AMT_NUM1': item['AMT_NUM1'],
                'AMT_NUM6': item['AMT_NUM6'],
                'AMT_NUM3': item['AMT_NUM3'],
                'AMT_NUM4': item['AMT_NUM4'],
                'AMT_NUM7': item['AMT_NUM7'],
                'AMT_NUM13': item['AMT_NUM13'],
                'ITEM_REPORT_NO': item['ITEM_REPORT_NO'],
              })
                  .toList();
            });
          } else {
            setState(() {
              _searchResults = [{'FOOD_NM_KR': '검색 결과 없음'}];
              _totalPages = 1;
            });
          }
        }
      }
    } catch (e) {
      setState(() {
        _searchResults = [{'FOOD_NM_KR': '오류 발생: $e'}];
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('식품 검색')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: '검색어 입력...',
              ),
              onSubmitted: (query) {
                if (query.isNotEmpty) {
                  _performSearch(query);
                }
              },
            ),
            ElevatedButton(
              onPressed: () {
                if (_controller.text.isNotEmpty) {
                  _performSearch(_controller.text);
                }
              },
              child: const Text('검색'),
            ),
            if (_isLoading) const CircularProgressIndicator(),
            if (_searchResults.isNotEmpty)
              Expanded(
                child: ListView.builder(
                  itemCount: _searchResults.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Text(_searchResults[index]['FOOD_NM_KR'] ?? 'N/A'),
                      subtitle: Text(
                          '제조사: ${_searchResults[index]['MAKER_NM'] ?? 'N/A'}'),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => FoodDetailPage(
                              foodItem: _searchResults[index],
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class FoodDetailPage extends StatelessWidget {
  final Map<String, dynamic> foodItem;

  const FoodDetailPage({super.key, required this.foodItem});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(foodItem['FOOD_NM_KR'] ?? '식품 상세정보')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('제조사: ${foodItem['MAKER_NM'] ?? 'N/A'}'),
            Text('칼로리: ${foodItem['AMT_NUM1'] ?? 'N/A'} kcal'),
            Text('탄수화물: ${foodItem['AMT_NUM6'] ?? 'N/A'} g'),
            Text('단백질: ${foodItem['AMT_NUM3'] ?? 'N/A'} g'),
            Text('지방: ${foodItem['AMT_NUM4'] ?? 'N/A'} g'),
            Text('당류: ${foodItem['AMT_NUM7'] ?? 'N/A'} g'),
            Text('나트륨: ${foodItem['AMT_NUM13'] ?? 'N/A'} mg'),
          ],
        ),
      ),
    );
  }
}




