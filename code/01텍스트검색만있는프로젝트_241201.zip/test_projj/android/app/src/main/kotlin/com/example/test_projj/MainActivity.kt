package com.example.test_projj

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
