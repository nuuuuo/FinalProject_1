package com.doinglab.foodlens2.example

import android.Manifest
import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.util.Log
import android.widget.ProgressBar
import android.widget.Toast
import android.widget.ImageView
import android.widget.TextView
import android.app.Activity
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
//import androidx.databinding.DataBindingUtil
//import com.doinglab.foodlens2.example.listview.ListItem
//import com.doinglab.foodlens2.example.listview.SampleListAdapter
import com.doinglab.foodlens2.sdk.FoodLens
import com.doinglab.foodlens2.sdk.RecognitionResultHandler
import com.doinglab.foodlens2.sdk.config.LanguageConfig
import com.doinglab.foodlens2.sdk.errors.BaseError
import com.doinglab.foodlens2.sdk.model.RecognitionResult
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Base64
import java.util.UUID
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import android.content.Context
import kotlinx.coroutines.*
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import com.doinglab.foodlens2.example.ParseUtils
import org.apache.poi.util.IOUtils
import com.monitorjbl.xlsx.StreamingReader
import javax.xml.parsers.DocumentBuilderFactory
import org.apache.poi.ss.usermodel.Workbook
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.apache.poi.ss.usermodel.*;
import java.lang.Exception
import org.apache.poi.openxml4j.exceptions.OLE2NotOfficeXmlFileException
import org.xml.sax.SAXNotRecognizedException
import org.apache.poi.ss.usermodel.WorkbookFactory
import org.apache.poi.openxml4j.opc.OPCPackage
import org.apache.poi.xssf.eventusermodel.XSSFReader
import org.xml.sax.Attributes
import org.xml.sax.InputSource
import java.io.FileInputStream
import org.xml.sax.SAXException
import org.xml.sax.helpers.DefaultHandler
import javax.xml.parsers.SAXParserFactory
import org.apache.poi.openxml4j.opc.PackageAccess
import com.doinglab.foodlens2.example.model.ExcelRow
import com.alibaba.excel.context.AnalysisContext
import com.alibaba.excel.event.AnalysisEventListener
import com.alibaba.excel.EasyExcel
import android.content.res.AssetManager
import java.io.FileOutputStream
import org.opencv.android.OpenCVLoader
import org.opencv.core.Scalar
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import com.google.gson.Gson



class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.doinglab.foodlens2.example"

    companion object {
        lateinit var methodChannel: MethodChannel
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        methodChannel.setMethodCallHandler { call, result ->
            when (call.method) {
                "openGallery" -> openCameraActivity("gallery", result)
                "openCamera" -> openCameraActivity("camera", result)

                // ✅ Flutter → 음식 이름 검색 요청 처리
                "searchFoodByName" -> {
                    val foodName = call.argument<String>("query") ?: ""
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val searchResult = getProductInfoFromAPI(this@MainActivity, foodName)
                            withContext(Dispatchers.Main) {
                                result.success(searchResult)  // Flutter로 결과 전송
                            }
                        } catch (e: Exception) {
                            Log.e("searchFoodByName", "검색 실패", e)
                            withContext(Dispatchers.Main) {
                                result.error("SEARCH_FAILED", "음식 검색 실패", null)
                            }
                        }
                    }
                }

                else -> result.notImplemented()
            }
        }
    }


    private fun openCameraActivity(action: String, result: MethodChannel.Result) {
        val intent = Intent(this, CameraActivity::class.java)
        intent.putExtra("action", action)
        startActivityForResult(intent, 1001) // requestCode를 1001로 설정
    }



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        try {
            if (requestCode == 1001 && resultCode == Activity.RESULT_OK) {
                val ocrResults = data?.getStringExtra("ocrResults") ?: "OCR 결과 없음"
                val parsedData = ParseUtils.parseOcrResponse(ocrResults)
                val recognitionResults = data?.getStringExtra("recognitionResults") ?: "두잉랩 결과 없음"
//                val resultMap: MutableMap<String, Any> = validationResult.toMutableMap()

//                resultMap["ocrResults"] = ocrResults
//                resultMap["recognitionResults"] = recognitionResults

//                methodChannel.invokeMethod("returnValidationResult", resultMap)

                val extractedProductName = parsedData["제품명"] ?: "Unknown"
                val extractedSerialNumber = parsedData["품목보고번호"] ?: "Unknown"

                Log.d("OCR 결과", "📝 OCR 추출 제품명: $extractedProductName, 품목보고번호: $extractedSerialNumber")

                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        // 텍스트 파일에서 품목보고번호 검색
                        val excelProductName = findProductNameBySerialNumber(this@MainActivity, extractedSerialNumber)

                        // API에서 OCR 제품명 검색
                        val apiProductList = getAllMatchingProductInfoFromAPI(this@MainActivity, extractedProductName)
                        val apiProductName = apiProductList.firstOrNull()?.get("FOOD_NM_KR") ?: "API 검색 실패"

                        // API에서 텍스트 파일 제품명 검색
                        val apiExcelProductList = excelProductName?.let {
                            val result = getProductInfoFromAPI(this@MainActivity, it)
                            Log.d("검증 결과", "✅ API 품목번호 기반 제품 리스트: $result")
                            result
                        }

                        val apiExcelProductName = apiExcelProductList?.firstOrNull()?.get("FOOD_NM_KR")


                        val validationResult = when {
                            apiProductName == apiExcelProductName && apiProductName != "API 검색 실패" -> {
                                Log.d("검증 결과", "✅ 신뢰도 높음: $apiProductName")
                                mapOf("status" to "high_confidence", "message" to "✅ 신뢰도 높음: $apiProductName")
                            }
                            apiProductName != "API 검색 실패" && apiExcelProductName != null -> {
                                Log.d("검증 결과", "⚠️ 불일치: API: $apiProductName | 텍스트파일: $apiExcelProductName")
                                mapOf("status" to "mismatch", "message" to "OCR 결과를 찾을 수 없습니다.")
                            }
                            apiProductName != "API 검색 실패" -> {
                                Log.d("검증 결과", "✅ OCR 기반 정보 있음: $apiProductName")
                                mapOf("status" to "success", "message" to "OCR 기반 탐색 결과입니다.")
                            }
                            apiExcelProductName != null -> {
                                Log.d("검증 결과", "✅ 품목보고번호 기반 정보 있음: $apiExcelProductName")
                                mapOf("status" to "success", "message" to "OCR 기반 탐색 결과입니다.")
                            }
                            excelProductName == null -> {
                                Log.d("검증 결과", "❌ 텍스트파일에서 품목보고번호를 찾을 수 없음")
                                mapOf("status" to "textfile_fail", "message" to "OCR 결과를 찾을 수 없습니다.")
                            }
                            else -> {
                                Log.d("검증 결과", "⚠️ 제품 정보 불확실")
                                mapOf("status" to "uncertain", "message" to "OCR 결과를 찾을 수 없습니다.")
                            }
                        }


                        val resultMap: MutableMap<String, Any> = validationResult.toMutableMap()

                        resultMap["ocrResults"] = ocrResults
                        resultMap["recognitionResults"] = recognitionResults

                        // 우선순위: 품목보고번호 기반 -> OCR 기반
                        val finalProductList = when {
                            apiExcelProductList != null && apiExcelProductList.isNotEmpty() -> apiExcelProductList  // 품목보고번호 결과 우선
                            apiProductList.isNotEmpty() -> apiProductList                                           // 제품명 결과는 fallback
                            else -> emptyList()
                        }


                        if (finalProductList.isNotEmpty()) {
                            val productList = finalProductList.map { HashMap(it) as HashMap<String, String> }
                            resultMap["products"] = productList
                            Log.d("Flutter 전달 직전", "📤 전달할 products: $productList")
                        } else {
                            Log.d("Flutter 전달 직전", "📤 전달할 products 없음")
                        }

                        withContext(Dispatchers.Main) {
                            methodChannel.invokeMethod("returnValidationResult", resultMap)
                        }

                    } catch (e: Exception) {
                        Log.e("검증 오류", "🚨 검증 중 오류 발생", e)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("MainActivity", "🚨 onActivityResult 오류", e)
        }
    }


    // 파일에서 일치하는 품목보고번호 있는지 확인하는 함수
    fun findProductNameBySerialNumber(context: Context, serialNumber: String): String? {
        try {
            val fileName = "20250327_가공식품DB_147999건.txt"  // ✅ assets 폴더 내 텍스트 파일명
            val cacheFile = File(context.cacheDir, fileName)

            // ✅ 1. 텍스트 파일이 없으면 assets에서 복사
            if (!cacheFile.exists()) {
                try {
                    val assetManager: AssetManager = context.assets
                    val inputStream: InputStream = assetManager.open(fileName)
                    val outputStream = FileOutputStream(cacheFile)
                    val buffer = ByteArray(1024)
                    var read: Int

                    while (inputStream.read(buffer).also { read = it } != -1) {
                        outputStream.write(buffer, 0, read)
                    }

                    inputStream.close()
                    outputStream.flush()
                    outputStream.close()

                    Log.d("FileCopy", "✅ 텍스트 파일 복사 완료: ${cacheFile.absolutePath}")
                } catch (e: IOException) {
                    Log.e("FileCopy", "🚨 텍스트 파일 복사 실패", e)
                    return null
                }
            } else {
                Log.d("FileCopy", "📂 텍스트 파일 이미 존재함: ${cacheFile.absolutePath}")
            }

            // ✅ 2. 텍스트 파일이 정상적으로 존재하는지 확인
            if (!cacheFile.exists()) {
                Log.e("TextFileCheck", "🚨 텍스트 파일이 여전히 존재하지 않습니다.")
                return null
            } else {
                Log.d("TextFileCheck", "📂 텍스트 파일이 정상적으로 존재합니다.")
            }

            var result: String? = null

            // ✅ 3. 텍스트 파일을 읽어 품목보고번호 검색
            cacheFile.bufferedReader().useLines { lines ->
                for (line in lines) {
                    val parts = line.split("\t") // 탭으로 구분
                    if (parts.size == 2) {
                        val foodName = parts[0]
                        val reportNumber = parts[1]
                        if (reportNumber == serialNumber) {
                            result = foodName
                            break // ✅ 찾으면 더 이상 읽지 않음
                        }
                    }
                }
            }

            return result // ✅ 검색 실패 시 null 반환

        } catch (e: IOException) {
            Log.e("TextFileError", "🚨 텍스트 파일 읽기 실패", e)
            return null
        } catch (e: Exception) {
            Log.e("TextFileError", "🚨 예외 발생", e)
            return null
        }
    }



    // 교정된 제품명을 기반으로 OpenAPI에서 제품 검색
    private suspend fun getProductInfoFromAPI(context: Context, productName: String): List<Map<String, String>> {
        val filePath = "20250327_가공식품DB_147999건.txt"
        return withContext(Dispatchers.IO) {
            try {
                // OCR 보정 적용 (API에서 유사한 제품명을 찾아 자동 수정)
                val correctedProductName = correctProductNameFromFile(context, productName, filePath) ?: productName  // 🔹 교정 실패 시 원래 OCR 명 사용

                Log.d("API 검색", "🛠 최종 검색 제품명 (교정 적용 후): $correctedProductName")

                val apiKey = "XgwptjbbJW9Kj0dDUwg4g47BpypKMzQrg%2ByaUu6Vs%2BI2nmZpO%2BMzm9zl%2FnJvp2%2BnElg4FgOKt8r1Na6kt4FKmQ%3D%3D"
                val encodedProductName = URLEncoder.encode(correctedProductName, "UTF-8")
                val apiUrl = "https://apis.data.go.kr/1471000/FoodNtrCpntDbInfo01/getFoodNtrCpntDbInq01?serviceKey=$apiKey&FOOD_NM_KR=$encodedProductName&pageNo=1&numOfRows=10&type=json"

                Log.d("API 검색", "🔎 검색할 제품명: $correctedProductName")
                Log.d("API 검색", "🔗 요청 URL: $apiUrl")

                val url = URL(apiUrl)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connect()

                val responseCode = connection.responseCode
                Log.d("API 검색", "📡 API 응답 코드: $responseCode")

                return@withContext if (responseCode == HttpURLConnection.HTTP_OK) {
                    val response = connection.inputStream.bufferedReader().use { it.readText() }

                    Log.d("API 검색", "📨 API 응답 본문 (일부): ${response.take(500)}") // 500자까지만 출력

                    if (response.trim().startsWith("<")) {
                        Log.d("API 검색", "📄 XML 응답 감지 → XML 파싱 실행")
                        parseXmlResponse(response)
                    } else {
                        Log.d("API 검색", "📜 JSON 응답 감지 → JSON 파싱 실행")
                        parseJsonResponse(response)
                    }
                } else {
                    Log.e("API 검색", "❌ API 요청 실패 (응답 코드: $responseCode)")
                    emptyList()
                }.also {
                    connection.disconnect()
                    Log.d("API 검색", "🔌 연결 해제됨")
                }
            } catch (e: Exception) {
                Log.e("API 검색", "🚨 API 검색 오류 발생", e)
                emptyList()
            }
        }
    }


    // 파일에서 후보 제품명으로 제품 찾고 교정하는 함수
    fun correctProductNameFromFile(context: Context, ocrProductName: String, filePath: String): String {
        val productList = loadProductNamesFromFile(context, filePath)

        // 🔍 1. 정확히 일치하는 경우 우선 반환
        if (productList.contains(ocrProductName)) {
            Log.d("OCR 교정", "✅ 정확히 일치하는 제품명 발견 → $ocrProductName")
            return ocrProductName
        }

        // 🔍 2. 포함 관계 체크 (예: "다이제스티브" in "맥비티 다이제스티브 비스킷")
        val partialMatch = productList.find {
            it.contains(ocrProductName) || ocrProductName.contains(it)
        }
        if (partialMatch != null) {
            Log.d("OCR 교정", "🔍 포함 관계로 매칭된 제품명 → $partialMatch")
            return partialMatch
        }

        // 🔍 3. Levenshtein 거리로 유사한 항목 선택
        var bestMatch = ocrProductName
        var minDistance = Int.MAX_VALUE

        for (product in productList) {
            val distance = levenshteinDistance(ocrProductName, product)
            if (distance < minDistance) {
                minDistance = distance
                bestMatch = product
            }
        }

        Log.d("OCR 교정", "🔄 OCR 결과: $ocrProductName → 최종 교정: $bestMatch")
        return bestMatch
    }


    // 파일에서 제품명으로 제품 찾는 함수
    fun loadProductNamesFromFile(context: Context, fileName: String): List<String> {
        return try {
            context.assets.open(fileName).bufferedReader().useLines { lines ->
                lines.mapNotNull { line ->
                    val parts = line.split("\t")
                    if (parts.size >= 2) parts[0] else null // 제품명만 추출
                }.toList()
            }
        } catch (e: Exception) {
            Log.e("파일 로드", "🚨 제품명 리스트 로드 실패: $e")
            emptyList()
        }
    }


    // 파일 안에 후보 제품명이 들어있는지 확인
    suspend fun getAllMatchingProductInfoFromAPI(context: Context, ocrProductName: String): List<Map<String, String>> {
        val filePath = "20250327_가공식품DB_147999건.txt"
        val allResults = mutableListOf<Map<String, String>>()

        // 1. OCR 전체 문자열이 텍스트 파일에 포함되어 있는지 우선 확인
        val exactMatchFound = findAllMatchingProductNames(context, ocrProductName, filePath)
            .filter { it == ocrProductName }

        if (exactMatchFound.isNotEmpty()) {
            Log.d("OCR 보정", "🎯 OCR 전체 이름으로 정확히 일치하는 제품명 발견 → ${exactMatchFound.first()}")
            val results = getProductInfoFromAPI(context, exactMatchFound.first())
            allResults.addAll(results)
            return allResults
        }

        // 2. 포함된 제품명 리스트 방식으로 fallback
        val fallbackMatches = findAllMatchingProductNames(context, ocrProductName, filePath)
        if (fallbackMatches.isNotEmpty()) {
            Log.d("OCR 보정", "🔁 포함된 제품명 리스트 방식으로 검색 진행")
            for (name in fallbackMatches) {
                val results = getProductInfoFromAPI(context, name)
                allResults.addAll(results)
            }
        }

        return allResults
    }


    // 파일에서 일치하는 제품명 찾는 함수를 호출하고 결과 반환하는 함수
    fun findAllMatchingProductNames(context: Context, ocrProductName: String, filePath: String): List<String> {
        val productList = loadProductNamesFromFile(context, filePath)
        return productList.filter {
            it.contains(ocrProductName) || ocrProductName.contains(it)
        }.also {
            Log.d("OCR 교정", "🔍 포함된 제품명 리스트: $it")
        }
    }


    // Levenshtein Distance 알고리즘
    fun levenshteinDistance(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }

        for (i in s1.indices) dp[i + 1][0] = i + 1
        for (j in s2.indices) dp[0][j + 1] = j + 1

        for (i in s1.indices) {
            for (j in s2.indices) {
                val cost = if (s1[i] == s2[j]) 0 else 1
                dp[i + 1][j + 1] = minOf(
                    dp[i][j + 1] + 1,  // 삽입
                    dp[i + 1][j] + 1,  // 삭제
                    dp[i][j] + cost   // 교체
                )
            }
        }
        return dp[s1.length][s2.length]
    }


    fun correctProductName(ocrProductName: String, productList: List<String>): String {
        var bestMatch = ocrProductName
        var minDistance = Int.MAX_VALUE

        for (product in productList) {
            val distance = levenshteinDistance(ocrProductName, product)
            if (distance < minDistance) {
                minDistance = distance
                bestMatch = product
            }
        }

        Log.d("OCR 교정", "🔄 OCR 결과: $ocrProductName → 교정된 제품명: $bestMatch")
        return bestMatch
    }



    private fun parseXmlResponse(xmlString: String): List<Map<String, String>> {
        val factory = DocumentBuilderFactory.newInstance()
        val builder = factory.newDocumentBuilder()
        val inputStream = InputSource(xmlString.byteInputStream())
        val document = builder.parse(inputStream)

        val items = document.getElementsByTagName("item")
        val resultList = mutableListOf<Map<String, String>>()

        for (i in 0 until items.length) {
            val item = items.item(i)
            val foodName = item.childNodes.item(1).textContent ?: "Unknown"
            val makerName = item.childNodes.item(3).textContent ?: "Unknown"
            val reportNo = item.childNodes.item(5).textContent ?: "Unknown"
            val updateDate = item.childNodes.item(7).textContent ?: "Unknown"

            resultList.add(
                mapOf(
                    "FOOD_NM_KR" to foodName,
                    "MAKER_NM" to makerName,
                    "ITEM_REPORT_NO" to reportNo,
                    "UPDATE_YMD" to updateDate
                )
            )
        }
        return resultList
    }


    private fun parseJsonResponse(jsonString: String): List<Map<String, String>> {
        val resultList = mutableListOf<Map<String, String>>()

        try {
            val data = JSONObject(jsonString)

            // API 응답 코드 확인
            val header = data.optJSONObject("header")
            if (header?.optString("resultCode") != "00") {
                Log.e("JSON 파싱", "❌ API 응답 실패: ${header?.optString("resultMsg")}")
                return emptyList()
            }

            // JSON 내부의 데이터 가져오기
            val body = data.optJSONObject("body")
            val items = body?.optJSONArray("items") ?: return emptyList()

            // 데이터 파싱
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                val foodData = mapOf(
                    "FOOD_NM_KR" to (item.optString("FOOD_NM_KR", "Unknown")), // 식품명
                    "FOOD_CAT3_NM" to (item.optString("FOOD_CAT3_NM", "Unknown")), // 식품소분류명
                    "AMT_NUM1" to (item.optString("AMT_NUM1", "Unknown")), // 에너지
                    "AMT_NUM6" to (item.optString("AMT_NUM6", "Unknown")), // 탄수화물
                    "AMT_NUM3" to (item.optString("AMT_NUM3", "Unknown")), // 단백질
                    "AMT_NUM4" to (item.optString("AMT_NUM4", "Unknown")), // 지방
                    "AMT_NUM7" to (item.optString("AMT_NUM7", "Unknown")), // 당류
                    "AMT_NUM13" to (item.optString("AMT_NUM13", "Unknown")), // 나트륨
                    "AMT_NUM23" to (item.optString("AMT_NUM23", "Unknown")), // 콜레스테롤
                    "NUTRI_AMOUNT_SERVING" to (item.optString("NUTRI_AMOUNT_SERVING", "Unknown")), // 1회 섭취참고량
                    "Z10500" to (item.optString("Z10500", "Unknown")), // 식품중량
                    "MAKER_NM" to (item.optString("MAKER_NM", "Unknown")), // 업체명
                    "ITEM_REPORT_NO" to (item.optString("ITEM_REPORT_NO", "Unknown")), // 품목제조보고번호
                    "UPDATE_YMD" to (item.optString("UPDATE_YMD", "Unknown")) // 데이터기준일자
                )
                resultList.add(foodData)
            }
        } catch (e: Exception) {
            Log.e("JSON 파싱", "🚨 JSON 파싱 중 오류 발생", e)
        }

        Log.d("JSON 파싱", "✅ 파싱된 제품 수: ${resultList.size}")
        for ((index, item) in resultList.withIndex()) {
            Log.d("JSON 파싱", "📦 [$index] 제품명: ${item["FOOD_NM_KR"]}, 제조사: ${item["MAKER_NM"]}")
        }

        return resultList
    }

}


class CameraActivity : AppCompatActivity() {
    private var currentPhotoPath: String = ""
    private var originBitmap: Bitmap? = null
//    lateinit var binding: ActivityMainBinding

    private val foodLensService by lazy {
        FoodLens.createFoodLensService(this)
    }

    private val loadingDialog by lazy {
        Dialog(this).apply {
            window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setContentView(ProgressBar(this@CameraActivity))
        }
    }

    fun increasePoiLimit() {
        IOUtils.setByteArrayMaxOverride(200_000_000) // 기본값 100,000,000 → 200,000,000으로 증가
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        increasePoiLimit() // POI 라이브러리의 제한 확장
//        setContentView(R.layout.activity_camera) /////////보라색 화면 근거

        if (OpenCVLoader.initDebug()) {
            Log.i("OpenCV", "OpenCV loaded successfully")
        } else {
            Log.e("OpenCV", "OpenCV initialization failed!")
            Toast.makeText(this, "OpenCV initialization failed!", Toast.LENGTH_LONG).show()
        }

        foodLensService.setLanguage(LanguageConfig.KO)

        val action = intent.getStringExtra("action")
        when (action) {
            "camera" -> openCamera()
            "gallery" -> openGallery()
        }
    }

    // 갤러리로 사진 선택했을 때 사용되는중
    private val mGalleryForResult: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                Log.d("mGalleryForResult", "mGalleryForResult() called")
                result.data?.data?.let { uri ->
                    try {
                        // 1. URI를 통해 InputStream 가져오기
                        val inputStream = contentResolver.openInputStream(uri)
                        val originalBitmap = BitmapFactory.decodeStream(inputStream)
                        inputStream?.close()

                        if (originalBitmap == null) {
                            Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show()
                            return@let
                        }

                        Log.d("mGalleryForResult", "mGalleryForResult() and Bitmap loaded successfully")

                        // 2. 수평 기울기 보정
                        val correctedBitmap = deskewBitmap(originalBitmap)
                        Log.d("mGalleryForResult", "mGalleryForResult() and deskewBitmap applied")

                        // 3. 선명도 향상
                        val enhancedBitmap = enhanceBitmap(correctedBitmap)
                        Log.d("mGalleryForResult", "mGalleryForResult() and enhanceBitmap applied")

                        // 4. 앱에 표시할 원본 저장
                        originBitmap = enhancedBitmap

                        // 5. Bitmap을 ByteArray로 변환
                        val byteArray = getByteArrayFromBitmap(enhancedBitmap)

                        // 6. OCR 처리 시작
                        processImage(byteArray)


//                        // URI를 통해 InputStream 가져오기
//                        val inputStream = contentResolver.openInputStream(uri)
//                        val bitmap = BitmapFactory.decodeStream(inputStream)
//                        inputStream?.close()
//
//                        // Bitmap을 ByteArray로 변환
//                        val byteArray = getByteArrayFromBitmap(bitmap)
//
//                        // ByteArray를 processImage 함수에 전달
//                        processImage(byteArray)
                    } catch (e: Exception) {
                        Toast.makeText(this, "이미지 처리 중 오류 발생: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                Toast.makeText(this, "No image selected!!", Toast.LENGTH_SHORT).show()
                finish()  // ✅ 선택하지 않았으면 Activity 종료
            }
        }

    // 카메라로 사진 찍었을 때 사용
    private val mCameraForResult: ActivityResultLauncher<Uri> =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) {
                Log.d("mCameraForResult", "mCameraForResult() called")
                processImageFromPath(currentPhotoPath)
            } else {
                Toast.makeText(this, "Failed to capture image", Toast.LENGTH_SHORT).show()
            }
        }

    private val selLaunuage = arrayOf("en", "ko")


    // 카메라로 사진 찍을 때 사용
    private fun openCamera() {
        val imageFile = createImageFile()
        val photoUri = FileProvider.getUriForFile(
            this,
            "${applicationContext.packageName}.fileprovider",
            imageFile
        )

        currentPhotoPath = imageFile.absolutePath
        mCameraForResult.launch(photoUri)
    }

    private fun openGallery() {
        Log.d("openGallery", "openGallery() called")
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        mGalleryForResult.launch(intent)
    }


    private fun createImageFile(): File {
        val imageFileName = "JPEG_Image"
        val storageDir: File? = getExternalFilesDir("images")
        return File.createTempFile(imageFileName, ".jpg", storageDir)
    }



    //카메라 사용한 이미지 탐색에만 쓰이는 중
    private fun processImageFromPath(imagePath: String) {
        try {
            if (imagePath.isEmpty()) {
                Toast.makeText(this, "Invalid image path", Toast.LENGTH_SHORT).show()
                return
            }

            val bitmap = getHighResolutionBitmap(imagePath)
            if (bitmap == null) {
                Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show()
                return
            }

            Log.d("processImageFromPath", "processImageFromPath() called")


            // 1. 수평 보정 (deskew 적용)
            val correctedBitmap = deskewBitmap(bitmap)

            // 2. 선명도 개선
            val enhancedBitmap = enhanceBitmap(correctedBitmap)

            originBitmap = enhancedBitmap

            // 3. 바이트 배열 변환
            val byteData = getByteArrayFromBitmap(enhancedBitmap)

            // 4. OCR 처리 시작
            processImage(byteData)

        } catch (e: Exception) {
            Toast.makeText(this, "Error processing image: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // 아예 안쓰이는중
    private fun processImageFromUri(uri: Uri) {
        try {
            val inputStream = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (bitmap == null) {
                Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show()
                return
            }

            Log.d("processImageFromUri", "processImageFromUri() called")

            // 1. 수평 보정 (deskew 적용)
            val correctedBitmap = deskewBitmap(bitmap)

            // 2. 선명도 개선
            val enhancedBitmap = enhanceBitmap(correctedBitmap)

            originBitmap = enhancedBitmap

            // 3. 바이트 배열 변환
            val byteData = getByteArrayFromBitmap(enhancedBitmap)

            processImage(byteData)

        } catch (e: Exception) {
            Toast.makeText(this, "Error processing image: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }


    // OCR 호출, 두잉랩 호출 함수
    private fun processImage(byteData: ByteArray) {
        Log.d("processImage", "processImage() called")

        loadingDialog.show()

        // OCR API 호출
        performOcrRequest(byteData) { hasText, ocrResults ->
            // 1. OCR 결과
            val ocrResultText = StringBuilder()
            ocrResults?.forEach { (key, value) ->
                val (text, confidence) = value
                ocrResultText.append("$key: $text (신뢰도: ${"%.2f".format(confidence * 100)}%)\n")
            }

            // 2. 두잉랩 API 호출
            foodLensService.predict(byteData, object : RecognitionResultHandler {
                override fun onSuccess(result: RecognitionResult?) {
                    loadingDialog.dismiss()

                    val foodList = result?.foodInfoList?.map { food ->
                        Log.d("FoodLens 원본", "⚠️ ${food.name} | energy=${food.energy} | carb=${food.carbohydrate} | protein=${food.protein}")
                        mapOf(
                            "name" to (food.name ?: ""),
                            "gram" to (food.gram ?: 0.0),
                            "energy" to (food.energy ?: -1.0),
                            "carbohydrate" to (food.carbohydrate ?: -1.0),
                            "protein" to (food.protein ?: -1.0),
                            "fat" to (food.fat ?: -1.0),
                            "totalSugars" to (food.totalSugars ?: -1.0),
                            "sodium" to (food.sodium ?: -1.0),
                            "cholesterol" to (food.cholesterol ?: -1.0)
                        )
                    } ?: emptyList()

                    val gson = Gson()
                    val foodListJson = gson.toJson(foodList)  // JSON 문자열로 직렬화

                    val intent = Intent().apply {
                        putExtra("ocrResults", ocrResultText.toString())
                        putExtra("recognitionResults", foodListJson.toString())  // ✅ JSON으로 전달
                    }

                    Log.d("NativeResult", "OCR 결과 전달: $ocrResultText")
                    Log.d("NativeResult", "두잉랩 JSON 전달: $foodListJson")
                    setResult(Activity.RESULT_OK, intent)
                    finish()
                }

                override fun onError(errorReason: BaseError?) {
                    loadingDialog.dismiss()
                    Toast.makeText(
                        this@CameraActivity,
                        "두잉랩 오류: ${errorReason?.getMessage()}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (loadingDialog.isShowing) {
            loadingDialog.dismiss() // Dialog가 열려 있다면 닫기
        }
    }


    // OCR 호출 및 요청 함수
    private fun performOcrRequest(byteData: ByteArray, onResult: (Boolean, Map<String, Pair<String, Double>>?) -> Unit) {
        val apiUrl = "https://aoupqi3geb.apigw.ntruss.com/custom/v1/37569/c532822ab12c693842a87ba41b73e34705cdaf6b7d869b7419da1c8cc36227a6/general"
        val secretKey = "d2lUR1BQSUV0Z3FWVm1SUkJ3dktYVmVaRExFS3VyZko="

        Log.d("performOcrRequest", "performOcrRequest() called")

        // Base64로 이미지 데이터 인코딩
        val encodedImage = Base64.getEncoder().encodeToString(byteData)

        // JSON 요청 본문 생성
        val jsonBody = JSONObject().apply {
            put("images", JSONArray().apply {
                put(JSONObject().apply {
                    put("format", "jpg")
                    put("name", "medium")
                    put("data", encodedImage)
                })
            })
            put("lang", "ko") // 언어 설정
            put("requestId", UUID.randomUUID().toString()) // 고유한 requestId 생성
            put("resultType", "general") // 결과 타입 설정
            put("timestamp", System.currentTimeMillis()) // 타임스탬프 설정
            put("version", "V2") // API 버전
        }.toString()

        // OkHttp 요청 생성
        val mediaType = "application/json".toMediaTypeOrNull()
        val requestBody = RequestBody.create(mediaType, jsonBody)
        val request = Request.Builder()
            .url(apiUrl)
            .post(requestBody)
            .addHeader("X-OCR-SECRET", secretKey)
            .addHeader("Content-Type", "application/json")
            .build()

        // OkHttp 클라이언트로 요청 전송
        OkHttpClient().newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@CameraActivity, "OCR 요청 실패: ${e.message}", Toast.LENGTH_SHORT).show()
                    onResult(false, null)
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseBody = response.body?.string()
                Log.d("OCR API", "응답 코드: ${response.code}, 응답 메시지: ${response.message}, 본문: $responseBody")

                if (response.isSuccessful && responseBody != null) {
                    val texts = ParseUtils.parseOcrResponse(responseBody)
                    runOnUiThread {
                        onResult(texts.isNotEmpty(), texts.mapValues { Pair(it.value, 1.0) })
                    }
                } else {
                    runOnUiThread {
                        Toast.makeText(
                            this@CameraActivity,
                            "OCR 응답 오류: 코드 ${response.code}, 메시지: ${response.message}",
                            Toast.LENGTH_LONG
                        ).show()
                        onResult(false, null)
                    }
                }
            }
        })
    }


    private fun findAllMatchingProductsFromFile(context: Context, keyword: String, fileName: String): List<String> {
        return try {
            val inputStream = File(context.cacheDir, fileName).inputStream()
            inputStream.bufferedReader().useLines { lines ->
                lines.mapNotNull { line ->
                    val parts = line.split("\t")
                    if (parts.size >= 2) {
                        val productName = parts[0]
                        if (productName.contains(keyword) || keyword.contains(productName)) productName else null
                    } else null
                }.toList()
            }
        } catch (e: Exception) {
            Log.e("제품명 검색", "🚨 파일 읽기 오류: $e")
            emptyList()
        }
    }



    // OCR 결과를 다이얼로그로 표시하는 함수
    private fun displayOcrResults(results: Map<String, Pair<String, Double>>) {
        if (!isFinishing && !isDestroyed) {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("OCR 결과")

            val message = StringBuilder().apply {
                results.forEach { (key, value) ->
                    val (text, confidence) = value
                    append("$key: $text (신뢰도: ${"%.2f".format(confidence * 100)}%)\n")
                }
            }.toString()

            builder.setMessage(message)
            builder.setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            builder.show()
        }
    }


    private fun checkAndRequestPermissions() {
        val permissions = arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
        val deniedPermissions = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (deniedPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, deniedPermissions.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }

    private fun getHighResolutionBitmap(filePath: String): Bitmap? {
        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888 // 고해상도 설정
            inJustDecodeBounds = false // 이미지 전체 로드
        }
        return BitmapFactory.decodeFile(filePath, options)
    }

    private fun getByteArrayFromBitmap(bitmap: Bitmap): ByteArray {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream) // PNG는 무손실 압축
        return outputStream.toByteArray()
    }

    private fun enhanceBitmap(bitmap: Bitmap): Bitmap {
        val contrast = 1.5f // 대비 증가 값
        val brightness = 10f // 밝기 증가 값 (float 타입으로 변경)

        // ColorMatrix 생성 및 설정
        val colorMatrix = ColorMatrix().apply {
            set(floatArrayOf(
                contrast, 0f, 0f, 0f, brightness,
                0f, contrast, 0f, 0f, brightness,
                0f, 0f, contrast, 0f, brightness,
                0f, 0f, 0f, 1f, 0f
            ))
        }

        // Paint에 ColorFilter 적용
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(colorMatrix)
            isAntiAlias = true // 이미지 품질 개선
        }

        // 결과 비트맵 생성
        val resultBitmap = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config)
        val canvas = Canvas(resultBitmap)
        canvas.drawBitmap(bitmap, 0f, 0f, paint)

        return resultBitmap
    }

    companion object {
        private const val REQ_GALLERY_PICTURE = 0x02
        private const val REQ_CAMERA_PICTURE = 0x03
        private const val PERMISSION_REQUEST_CODE = 1001
    }

}


fun deskewBitmap(bitmap: Bitmap): Bitmap {
    Log.d("deskew", "deskewBitmap() called")

    val src = Mat()
    Utils.bitmapToMat(bitmap, src)

    val gray = Mat()
    Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY)

    val binary = Mat()
    Imgproc.adaptiveThreshold(
        gray, binary, 255.0,
        Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C,
        Imgproc.THRESH_BINARY_INV, 15, 10.0
    )

    val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0))
    Imgproc.morphologyEx(binary, binary, Imgproc.MORPH_CLOSE, kernel)

    val moments = Imgproc.moments(binary)
    Log.d("deskew", "mu02=${moments.mu02}, mu11=${moments.mu11}")

    if (Math.abs(moments.mu02) < 1e-2) {
        Log.d("deskew", "No deskew needed (mu02 too small)")
        return bitmap
    }

    val skew = moments.mu11 / moments.mu02
    val angle = Math.atan(skew) * (180 / Math.PI)
    Log.d("deskew", "Detected skew angle=$angle")

    val center = Point(src.width() / 2.0, src.height() / 2.0)
    val rotationMatrix = Imgproc.getRotationMatrix2D(center, angle, 1.0)

    val rotated = Mat()
    Imgproc.warpAffine(
        src, rotated, rotationMatrix,
        Size(src.width().toDouble(), src.height().toDouble()),
        Imgproc.INTER_LINEAR,
        Core.BORDER_CONSTANT,
        Scalar(255.0, 255.0, 255.0)
    )

    val resultBitmap = Bitmap.createBitmap(rotated.cols(), rotated.rows(), Bitmap.Config.ARGB_8888)
    Utils.matToBitmap(rotated, resultBitmap)

    Log.d("deskew", "deskewBitmap() finished")

    return resultBitmap
}




/*

flutter clean
flutter pub get
flutter run




flutter clean
flutter pub get
cd android
./gradlew clean
./gradlew build


 */

