package com.doinglab.foodlens2.example

import android.util.Log
import org.json.JSONObject
import java.io.File


object ParseUtils {

    fun parseJsonResponse(jsonString: String): List<Map<String, String>> {
        val resultList = mutableListOf<Map<String, String>>()
        try {
            val data = JSONObject(jsonString)
            val header = data.optJSONObject("header")
            if (header?.optString("resultCode") != "00") {
                Log.e("JSON 파싱", "❌ API 응답 실패: ${header?.optString("resultMsg")}")
                return emptyList()
            }

            val body = data.optJSONObject("body")
            val items = body?.optJSONArray("items") ?: return emptyList()

            Log.d("JSON 파싱", "✅ 파싱된 제품 수: ${items.length()}")

            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                Log.d("JSON 파싱", "📦 [$i] 제품명: ${item.optString("FOOD_NM_KR")}, 제조사: ${item.optString("MAKER_NM")}")

                val foodData = mapOf(
                    "FOOD_NM_KR" to item.optString("FOOD_NM_KR", "Unknown"),
                    "FOOD_CAT3_NM" to item.optString("FOOD_CAT3_NM", "Unknown"),
                    "AMT_NUM1" to item.optString("AMT_NUM1", "Unknown"),
                    "AMT_NUM7" to item.optString("AMT_NUM7", "Unknown"),
                    "AMT_NUM3" to item.optString("AMT_NUM3", "Unknown"),
                    "AMT_NUM4" to item.optString("AMT_NUM4", "Unknown"),
                    "AMT_NUM13" to item.optString("AMT_NUM13", "Unknown"),
                    "AMT_NUM23" to item.optString("AMT_NUM23", "Unknown"),
                    "NUTRI_AMOUNT_SERVING" to item.optString("NUTRI_AMOUNT_SERVING", "Unknown"),
                    "Z10500" to item.optString("Z10500", "Unknown"),
                    "MAKER_NM" to item.optString("MAKER_NM", "Unknown"),
                    "ITEM_REPORT_NO" to item.optString("ITEM_REPORT_NO", "Unknown"),
                    "UPDATE_YMD" to item.optString("UPDATE_YMD", "Unknown")
                )
                resultList.add(foodData)
                Log.d("API 검색", "🔍 최종 반환 리스트 크기: ${resultList.size}")
            }
        } catch (e: Exception) {
            Log.e("JSON 파싱", "🚨 JSON 파싱 중 오류 발생", e)
        }
        Log.d("API 검색", "🔍 최종 반환 리스트 크기: ${resultList.size}")
        return resultList
    }



    fun parseOcrResponse(response: String): Map<String, String> {
        Log.d("parseOcrResponse", "parseOcrResponse() called")
        try {
            val trimmed = response.trim()
            if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
                val jsonResponse = JSONObject(trimmed)
                val images = jsonResponse.optJSONArray("images") ?: return emptyMap()
                if (images.length() == 0) return emptyMap()

                val firstImage = images.getJSONObject(0)
                val fields = firstImage.optJSONArray("fields") ?: return emptyMap()
                if (fields.length() == 0) return emptyMap()

                val resultMap = mutableMapOf<String, String>()
                val serialNumberCandidates = mutableListOf<String>()

                val productNameKeywords = listOf("제품명", "품명")
                val stopKeywords = listOf("식재료", "원재료", "중량", "유통기한", "제조사", "보관방법")

                var captureProductName = false
                val productNameBuilder = StringBuilder()
                var baseX = -1.0
                var baseY = -1.0
                var previousX = -1.0
                var previousY = -1.0
                var previousXGap = -1.0
                var previousYGap = -1.0
                val maxGapRatio = 2.5

                for (i in 0 until fields.length()) {
                    val field = fields.getJSONObject(i)
                    val inferText = field.optString("inferText", "").trim()
                    val confidence = field.optDouble("inferConfidence", 0.0)
                    if (confidence < 0.9 || inferText.isEmpty()) continue

                    if (inferText.contains("품목보고번호")) continue
                    val serialMatches = Regex("\\d{10,}-?\\d*").findAll(inferText).map { it.value }.toList()
                    serialNumberCandidates.addAll(serialMatches)

                    val similarity = productNameKeywords.maxOf { calculateJaroWinklerSimilarity(it, inferText) }
                    if (!captureProductName && similarity > 0.85) {
                        captureProductName = true
                        baseX = getMinX(field)
                        baseY = getMinY(field)

                        // "제품명:맥비티"처럼 붙은 경우 분리 추출
                        val suffix = inferText.replace(Regex(".*[:：]"), "").trim()
                        if (suffix.isNotEmpty() && !productNameKeywords.any { suffix.contains(it) }) {
                            productNameBuilder.append(suffix).append(" ")
                            Log.d("제품명 추출", "📎 키워드 포함 단어에서 바로 추출된 제품명: '$suffix'")
                        }

                        continue
                    }

                    if (captureProductName) {
                        if (stopKeywords.any { inferText.contains(it) }) {
                            Log.d("제품명 추출", "⛔ 중단 키워드 감지: '$inferText'")
                            captureProductName = false
                            continue
                        }

                        val currentX = getMinX(field)
                        val currentY = getMinY(field)
                        val xGap = currentX - previousX
                        val yGap = Math.abs(currentY - previousY)

                        if (xGap < 0) continue

                        if (previousXGap > 0 || previousYGap > 0) {
                            val safePrevXGap = if (previousXGap != 0.0) previousXGap else 1.0
                            val safePrevYGap = if (previousYGap != 0.0) previousYGap else 1.0
                            val xRatio = xGap / safePrevXGap
                            val yRatio = yGap / safePrevYGap
                            Log.d("제품명 추출", "👉 '$inferText' - xGap=$xGap (ratio=$xRatio), yGap=$yGap (ratio=$yRatio)")
                            if (xRatio > maxGapRatio || yRatio > maxGapRatio) {
                                Log.d("제품명 추출", "❌ 간격 초과로 중단: '$inferText'")
                                break
                            }
                        } else {
                            Log.d("제품명 추출", "👉 첫 단어: '$inferText' - currentX=$currentX, currentY=$currentY")
                        }

                        productNameBuilder.append(inferText).append(" ")
                        previousXGap = xGap
                        previousYGap = yGap
                        previousX = currentX
                        previousY = currentY
                    }
                }

                val finalProductName = productNameBuilder.toString().trim()
                if (finalProductName.isNotEmpty()) {
                    resultMap["제품명"] = finalProductName
                    Log.d("제품명 추출", "✅ 최종 제품명: $finalProductName")
                }
                if (serialNumberCandidates.isNotEmpty()) {
                    val bestSerialNumber = serialNumberCandidates.maxByOrNull { it.length }
                        ?.replace(Regex("[^0-9-]"), "")
                    if (!bestSerialNumber.isNullOrEmpty()) {
                        resultMap["품목보고번호"] = bestSerialNumber
                    }
                }

                return resultMap
            } else {
                val resultMap = mutableMapOf<String, String>()
                val productNameRegex = Regex("제품명:\\s*([^\\n]+)")
                val serialNumberRegex = Regex("품목보고번호:\\s*([^\\n]+)")

                val productMatch = productNameRegex.find(response)
                val serialMatch = serialNumberRegex.find(response)

                if (productMatch != null) {
                    resultMap["제품명"] = productMatch.groupValues[1].split("(")[0].trim()
                }
                if (serialMatch != null) {
                    val serial = serialMatch.groupValues[1].split("(")[0].trim()
                    resultMap["품목보고번호"] = serial.replace(Regex("[^0-9-]"), "")
                }
                return resultMap
            }
        } catch (e: Exception) {
            Log.e("parseOcrResponse", "JSON Parsing Error: ${e.message}", e)
            return emptyMap()
        }
    }



    fun getMinX(field: JSONObject): Double {
        val vertices = field.getJSONObject("boundingPoly").getJSONArray("vertices")
        return vertices.getJSONObject(0).optDouble("x", 0.0)
    }

    fun getMinY(field: JSONObject): Double {
        val vertices = field.getJSONObject("boundingPoly").getJSONArray("vertices")
        return vertices.getJSONObject(0).optDouble("y", 0.0)
    }

    fun getMatchingProductListByOcrName(ocrProductName: String, filePath: String): List<String> {
        val result = mutableListOf<String>()
        try {
            val file = File(filePath)
            if (!file.exists()) return result

            val normalizedOcrName = ocrProductName.replace("\\s".toRegex(), "") // 공백 제거

            file.forEachLine { line ->
                val productName = line.split("\t").getOrNull(0)?.trim() ?: return@forEachLine
                val normalizedProductName = productName.replace("\\s".toRegex(), "") // 공백 제거

                Log.d("제품명 비교", "📄 파일 내 제품명 원본: '$productName'")

                if (normalizedProductName.contains(normalizedOcrName)) {
                    result.add(productName) // ✅ 원래 제품명 형태로 결과에 추가
                }
            }
        } catch (e: Exception) {
            Log.e("제품명 보정", "❌ 텍스트 파일 처리 오류: ${e.message}")
        }
        return result
    }



    // Jaro-Winkler 유사도 계산 함수
    fun calculateJaroWinklerSimilarity(s1: String, s2: String): Double {
        val mtp = matches(s1, s2)
        val m = mtp[0].toDouble()
        if (m == 0.0) return 0.0
        val j = ((m / s1.length) + (m / s2.length) + ((m - mtp[1]) / m)) / 3.0
        val jw = if (j < 0.7) j else j + (minOf(0.1, 1.0 / mtp[3]) * mtp[2] * (1 - j))
        return jw
    }


    fun matches(s1: String, s2: String): IntArray {
        val max = if (s1.length > s2.length) s1 else s2
        val min = if (s1.length > s2.length) s2 else s1
        val range = maxOf(max.length / 2 - 1, 0)
        val matchIndexes = IntArray(min.length) { -1 }
        val matchFlags = BooleanArray(max.length)
        var matches = 0
        for (mi in min.indices) {
            val c1 = min[mi]
            for (xi in maxOf(mi - range, 0)..minOf(mi + range + 1, max.length - 1)) {
                if (!matchFlags[xi] && c1 == max[xi]) {
                    matchIndexes[mi] = xi
                    matchFlags[xi] = true
                    matches++
                    break
                }
            }
        }
        val ms1 = CharArray(matches)
        val ms2 = CharArray(matches)
        var si = 0
        for (i in min.indices) {
            if (matchIndexes[i] != -1) {
                ms1[si] = min[i]
                si++
            }
        }
        si = 0
        for (i in max.indices) {
            if (matchFlags[i]) {
                ms2[si] = max[i]
                si++
            }
        }
        var transpositions = 0
        for (mi in ms1.indices) {
            if (ms1[mi] != ms2[mi]) transpositions++
        }

        // 배열 길이 검사 후 prefix 길이 결정
        val prefixLength = minOf(4, ms1.size)
        return intArrayOf(matches, transpositions / 2, prefixLength, max.length)
    }


}





/*

flutter clean
flutter pub get
flutter run

 */



//썬칩 경우 생각해주기 (글씨가 대각선)
// 단종된 제품, 예전 사진이라 품목보고번호가 2개인데 그 중 뒷번호만 유효한 경우
//음식인지 가공식품인지 체크하는 라디오 박스
