import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

Future<void> saveFoodRecord({
  required String foodName,
  required double totalConsumed,
  required double calories,
  required double carbohydrates,
  required double protein,
  required double fat,
  required double sugars,
  required double sodium,
}) async {
  final user = FirebaseAuth.instance.currentUser;

  if (user == null) {
    throw Exception("로그인된 사용자가 없습니다.");
  }

  final email = user.email;
  final today = DateTime.now().toIso8601String().split('T')[0]; // 날짜 (YYYY-MM-DD)
  final firestore = FirebaseFirestore.instance;

  // Firestore에 데이터 저장
  await firestore
      .collection('sjsk_users')
      .doc(email)
      .collection(today)
      .add({
    'foodName': foodName,
    'totalConsumed': totalConsumed,
    'calories': calories, // 칼로리 추가
    'carbohydrates': carbohydrates, // 탄수화물 추가
    'protein': protein, // 단백질 추가
    'fat': fat, // 지방 추가
    'sugars': sugars, // 당류 추가
    'sodium': sodium, // 나트륨 추가
    'timestamp': Timestamp.now(), // 저장 시간
  });
}



Future<List<Map<String, dynamic>>> fetchFoodRecords(String date) async {
  final user = FirebaseAuth.instance.currentUser;

  if (user == null) {
    throw Exception("로그인된 사용자가 없습니다.");
  }

  final email = user.email;

  final firestore = FirebaseFirestore.instance;

  // Firestore에서 데이터 읽기
  final snapshot = await firestore
      .collection('sjsk_users')
      .doc(email)
      .collection(date)
      .get();

  return snapshot.docs.map((doc) => doc.data() as Map<String, dynamic>).toList();
}

Future<void> deleteFoodRecord(String date, String docId) async {
  final user = FirebaseAuth.instance.currentUser;

  if (user == null) {
    throw Exception("로그인된 사용자가 없습니다.");
  }

  final email = user.email;

  final firestore = FirebaseFirestore.instance;

  // Firestore에서 데이터 삭제
  await firestore
      .collection('sjsk_users')
      .doc(email)
      .collection(date)
      .doc(docId)
      .delete();
}

Future<void> updateFoodRecord({
  required String date,
  required String docId,
  required String foodName,
  required double amount,
  required Map<String, dynamic> nutritionDetails,
}) async {
  final user = FirebaseAuth.instance.currentUser;

  if (user == null) {
    throw Exception("로그인된 사용자가 없습니다.");
  }

  final email = user.email;
  final timestamp = Timestamp.now();

  final firestore = FirebaseFirestore.instance;

  // Firestore에서 데이터 업데이트
  await firestore
      .collection('sjsk_users')
      .doc(email)
      .collection(date)
      .doc(docId)
      .update({
    'foodName': foodName,
    'amount': amount,
    'nutritionDetails': nutritionDetails,
    'timestamp': timestamp,
  });
}

Future<void> deleteAllFoodRecords(String date) async {
  final user = FirebaseAuth.instance.currentUser;

  if (user == null) {
    throw Exception("로그인된 사용자가 없습니다.");
  }

  final email = user.email;

  final firestore = FirebaseFirestore.instance;

  // Firestore에서 모든 데이터 삭제
  final snapshot = await firestore
      .collection('sjsk_users')
      .doc(email)
      .collection(date)
      .get();

  for (final doc in snapshot.docs) {
    await doc.reference.delete();
  }
}

// Future<void> deleteAllFoodRecordsForUser() async {
//   final user = FirebaseAuth.instance.currentUser;
//
//   if (user == null) {
//     throw Exception("로그인된 사용자가 없습니다.");
//   }
//
//   final email = user.email;
//
//   final firestore = FirebaseFirestore.instance;
//
//   // Firestore에서 모든 데이터 삭제
//   final snapshot = await firestore.collection('sjsk_users').doc(email).get();
//
//   if (snapshot.exists) {
//     final dateCollection = snapshot.reference.collectionGroup();
//     final dateSnapshot = await dateCollection.get();
//
//     for (final doc in dateSnapshot.docs) {
//       await doc.reference.delete();
//     }
//   }
// }

Future<void> deleteAllFoodRecordsForUserAndDate(String date) async {
  final user = FirebaseAuth.instance.currentUser;

  if (user == null) {
    throw Exception("로그인된 사용자가 없습니다.");
  }

  final email = user.email;

  final firestore = FirebaseFirestore.instance;

  // Firestore에서 모든 데이터 삭제
  final snapshot = await firestore
      .collection('sjsk_users')
      .doc(email)
      .collection(date)
      .get();

  for (final doc in snapshot.docs) {
    await doc.reference.delete();
  }
}

