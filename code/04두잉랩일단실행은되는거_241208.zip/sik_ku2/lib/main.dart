import 'package:coniv_3_dream/auth/login_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_options.dart';
import 'food_lens_example.dart';
import 'foodlens_screen.dart';
import 'logout_screen.dart';
import 'textSearch.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    print('Firebase 초기화 오류: $e');
    // 이미 초기화된 경우 무시하고 계속 진행
  }
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Sik_ku',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AuthWrapper(),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.active) {
          User? user = snapshot.data;
          if (user == null) {
            return LoginScreen();
          }
          return TabView();
        }
        return Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        );
      },
    );
  }
}

class TabView extends StatefulWidget {
  const TabView({super.key});

  @override
  State<TabView> createState() => _TabViewState();
}

class _TabViewState extends State<TabView> with TickerProviderStateMixin {
  late TabController _tabController;
  int _index = 0;

  @override
  void initState() {
    super.initState();

    _tabController = TabController(length: _navItems.length, vsync: this);
    _tabController.addListener(tabListener);
  }

  @override
  void dispose() {
    _tabController.removeListener(tabListener);
    super.dispose();
  }

  void tabListener() {
    setState(() {
      _index = _tabController.index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(60.0),
          child: AppBar(
            backgroundColor: Color(0xFF54D42A),
            foregroundColor: Colors.white,
            elevation: 0,
            title: Text(
              '식전식KU',
              style: TextStyle(fontSize: 40, color: Colors.red),
            ),
          ),
        ),
        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Colors.white,
          selectedItemColor: Colors.black,
          unselectedItemColor: Colors.grey,
          selectedLabelStyle: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 10,
          ),
          unselectedLabelStyle: const TextStyle(
            fontSize: 10,
          ),
          type: BottomNavigationBarType.fixed,
          onTap: (int index) {
            _tabController.animateTo(index);
          },
          currentIndex: _index,
          items: _navItems.map((item) {
            return BottomNavigationBarItem(
              icon: Icon(
                _index == item.index ? item.activeIcon : item.inactiveIcon,
              ),
              label: item.label,
            );
          }).toList(),
        ),
        body: TabBarView(
          physics: const NeverScrollableScrollPhysics(),
          controller: _tabController,
          children: [
            const FirstScreen(),
            SecondScreen(),
            const LogoutScreen()
          ],
        ),
      ),
    );
  }
}

class NavItem {
  final int index;
  final IconData activeIcon;
  final IconData inactiveIcon;
  final String label;

  const NavItem({
    required this.index,
    required this.activeIcon,
    required this.inactiveIcon,
    required this.label,
  });
}

const _navItems = [
  NavItem(
    index: 0,
    activeIcon: Icons.home,
    inactiveIcon: Icons.home_outlined,
    label: '텍스트 검색',
  ),
  NavItem(
    index: 1,
    activeIcon: Icons.mode_comment_rounded,
    inactiveIcon: Icons.mode_comment_outlined,
    label: '이미지 검색',
  ),
  NavItem(
    index: 2,
    activeIcon: Icons.more_horiz,
    inactiveIcon: Icons.more_horiz_outlined,
    label: '로그아웃',
  ),
];

class FirstScreen extends StatefulWidget {
  const FirstScreen({super.key});

  @override
  State<FirstScreen> createState() => Screen2State();

  // @override
  // Widget build(BuildContext context) {
  //   return Center(
  //     child: Text('텍스트 검색'),
  //   );
  // }
}

class SecondScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('이미지 검색'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => FoodLensScreen()),
            );
          },
          child: Text('Start FoodLens'),
        ),
      ),
    );
  }
}

class FoodLensScreen extends StatefulWidget {
  @override
  _FoodLensScreenState createState() => _FoodLensScreenState();
}

class _FoodLensScreenState extends State<FoodLensScreen> {

  static const platform = MethodChannel('com.doinglab.foodlens2.example');

  Future<void> _startFoodLens() async {
    try {
      final result = await platform.invokeMethod('startFoodLens');
      print('FoodLens Result: $result');
    } on PlatformException catch (e) {
      print('Error: ${e.message}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('FoodLens Example'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: _startFoodLens,
          child: Text('Start FoodLens'),
        ),
      ),
    );
  }
}







//로그인+텍스트검색 합본_241202