import 'dart:typed_data';
import 'package:flutter/services.dart';

class FoodLensService {
  static const _channel = MethodChannel('foodlens_sdk'); // Android 채널 이름과 동일

  /// FoodLens predict 호출
  static Future<List<String>> predictFood(Uint8List imageData) async {
    try {
      final List<dynamic> result = await _channel.invokeMethod(
        'predictFood',
        {'imageData': imageData},
      );
      return result.cast<String>(); // 결과를 List<String>으로 반환
    } catch (e) {
      print('FoodLens Predict Error: $e');
      return [];
    }
  }
}
