
import 'main.dart';
import 'dart:convert'; // JSON 파싱용
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:xml/xml.dart';

class Screen2State extends State<FirstScreen> {
  final TextEditingController _controller = TextEditingController();
  List<Map<String, dynamic>> _searchResults = []; // 검색 결과 리스트 저장
  bool _isLoading = false; // 로딩 상태 관리
  int _currentPage = 1; // 현재 페이지 번호, 1부터 시작
  int _totalPages = 0; // 전체 페이지 수
  static const int _itemsPerPage = 10; // 페이지당 항목 수
  String _currentQuery = ''; // 현재 검색어

  // API 호출 함수
  Future<void> _performSearch(String query, {int pageNo = 1}) async {
    setState(() {
      _isLoading = true;
      _searchResults = []; // 이전 결과 초기화
      if (query != _currentQuery) {
        _currentPage = 1; // 새로운 검색어일 경우 페이지 초기화
      }
      _currentQuery = query;
    });

    final String apiUrl =
        'https://apis.data.go.kr/1471000/FoodNtrCpntDbInfo01/getFoodNtrCpntDbInq01';
    final String serviceKey =
        'XgwptjbbJW9Kj0dDUwg4g47BpypKMzQrg%2ByaUu6Vs%2BI2nmZpO%2BMzm9zl%2FnJvp2%2BnElg4FgOKt8r1Na6kt4FKmQ%3D%3D';

    // 페이지 번호 추가
    final Uri uri = Uri.parse(
        '$apiUrl?serviceKey=$serviceKey&FOOD_NM_KR=${Uri.encodeComponent(query)}&pageNo=$pageNo&numOfRows=$_itemsPerPage&type=json');

    try {
      final response = await http.get(uri);

      if (response.statusCode == 200) {
        // 응답 본문 출력 (디버깅용)
        print('응답 본문: ${response.body}');

        if (_isXmlResponse(response.body)) {
          // XML 파싱
          try {
            final document = XmlDocument.parse(response.body);
            final items = document.findAllElements('item');
            setState(() {
              _searchResults = items
                  .map((item) => {
                'FOOD_NM_KR': item.findElements('FOOD_NM_KR').first.text,
                'FOOD_REF_NM': item.findElements('FOOD_REF_NM').first.text,
                'FOOD_CAT3_NM': item.findElements('FOOD_CAT3_NM').first.text,
                'AMT_NUM1': item.findElements('AMT_NUM1').first.text,
                'AMT_NUM7': item.findElements('AMT_NUM7').first.text,
                'AMT_NUM3': item.findElements('AMT_NUM3').first.text,
                'AMT_NUM4': item.findElements('AMT_NUM4').first.text,
                'AMT_NUM8': item.findElements('AMT_NUM8').first.text,
                'AMT_NUM14': item.findElements('AMT_NUM14').first.text,
                'NUTRI_AMOUNT_SERVING': item.findElements('NUTRI_AMOUNT_SERVING').first.text,
                'Z10500': item.findElements('Z10500').first.text,
                'MAKER_NM': item.findElements('MAKER_NM').first.text,
                'UPDATE_YMD': item.findElements('UPDATE_YMD').first.text,
              })
                  .toList();
              _totalPages = (_searchResults.length / _itemsPerPage).ceil();
            });
          } catch (e) {
            setState(() {
              _searchResults = [
                {'FOOD_NM_KR': 'XML 파싱 중 오류 발생: $e'}
              ];
            });
          }
        } else {
          // JSON 파싱
          try {
            final data = json.decode(response.body);
            if (data['header']['resultCode'] == '00') {
              final totalCount =
                  int.tryParse(data['body']['totalCount']?.toString() ?? '0') ??
                      0;
              _totalPages = (totalCount / _itemsPerPage).ceil();

              final items = data['body']['items'];
              if (items != null) {
                List<dynamic> itemList;

                if (items is List) {
                  // items가 리스트인 경우 여러 개의 아이템 처리
                  itemList = items;
                } else if (items is Map && items['item'] is List) {
                  // items 안의 item이 리스트인 경우
                  itemList = items['item'];
                } else if (items is Map && items['item'] is Map) {
                  // items 안의 item이 단일 객체인 경우
                  itemList = [items['item']];
                } else {
                  itemList = [];
                }

                setState(() {
                  _searchResults = itemList
                      .map((item) => {
                    'FOOD_NM_KR': item['FOOD_NM_KR'] as String,
                    'FOOD_REF_NM': item['FOOD_REF_NM'],
                    'FOOD_CAT3_NM': item['FOOD_CAT3_NM'],
                    'AMT_NUM1': item['AMT_NUM1'],
                    'AMT_NUM7': item['AMT_NUM7'],
                    'AMT_NUM3': item['AMT_NUM3'],
                    'AMT_NUM4': item['AMT_NUM4'],
                    'AMT_NUM8': item['AMT_NUM8'],
                    'AMT_NUM14': item['AMT_NUM14'],
                    'NUTRI_AMOUNT_SERVING': item['NUTRI_AMOUNT_SERVING'],
                    'Z10500': item['Z10500'],
                    'MAKER_NM': item['MAKER_NM'],
                    'UPDATE_YMD': item['UPDATE_YMD'],
                  })
                      .toList();
                });
              } else {
                setState(() {
                  _searchResults = [
                    {'FOOD_NM_KR': '결과가 없습니다: "$query".'}
                  ];
                  _totalPages = 1;
                });
              }
            } else {
              setState(() {
                _searchResults = [
                  {'FOOD_NM_KR': '오류: ${data['header']['resultMsg']}'}
                ];
                _totalPages = 1;
              });
            }
          } catch (e) {
            setState(() {
              _searchResults = [
                {'FOOD_NM_KR': 'JSON 파싱 중 오류 발생: $e'}
              ];
              _totalPages = 1;
            });
          }
        }
      } else {
        setState(() {
          _searchResults = [
            {'FOOD_NM_KR': '서버 오류: 데이터를 가져오는 데 실패했습니다 (상태 코드: ${response.statusCode})'}
          ];
          _totalPages = 1;
        });
      }
    } catch (e) {
      setState(() {
        _searchResults = [
          {'FOOD_NM_KR': '네트워크 요청 중 오류 발생: $e'}
        ];
        _totalPages = 1;
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // 응답이 XML인지 JSON인지 확인하는 함수
  bool _isXmlResponse(String responseBody) {
    return responseBody.trim().startsWith('<');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Screen 2 - Search'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Enter text to search:',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _controller,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Type something...',
              ),
              keyboardType: TextInputType.text,
              textInputAction: TextInputAction.search,
              onSubmitted: (query) {
                if (query.isNotEmpty) {
                  _performSearch(query);
                }
              },
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                if (_controller.text.isNotEmpty) {
                  _performSearch(_controller.text);
                }
              },
              child: const Text('Search'),
            ),
            const SizedBox(height: 20),
            if (_isLoading)
              const Center(child: CircularProgressIndicator())
            else if (_searchResults.isEmpty)
              const Text('No results to display.', style: TextStyle(fontSize: 16))
            else
              Expanded(
                child: Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                        itemCount: _searchResults.length,
                        itemBuilder: (context, index) {
                          return ListTile(
                            title: Text(_searchResults[index]['FOOD_NM_KR'] ?? 'N/A'),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => FoodDetailPage(
                                    foodItem: _searchResults[index],
                                  ),
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        _totalPages,
                            (index) => InkWell(
                          onTap: () {
                            setState(() {
                              _currentPage = index + 1; // 페이지 번호는 1부터 시작
                              _performSearch(_currentQuery, pageNo: _currentPage);
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              '${index + 1}',
                              style: TextStyle(
                                fontWeight: _currentPage == index + 1
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                                color: _currentPage == index + 1
                                    ? Colors.blue
                                    : Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}


class FoodDetailPage extends StatelessWidget {
  final Map<String, dynamic> foodItem;

  const FoodDetailPage({super.key, required this.foodItem});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Food Detail'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Food Name: ${foodItem['FOOD_NM_KR'] ?? 'N/A'}',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text('Food Reference Name: ${foodItem['FOOD_REF_NM'] ?? 'N/A'}'),
            Text('Food Category 3 Name: ${foodItem['FOOD_CAT3_NM'] ?? 'N/A'}'),
            Text('Calories (AMT_NUM1): ${foodItem['AMT_NUM1'] ?? 'N/A'} kcal'),
            Text('Carbohydrates (AMT_NUM7): ${foodItem['AMT_NUM7'] ?? 'N/A'} g'),
            Text('Protein (AMT_NUM3): ${foodItem['AMT_NUM3'] ?? 'N/A'} g'),
            Text('Fat (AMT_NUM4): ${foodItem['AMT_NUM4'] ?? 'N/A'} g'),
            Text('Saturated Fat (AMT_NUM8): ${foodItem['AMT_NUM8'] ?? 'N/A'} g'),
            Text('Cholesterol (AMT_NUM14): ${foodItem['AMT_NUM14'] ?? 'N/A'} mg'),
            Text('Nutrition Amount per Serving: ${foodItem['NUTRI_AMOUNT_SERVING'] ?? 'N/A'}'),
            Text('Weight (Z10500): ${foodItem['Z10500'] ?? 'N/A'}'),
            Text('Maker Name: ${foodItem['MAKER_NM'] ?? 'N/A'}'),
            Text('Last Updated: ${foodItem['UPDATE_YMD'] ?? 'N/A'}'),
          ],
        ),
      ),
    );
  }
}


